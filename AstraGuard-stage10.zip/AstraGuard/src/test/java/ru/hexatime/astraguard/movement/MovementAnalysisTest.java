package ru.hexatime.astraguard.movement;

import org.junit.jupiter.api.Test;
import ru.hexatime.astraguard.combat.analysis.ControlClass;
import ru.hexatime.astraguard.combat.analysis.Finding;
import ru.hexatime.astraguard.movement.analysis.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Тесты на модели ванильной физики (формулы из кода игры), а не на записях реального клиента.
 * Проверяют: честные сценарии (спринт, спринт-прыжок, лёд, прыжки) не флагаются, читерские — флагаются.
 */
class MovementAnalysisTest {

    private static final MoveThresholds JAVA = MoveThresholds.defaults(ControlClass.JAVA);
    private static final MoveThresholds TOUCH = MoveThresholds.defaults(ControlClass.BEDROCK_TOUCH);
    private static final double SPRINT = 0.13;

    private static MoveFrame frame(long t, double h, double dy, boolean ground, double slip) {
        return new MoveFrame(t, h, dy, 0, false, ground, ground, slip, false, false, false, SPRINT, 0.42, 0.08, false);
    }

    /** Ванильный порядок тика: разгон → смещение → трение (по состоянию земли в начале тика). */
    private static int simulateSpeed(SpeedAnalyzer a, MoveThresholds th, double slip, boolean jumping,
                                     double hackFactor, int ticks) {
        double v = 0;
        boolean ground = true;
        int airTicks = 0;
        int flags = 0;
        long time = 0;
        for (int i = 0; i < ticks; i++) {
            boolean takeoff = jumping && ground;
            double accel = ground ? SPRINT * 0.98 * 0.216 / (slip * slip * slip) : 0.026 * 0.98;
            if (takeoff) {
                v += 0.2;
            }
            double d = (v + accel) * hackFactor;
            double friction = ground ? slip * 0.91 : 0.91;
            v = d * friction;
            if (takeoff) {
                ground = false;
                airTicks = 0;
            } else if (!ground && ++airTicks >= 12) {
                ground = true;
            }
            time += 50;
            if (a.onFrame(frame(time, d, 0, ground, slip), th) != null) {
                flags++;
            }
        }
        return flags;
    }

    @Test
    void sprintingOnGroundIsNotFlagged() {
        assertEquals(0, simulateSpeed(new SpeedAnalyzer(), JAVA, 0.6, false, 1.0, 300));
    }

    @Test
    void sprintJumpingChainIsNotFlagged() {
        assertEquals(0, simulateSpeed(new SpeedAnalyzer(), JAVA, 0.6, true, 1.0, 400));
    }

    @Test
    void sprintingOnIceIsNotFlagged() {
        assertEquals(0, simulateSpeed(new SpeedAnalyzer(), JAVA, 0.98, false, 1.0, 300));
        assertEquals(0, simulateSpeed(new SpeedAnalyzer(), JAVA, 0.98, true, 1.0, 300));
    }

    @Test
    void speedHackOnGroundIsFlagged() {
        assertTrue(simulateSpeed(new SpeedAnalyzer(), JAVA, 0.6, false, 1.35, 100) > 0);
    }

    @Test
    void bhopSpeedHackIsFlagged() {
        assertTrue(simulateSpeed(new SpeedAnalyzer(), JAVA, 0.6, true, 1.3, 200) > 0);
    }

    @Test
    void touchProfileIsMoreLenientThanJava() {
        int java = simulateSpeed(new SpeedAnalyzer(), JAVA, 0.6, false, 1.08, 200);
        int touch = simulateSpeed(new SpeedAnalyzer(), TOUCH, 0.6, false, 1.08, 200);
        assertTrue(touch <= java);
    }

    @Test
    void alteredMediumResetsSpeedCheck() {
        SpeedAnalyzer a = new SpeedAnalyzer();
        long t = 0;
        for (int i = 0; i < 30; i++) {
            MoveFrame f = new MoveFrame(t += 50, 0.6, 0, 0, false, false, false, 0.6, true, false, false,
                    SPRINT, 0.42, 0.08, false);
            assertNull(a.onFrame(f, JAVA)); // в воде/на лестнице скорость не оцениваем
        }
    }

    // ---------- Fly ----------

    private static int simulateJump(FlyAnalyzer a, MoveThresholds th, double jumpPower, int jumps, boolean wall) {
        int flags = 0;
        long t = 0;
        for (int j = 0; j < jumps; j++) {
            for (int i = 0; i < 3; i++) {
                if (a.onFrame(frame(t += 50, 0.2, 0, true, 0.6), th) != null) flags++;
            }
            double dy = jumpPower;
            while (true) {
                MoveFrame f = new MoveFrame(t += 50, 0.2, dy, 0, false, false, false, 0.6, false, wall, false,
                        SPRINT, jumpPower, 0.08, false);
                if (a.onFrame(f, th) != null) flags++;
                dy = (dy - 0.08) * 0.98;
                if (dy < -0.8) break;
            }
            if (a.onFrame(frame(t += 50, 0.2, -0.5, true, 0.6), th) != null) flags++;
        }
        return flags;
    }

    @Test
    void normalJumpsAreNotFlagged() {
        assertEquals(0, simulateJump(new FlyAnalyzer(), JAVA, 0.42, 30, false));
    }

    @Test
    void jumpBoostJumpsAreNotFlaggedWhenPowerIsKnown() {
        assertEquals(0, simulateJump(new FlyAnalyzer(), JAVA, 0.62, 30, false));
    }

    @Test
    void highJumpIsFlaggedBecauseTakeoffExceedsJumpPower() {
        FlyAnalyzer a = new FlyAnalyzer();
        int flags = 0;
        long t = 0;
        for (int j = 0; j < 4; j++) {
            a.onFrame(frame(t += 50, 0.2, 0, true, 0.6), JAVA);
            double dy = 0.9;
            MoveFrame f = new MoveFrame(t += 50, 0.2, dy, 0, false, false, false, 0.6, false, false, false,
                    SPRINT, 0.42, 0.08, false);
            if (a.onFrame(f, JAVA) != null) flags++;
            a.onFrame(frame(t += 50, 0.2, 0, true, 0.6), JAVA);
        }
        assertTrue(flags > 0);
    }

    @Test
    void hoveringInAirIsFlagged() {
        FlyAnalyzer a = new FlyAnalyzer();
        long t = 0;
        a.onFrame(frame(t += 50, 0.2, 0, true, 0.6), JAVA);
        Finding last = null;
        for (int i = 0; i < 20; i++) {
            Finding f = a.onFrame(frame(t += 50, 0.2, 0.0, false, 0.6), JAVA);
            if (f != null) last = f;
        }
        assertNotNull(last);
        assertEquals("Fly-Gravity", last.check());
        assertEquals("move-vertical", last.group());
    }

    @Test
    void climbingAlongWallIsSpider() {
        FlyAnalyzer a = new FlyAnalyzer();
        long t = 0;
        a.onFrame(frame(t += 50, 0.0, 0, true, 0.6), JAVA);
        Finding last = null;
        for (int i = 0; i < 20; i++) {
            MoveFrame f = new MoveFrame(t += 50, 0.0, 0.12, 0, false, false, false, 0.6, false, true, false,
                    SPRINT, 0.42, 0.08, false);
            Finding r = a.onFrame(f, JAVA);
            if (r != null) last = r;
        }
        assertNotNull(last);
        assertEquals("Spider-Climb", last.check());
    }

    @Test
    void ceilingBumpDoesNotFlag() {
        FlyAnalyzer a = new FlyAnalyzer();
        long t = 0;
        a.onFrame(frame(t += 50, 0, 0, true, 0.6), JAVA);
        a.onFrame(new MoveFrame(t += 50, 0, 0.42, 0, false, false, false, 0.6, false, false, false, SPRINT, 0.42, 0.08, false), JAVA);
        // удар головой о потолок: скорость обнулена, дальше падение
        double dy = -0.0784;
        for (int i = 0; i < 10; i++) {
            assertNull(a.onFrame(new MoveFrame(t += 50, 0, dy, 0, false, false, false, 0.6, false, false, false,
                    SPRINT, 0.42, 0.08, false), JAVA));
            dy = (dy - 0.08) * 0.98;
        }
    }

    @Test
    void slowFallingIsModeled() {
        FlyAnalyzer a = new FlyAnalyzer();
        long t = 0;
        a.onFrame(frame(t += 50, 0, 0, true, 0.6), JAVA);
        double dy = -0.0784;
        for (int i = 0; i < 60; i++) {
            assertNull(a.onFrame(new MoveFrame(t += 50, 0, dy, 0, false, false, false, 0.6, false, false, false,
                    SPRINT, 0.42, 0.08, true), JAVA));
            dy = (dy - 0.01) * 0.98;
        }
    }

    // ---------- Ground / Jesus / Distance / Timer ----------

    @Test
    void groundSpoofIsFlaggedOnJavaButNotOnBedrock() {
        GroundAnalyzer java = new GroundAnalyzer();
        GroundAnalyzer bedrock = new GroundAnalyzer();
        Finding jf = null;
        long t = 0;
        for (int i = 0; i < 12; i++) {
            MoveFrame f = new MoveFrame(t += 50, 0.2, -0.5, 0, false, false, true, 0.6, false, false, false, SPRINT, 0.42, 0.08, false);
            Finding r = java.onFrame(f, JAVA);
            if (r != null) jf = r;
            assertNull(bedrock.onFrame(f, TOUCH));
        }
        assertNotNull(jf);
        assertEquals("NoFall-Ground", jf.check());
    }

    @Test
    void honestLandingsDoNotTriggerGroundCheck() {
        GroundAnalyzer a = new GroundAnalyzer();
        long t = 0;
        for (int i = 0; i < 100; i++) {
            boolean claimed = i % 10 == 9;
            MoveFrame f = new MoveFrame(t += 50, 0.2, -0.3, 0, false, claimed, claimed, 0.6, false, false, false, SPRINT, 0.42, 0.08, false);
            assertNull(a.onFrame(f, JAVA));
        }
    }

    @Test
    void jesusNeedsEightFlatFramesOverLiquid() {
        JesusAnalyzer a = new JesusAnalyzer();
        long t = 0;
        Finding r = null;
        for (int i = 0; i < 7; i++) {
            r = a.onFrame(new MoveFrame(t += 50, 0.2, 0, 0, false, false, false, 0.6, false, false, true, SPRINT, 0.42, 0.08, false));
        }
        assertNull(r);
        r = a.onFrame(new MoveFrame(t += 50, 0.2, 0, 0, false, false, false, 0.6, false, false, true, SPRINT, 0.42, 0.08, false));
        assertNotNull(r);
        assertEquals("Jesus-Walk", r.check());
    }

    @Test
    void jumpingAcrossWaterIsNotJesus() {
        JesusAnalyzer a = new JesusAnalyzer();
        long t = 0;
        double dy = 0.42;
        for (int i = 0; i < 30; i++) {
            assertNull(a.onFrame(new MoveFrame(t += 50, 0.2, dy, 0, false, false, false, 0.6, false, false, true, SPRINT, 0.42, 0.08, false)));
            dy = (dy - 0.08) * 0.98;
        }
    }

    @Test
    void distanceNeedsTwoImpossibleFramesWithinFiveSeconds() {
        DistanceAnalyzer a = new DistanceAnalyzer();
        assertNull(a.onFrame(frame(1000, 7.0, 0, false, 0.6)));
        assertNotNull(a.onFrame(frame(2000, 7.0, 0, false, 0.6)));
        DistanceAnalyzer b = new DistanceAnalyzer();
        assertNull(b.onFrame(frame(1000, 7.0, 0, false, 0.6)));
        assertNull(b.onFrame(frame(9000, 7.0, 0, false, 0.6)));
        assertNull(b.onFrame(frame(9050, 0.3, -3.9, false, 0.6)));
    }

    @Test
    void steadyTwentyPacketsPerSecondIsNotTimer() {
        TimerAnalyzer a = new TimerAnalyzer();
        long t = 0;
        for (int i = 0; i < 2000; i++) {
            assertNull(a.onFrame(t += 50, JAVA));
        }
    }

    @Test
    void networkStallBurstIsNotTimer() {
        TimerAnalyzer a = new TimerAnalyzer();
        long t = 0;
        for (int i = 0; i < 100; i++) a.onFrame(t += 50, JAVA);
        t += 2500; // клиент «завис» на 2.5 с, потом пакеты пришли разом
        for (int i = 0; i < 50; i++) {
            assertNull(a.onFrame(t, JAVA));
        }
    }

    @Test
    void sustainedTimerIsFlagged() {
        TimerAnalyzer a = new TimerAnalyzer();
        long t = 0;
        Finding last = null;
        for (int i = 0; i < 600; i++) { // 30 пакетов/с = 1.5x
            Finding f = a.onFrame(t += 33, JAVA);
            if (f != null) last = f;
        }
        assertNotNull(last);
        assertEquals("Timer", last.check());
    }
}
