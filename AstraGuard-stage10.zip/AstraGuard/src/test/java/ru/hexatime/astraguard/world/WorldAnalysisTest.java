package ru.hexatime.astraguard.world;

import org.junit.jupiter.api.Test;
import ru.hexatime.astraguard.combat.analysis.ControlClass;
import ru.hexatime.astraguard.combat.analysis.Finding;
import ru.hexatime.astraguard.world.analysis.*;

import static org.junit.jupiter.api.Assertions.*;

class WorldAnalysisTest {

    private static final WorldThresholds JAVA = WorldThresholds.defaults(ControlClass.JAVA);
    private static final WorldThresholds TOUCH = WorldThresholds.defaults(ControlClass.BEDROCK_TOUCH);

    // ---------- FastBreak ----------

    @Test
    void breakAtExpectedTimeIsNotFlagged() {
        BreakAnalyzer a = new BreakAnalyzer();
        for (int i = 0; i < 20; i++) {
            assertNull(a.onBreak(i * 1000L, 1500, 1500, JAVA));
        }
    }

    @Test
    void breakAtVanillaToleranceIsNotFlagged() {
        // ваниль сама принимает ломание на ~70% прогресса
        BreakAnalyzer a = new BreakAnalyzer();
        for (int i = 0; i < 20; i++) {
            assertNull(a.onBreak(i * 1000L, 1500 * 0.7, 1500, JAVA));
        }
    }

    @Test
    void instantBreakWithHighEfficiencyIsNeverFlagged() {
        // Efficiency VI–X: сервер вернул эталон 0 или один тик — проверка не применяется
        BreakAnalyzer a = new BreakAnalyzer();
        for (int i = 0; i < 100; i++) {
            assertNull(a.onBreak(i * 100L, 0, 0, JAVA));
            assertNull(a.onBreak(i * 100L + 50, 10, 50, JAVA));
        }
    }

    @Test
    void efficiencyXOnObsidianStillCannotBeInstantWhenServerSaysSo() {
        // эталон 2000 мс (сервер учёл инструмент и уровень), слом за 100 мс дважды — нарушение
        BreakAnalyzer a = new BreakAnalyzer();
        assertNull(a.onBreak(1000, 100, 2000, JAVA));
        Finding f = a.onBreak(5000, 100, 2000, JAVA);
        assertNotNull(f);
        assertEquals("FastBreak", f.check());
    }

    @Test
    void singleFastBreakIsNotFlagged() {
        BreakAnalyzer a = new BreakAnalyzer();
        assertNull(a.onBreak(1000, 100, 2000, JAVA));
        assertNull(a.onBreak(100_000, 100, 2000, JAVA)); // слишком давно — это снова «первый» случай
    }

    // ---------- FastPlace ----------

    @Test
    void normalBridgingRateIsNotFlagged() {
        PlaceRateAnalyzer a = new PlaceRateAnalyzer();
        for (int i = 0; i < 200; i++) {
            assertNull(a.onPlace(i * 200L, JAVA)); // 5/с
        }
    }

    @Test
    void impossiblePlaceRateIsFlagged() {
        PlaceRateAnalyzer a = new PlaceRateAnalyzer();
        Finding last = null;
        for (int i = 0; i < 60; i++) {
            Finding f = a.onPlace(i * 40L, JAVA); // 25/с
            if (f != null) last = f;
        }
        assertNotNull(last);
        assertEquals("FastPlace", last.check());
    }

    @Test
    void shortBurstIsNotFlagged() {
        PlaceRateAnalyzer a = new PlaceRateAnalyzer();
        for (int i = 0; i < 11; i++) {
            assertNull(a.onPlace(i * 60L, JAVA));
        }
    }

    // ---------- Scaffold / InvalidPlace ----------

    // блок-опора [0,1]^3, ставим на верхнюю грань (нормаль +Y)
    private static final double[] BOX = {0, 0, 0, 1, 1, 1};
    private static final int[] UP = {0, 1, 0};

    @Test
    void lookingAtBlockIsOk() {
        double[] eye = {0.5, 2.6, 2.0};
        double dx = 0.5 - eye[0], dy = 1.0 - eye[1], dz = 0.5 - eye[2];
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        assertEquals(PlacementAnalyzer.Result.OK,
                PlacementAnalyzer.classify(eye, new double[]{dx / len, dy / len, dz / len}, BOX, UP, JAVA, true));
    }

    @Test
    void lookingAwayIsAimMiss() {
        double[] eye = {0.5, 2.6, 2.0};
        assertEquals(PlacementAnalyzer.Result.AIM_MISS,
                PlacementAnalyzer.classify(eye, new double[]{0, 0, 1}, BOX, UP, JAVA, true));
    }

    @Test
    void touchProfileDoesNotCheckAim() {
        double[] eye = {0.5, 2.6, 2.0};
        assertEquals(PlacementAnalyzer.Result.OK,
                PlacementAnalyzer.classify(eye, new double[]{0, 0, 1}, BOX, UP, TOUCH, TOUCH.aimChecks()));
    }

    @Test
    void placingOnFaceTurnedAwayIsFaceAway() {
        double[] eye = {0.5, -1.5, 0.5}; // глаза под блоком, ставят на верхнюю грань
        assertEquals(PlacementAnalyzer.Result.FACE_AWAY,
                PlacementAnalyzer.classify(eye, new double[]{0, 1, 0}, BOX, UP, JAVA, true));
    }

    @Test
    void scaffoldNeedsSeveralMisses() {
        PlacementAnalyzer a = new PlacementAnalyzer();
        assertNull(a.onPlace(PlacementAnalyzer.Result.AIM_MISS));
        assertNull(a.onPlace(PlacementAnalyzer.Result.AIM_MISS));
        assertNull(a.onPlace(PlacementAnalyzer.Result.AIM_MISS));
        Finding f = a.onPlace(PlacementAnalyzer.Result.AIM_MISS);
        assertNotNull(f);
        assertEquals("Scaffold-Aim", f.check());
        assertEquals("world-place-aim", f.group());
    }

    @Test
    void occasionalMissAmongGoodPlacesIsNotFlagged() {
        PlacementAnalyzer a = new PlacementAnalyzer();
        for (int i = 0; i < 100; i++) {
            assertNull(a.onPlace(i % 4 == 0 ? PlacementAnalyzer.Result.AIM_MISS : PlacementAnalyzer.Result.OK));
        }
    }

    // ---------- InvalidInteract-Reach ----------

    @Test
    void interactionWithinRangeIsNotFlagged() {
        InteractReachAnalyzer a = new InteractReachAnalyzer();
        for (int i = 0; i < 50; i++) {
            assertNull(a.onInteract(5.0, 4.5, "слом", JAVA)); // в пределах запаса 0.7
        }
    }

    @Test
    void farInteractionIsFlaggedAfterRepeats() {
        InteractReachAnalyzer a = new InteractReachAnalyzer();
        assertNull(a.onInteract(7.0, 4.5, "слом", JAVA));
        assertNull(a.onInteract(7.0, 4.5, "слом", JAVA));
        Finding f = a.onInteract(7.0, 4.5, "слом", JAVA);
        assertNotNull(f);
        assertEquals("InvalidInteract-Reach", f.check());
    }
}
