package ru.hexatime.astraguard.enchant;

import org.junit.jupiter.api.Test;
import ru.hexatime.astraguard.enchant.analysis.EnchantMath;
import ru.hexatime.astraguard.enchant.analysis.EnchantMath.Cause;
import ru.hexatime.astraguard.enchant.analysis.EnchantSnapshot;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class EnchantAnalysisTest {

    private static EnchantSnapshot snap(Object... kv) {
        java.util.Map<String, Integer> m = new java.util.LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) {
            m.put((String) kv[i], (Integer) kv[i + 1]);
        }
        return new EnchantSnapshot(m);
    }

    private static List<EnchantSnapshot> fullSet(Object... kv) {
        return List.of(snap(kv), snap(kv), snap(kv), snap(kv));
    }

    // ---------- Snapshot ----------

    @Test
    void snapshotNormalizesKeysAndIgnoresZeroLevels() {
        EnchantSnapshot s = snap("sharpness", 7, "minecraft:unbreaking", 0, "Custom:Drill", 3);
        assertEquals(7, s.level("minecraft:sharpness"));
        assertEquals(7, s.level("sharpness"));
        assertEquals(0, s.level("unbreaking"));
        assertEquals(3, s.level("custom:drill"));
    }

    @Test
    void snapshotMergeKeepsHigherLevel() {
        EnchantSnapshot a = snap("sharpness", 5, "unbreaking", 3);
        EnchantSnapshot b = snap("sharpness", 7);
        EnchantSnapshot m = a.mergedWith(b);
        assertEquals(7, m.level("sharpness"));
        assertEquals(3, m.level("unbreaking"));
        assertSame(a, a.mergedWith(EnchantSnapshot.EMPTY));
        assertSame(b, EnchantSnapshot.EMPTY.mergedWith(b));
    }

    @Test
    void snapshotIsImmutable() {
        EnchantSnapshot s = snap("sharpness", 7);
        assertThrows(UnsupportedOperationException.class, () -> s.levels().put("x", 1));
    }

    @Test
    void describeUsesRomanNumeralsUpToTenAndNumbersAbove() {
        assertEquals("sharpness VII, unbreaking V", snap("sharpness", 7, "unbreaking", 5).describe());
        assertEquals("efficiency X", snap("efficiency", 10).describe());
        assertEquals("protection 255", snap("protection", 255).describe());
        assertEquals("нет", EnchantSnapshot.EMPTY.describe());
        assertEquals("custom:drill III", snap("custom:drill", 3).describe());
    }

    // ---------- Sharpness VI–VII ----------

    @Test
    void sharpnessBonusFollowsVanillaFormulaForCustomLevels() {
        assertEquals(0.0, EnchantMath.sharpnessBonus(0), 1e-9);
        assertEquals(1.0, EnchantMath.sharpnessBonus(1), 1e-9);
        assertEquals(3.0, EnchantMath.sharpnessBonus(5), 1e-9);
        assertEquals(3.5, EnchantMath.sharpnessBonus(6), 1e-9);
        assertEquals(4.0, EnchantMath.sharpnessBonus(7), 1e-9);
        assertEquals(4.0, EnchantMath.sharpnessBonus(snap("sharpness", 7)), 1e-9);
    }

    // ---------- Protection IV–V ----------

    @Test
    void fullProtectionFiveReachesTheEightyPercentCap() {
        int pts = EnchantMath.totalProtectionPoints(fullSet("protection", 5), Cause.GENERIC);
        assertEquals(20, pts);
        assertEquals(0.2, EnchantMath.enchantDamageFactor(pts), 1e-9);
    }

    @Test
    void fullProtectionFourGivesSixtyFourPercent() {
        int pts = EnchantMath.totalProtectionPoints(fullSet("protection", 4), Cause.GENERIC);
        assertEquals(16, pts);
        assertEquals(0.36, EnchantMath.enchantDamageFactor(pts), 1e-9);
    }

    @Test
    void mixedProtectionFourAndFiveSumsPerPiece() {
        List<EnchantSnapshot> mixed = List.of(snap("protection", 5), snap("protection", 5),
                snap("protection", 4), snap("protection", 4));
        assertEquals(18, EnchantMath.totalProtectionPoints(mixed, Cause.GENERIC));
    }

    @Test
    void protectionPointsAreCappedAtTwenty() {
        List<EnchantSnapshot> set = fullSet("protection", 5, "blast_protection", 5);
        assertEquals(20, EnchantMath.totalProtectionPoints(set, Cause.EXPLOSION));
        assertEquals(0.2, EnchantMath.enchantDamageFactor(500), 1e-9);
        assertEquals(1.0, EnchantMath.enchantDamageFactor(-3), 1e-9);
    }

    @Test
    void specificProtectionsApplyOnlyToTheirCause() {
        EnchantSnapshot boots = snap("feather_falling", 4);
        assertEquals(12, EnchantMath.protectionPoints(boots, Cause.FALL));
        assertEquals(0, EnchantMath.protectionPoints(boots, Cause.GENERIC));
        EnchantSnapshot blast = snap("blast_protection", 4);
        assertEquals(8, EnchantMath.protectionPoints(blast, Cause.EXPLOSION));
        assertEquals(0, EnchantMath.protectionPoints(blast, Cause.PROJECTILE));
        EnchantSnapshot fire = snap("fire_protection", 4);
        assertEquals(8, EnchantMath.protectionPoints(fire, Cause.FIRE));
        EnchantSnapshot arrow = snap("projectile_protection", 4);
        assertEquals(8, EnchantMath.protectionPoints(arrow, Cause.PROJECTILE));
    }

    // ---------- Алмазная и незеритовая броня ----------

    @Test
    void diamondArmorFactorMatchesVanillaFormula() {
        // броня 20, твёрдость 8, удар 10: f=4, g=17.5, множитель 0.3
        assertEquals(0.3, EnchantMath.armorDamageFactor(10, 20, 8), 1e-9);
    }

    @Test
    void netheriteTakesLessDamageThanDiamondWithSameEnchants() {
        double diamond = EnchantMath.damageAfterArmor(10, 20, 8, 20);
        double netherite = EnchantMath.damageAfterArmor(10, 20, 12, 20);
        assertEquals(0.6, diamond, 1e-9);
        assertEquals(0.56, netherite, 1e-9);
        assertTrue(netherite < diamond);
    }

    @Test
    void armorFactorHasMinimumTwentyPercentOfArmorForHugeHits() {
        // сильный удар: g = max(armor*0.2, ...) = 4 → множитель 0.84
        assertEquals(0.84, EnchantMath.armorDamageFactor(1000, 20, 8), 1e-9);
    }

    @Test
    void noArmorOrNoDamageMeansNoReduction() {
        assertEquals(1.0, EnchantMath.armorDamageFactor(10, 0, 0), 1e-9);
        assertEquals(1.0, EnchantMath.armorDamageFactor(0, 20, 8), 1e-9);
        assertEquals(10.0, EnchantMath.damageAfterArmor(10, 0, 0, 0), 1e-9);
    }

    // ---------- Unbreaking IV–V ----------

    @Test
    void unbreakingOnToolsMultipliesDurabilityByLevelPlusOne() {
        assertEquals(1.0, EnchantMath.toolDurabilityMultiplier(0), 1e-9);
        assertEquals(5.0, EnchantMath.toolDurabilityMultiplier(4), 1e-9);
        assertEquals(6.0, EnchantMath.toolDurabilityMultiplier(5), 1e-9);
        assertEquals(1.0 / 6.0, EnchantMath.toolDurabilityLossChance(5), 1e-9);
    }

    @Test
    void unbreakingOnArmorUsesSixtyPercentFormula() {
        assertEquals(1.0, EnchantMath.armorDurabilityLossChance(0) , 1e-9);
        assertEquals(0.68, EnchantMath.armorDurabilityLossChance(4), 1e-9);
        assertEquals(0.6 + 0.4 / 6.0, EnchantMath.armorDurabilityLossChance(5), 1e-9);
        assertEquals(1.5, EnchantMath.armorDurabilityMultiplier(5), 1e-9);
        assertTrue(EnchantMath.armorDurabilityMultiplier(5) > EnchantMath.armorDurabilityMultiplier(4));
    }

    // ---------- Efficiency VI–X ----------

    @Test
    void efficiencyBonusGrowsWithoutCapUpToTen() {
        assertEquals(0.0, EnchantMath.efficiencyBonus(0), 1e-9);
        assertEquals(26.0, EnchantMath.efficiencyBonus(5), 1e-9);
        assertEquals(37.0, EnchantMath.efficiencyBonus(6), 1e-9);
        assertEquals(50.0, EnchantMath.efficiencyBonus(7), 1e-9);
        assertEquals(65.0, EnchantMath.efficiencyBonus(8), 1e-9);
        assertEquals(82.0, EnchantMath.efficiencyBonus(9), 1e-9);
        assertEquals(101.0, EnchantMath.efficiencyBonus(10), 1e-9);
    }

    @Test
    void efficiencyAppliesOnlyWhenToolSuitsTheBlock() {
        assertEquals(109.0, EnchantMath.miningSpeedWithEfficiency(8.0, 10), 1e-9);
        assertEquals(1.0, EnchantMath.miningSpeedWithEfficiency(1.0, 10), 1e-9);
        assertEquals(8.0, EnchantMath.miningSpeedWithEfficiency(8.0, 0), 1e-9);
    }

    @Test
    void efficiencySixOnDiamondPickaxeBreaksStoneInstantly() {
        // скорость/твёрдость/30 ≥ 1 — блок ломается за один тик; Efficiency V ещё нет
        double hardness = 1.5;
        assertTrue(EnchantMath.miningSpeedWithEfficiency(8.0, 6) / hardness / 30.0 >= 1.0);
        assertTrue(EnchantMath.miningSpeedWithEfficiency(8.0, 5) / hardness / 30.0 < 1.0);
    }

    @Test
    void efficiencyTenDoesNotInstantlyBreakObsidian() {
        double perTick = EnchantMath.miningSpeedWithEfficiency(8.0, 10) / 50.0 / 30.0;
        assertTrue(perTick < 1.0);
        assertTrue(perTick > 0.0);
    }

    @Test
    void efficiencyReadFromSnapshot() {
        assertEquals(10, EnchantMath.efficiencyLevel(snap("efficiency", 10)));
        assertEquals(5, EnchantMath.unbreakingLevel(snap("unbreaking", 5)));
        assertEquals(0, EnchantMath.efficiencyLevel(EnchantSnapshot.EMPTY));
    }

    // ---------- пометка «выше ванили» ----------

    @Test
    void aboveVanillaIsOnlyAMarkNotAVerdict() {
        assertTrue(EnchantMath.aboveVanillaMax("sharpness", 6));
        assertTrue(EnchantMath.aboveVanillaMax("minecraft:efficiency", 10));
        assertFalse(EnchantMath.aboveVanillaMax("sharpness", 5));
        assertFalse(EnchantMath.aboveVanillaMax("custom:drill", 10));
        assertFalse(EnchantMath.aboveVanillaMax("minecraft:unknown_thing", 50));
    }
}
