package ru.hexatime.astraguard.combat;

import org.junit.jupiter.api.Test;
import ru.hexatime.astraguard.combat.analysis.*;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class CombatAnalysisTest {

    private static final Thresholds JAVA = Thresholds.defaults(ControlClass.JAVA);
    private static final Thresholds TOUCH = Thresholds.defaults(ControlClass.BEDROCK_TOUCH);

    // ---------- геометрия ----------

    @Test
    void distanceToBoxIsZeroInsideAndCorrectOutside() {
        assertEquals(0.0, Geometry.distanceToBox(0.1, 1, 0.1, -0.3, 0, -0.3, 0.3, 1.8, 0.3), 1e-9);
        assertEquals(2.7, Geometry.distanceToBox(3.0, 1, 0, -0.3, 0, -0.3, 0.3, 1.8, 0.3), 1e-9);
    }

    @Test
    void rayHitsBoxOnlyWhenAimedAndInRange() {
        double[] l = Geometry.look(0, 0); // yaw 0 = в сторону +Z
        assertEquals(1.0, l[2], 1e-9);
        assertTrue(Geometry.rayHitsBox(0, 1, 0, l[0], l[1], l[2], -0.3, 0, 2.5, 0.3, 1.8, 3.1, 6));
        assertFalse(Geometry.rayHitsBox(0, 1, 0, l[0], l[1], l[2], 2, 0, 2.5, 2.6, 1.8, 3.1, 6));
        assertFalse(Geometry.rayHitsBox(0, 1, 0, l[0], l[1], l[2], -0.3, 0, 8, 0.3, 1.8, 8.6, 6));
    }

    @Test
    void yawToMatchesLookDirection() {
        double yaw = Geometry.yawTo(-1, 1); // цель по диагонали
        double[] l = Geometry.look(yaw, 0);
        assertEquals(-1.0 / Math.sqrt(2), l[0], 1e-9);
        assertEquals(1.0 / Math.sqrt(2), l[2], 1e-9);
        assertEquals(10.0, Geometry.wrapDeg(370), 1e-9);
        assertEquals(-170.0, Geometry.wrapDeg(190), 1e-9);
    }

    // ---------- AutoClicker ----------

    private static Finding feed(ClickAnalyzer a, int[] intervals, Thresholds t) {
        int tick = 1000;
        Finding last = null;
        for (int iv : intervals) {
            tick += iv;
            Finding f = a.onSwing(tick, t);
            if (f != null) {
                last = f;
            }
        }
        return last;
    }

    @Test
    void constantTwoTickClicksAreFlagged() {
        int[] iv = new int[80];
        java.util.Arrays.fill(iv, 2); // ровно 10 CPS
        Finding f = feed(new ClickAnalyzer(), iv, JAVA);
        assertNotNull(f);
        assertEquals("AutoClicker-Pattern", f.check());
    }

    @Test
    void humanJitterIsNotFlagged() {
        Random r = new Random(7);
        int[] iv = new int[400];
        for (int i = 0; i < iv.length; i++) {
            double x = r.nextDouble();
            iv[i] = x < 0.45 ? 2 : x < 0.7 ? 1 : x < 0.9 ? 3 : 4; // реалистичный разброс
        }
        assertNull(feed(new ClickAnalyzer(), iv, JAVA));
    }

    @Test
    void slowClicksBelowMinCpsAreIgnored() {
        int[] iv = new int[80];
        java.util.Arrays.fill(iv, 4); // 5 CPS ровно — медленно, не анализируется
        assertNull(feed(new ClickAnalyzer(), iv, JAVA));
    }

    @Test
    void touchNeedsStricterEvidenceThanJava() {
        // 90% интервалов одинаковы: для Java это подозрительно (порог 0.88), для тача (0.95) — нет
        int[] iv = new int[120];
        for (int i = 0; i < iv.length; i++) {
            iv[i] = (i % 10 == 9) ? 3 : 2;
        }
        // стандартное отклонение у такого ряда ≈ 0.3, т.е. прошло бы по std; различает именно доля
        assertNotNull(feed(new ClickAnalyzer(), iv, JAVA));
        assertNull(feed(new ClickAnalyzer(), iv, TOUCH));
    }

    @Test
    void singleCpsSpikeDoesNotFlag() {
        ClickAnalyzer a = new ClickAnalyzer();
        Finding f = null;
        for (int i = 0; i < 29; i++) { // 29 кликов за 29 тиков, порог 28 за 20 тиков — один всплеск
            Finding x = a.onSwing(2000 + i / 2, JAVA);
            if (x != null) f = x;
        }
        assertNull(f);
    }


    @Test
    void sustainedImpossibleCpsIsFlaggedButOnlyAfterRepeating() {
        ClickAnalyzer a = new ClickAnalyzer();
        Finding first = null, any = null;
        for (int sec = 0; sec < 3; sec++) {
            for (int i = 0; i < 40; i++) { // 40 взмахов в секунду, порог Java 28
                Finding x = a.onSwing(5000 + sec * 20 + i / 2, JAVA);
                if (x != null) { if (first == null) first = x; any = x; }
            }
        }
        assertNotNull(any);
        assertEquals("AutoClicker-CPS", any.check());
    }

    // ---------- Reach ----------

    @Test
    void reachWithinAllowanceNeverFlags() {
        ReachAnalyzer r = new ReachAnalyzer();
        for (int i = 0; i < 100; i++) {
            assertNull(r.onAttack(3.4, 3.0 + JAVA.reachTolerance()));
        }
    }

    @Test
    void singleReachOutlierIsAbsorbedButRepeatedIsFlagged() {
        ReachAnalyzer r = new ReachAnalyzer();
        assertNull(r.onAttack(3.6, 3.45)); // выброс
        for (int i = 0; i < 6; i++) assertNull(r.onAttack(2.9, 3.45)); // буфер остывает
        assertNull(r.onAttack(3.6, 3.45));
        Finding f = r.onAttack(4.6, 3.45);
        assertNotNull(f);
        assertEquals("Reach", f.check());
        assertTrue(f.weight() > 1.0);
    }

    // ---------- KillAura ----------

    private static KillAuraAnalyzer.Hit hit(int tick, int target, double yawTo, double err, boolean wall) {
        return new KillAuraAnalyzer.Hit(tick, target, 3.0, yawTo, err, wall);
    }

    @Test
    void hitsInFrontNeverFlagFacing() {
        KillAuraAnalyzer k = new KillAuraAnalyzer();
        for (int i = 0; i < 100; i++) assertNull(k.onAttack(hit(i * 5, 1, 0, 8, false), JAVA));
    }

    @Test
    void hitsFromBehindFlagFacingOnJava() {
        KillAuraAnalyzer k = new KillAuraAnalyzer();
        Finding f = null;
        for (int i = 0; i < 4; i++) {
            Finding x = k.onAttack(hit(i * 10, 1, 0, 120, false), JAVA);
            if (x != null) f = x;
        }
        assertNotNull(f);
        assertEquals("KillAura-Facing", f.check());
    }

    @Test
    void sixtyFiveDegreesIsToleratedOnTouchButNotOnJava() {
        KillAuraAnalyzer j = new KillAuraAnalyzer();
        KillAuraAnalyzer t = new KillAuraAnalyzer();
        Finding fj = null, ft = null;
        for (int i = 0; i < 6; i++) {
            Finding a = j.onAttack(hit(i * 10, 1, 0, 65, false), JAVA);
            Finding b = t.onAttack(hit(i * 10, 1, 0, 65, false), TOUCH);
            if (a != null) fj = a;
            if (b != null) ft = b;
        }
        assertNotNull(fj);
        assertNull(ft);
    }

    @Test
    void rapidSwitchingBetweenThreeOppositeTargetsIsFlagged() {
        KillAuraAnalyzer k = new KillAuraAnalyzer();
        Finding f = null;
        double[] yaws = {0, 120, -120, 0, 120};
        for (int i = 0; i < yaws.length; i++) {
            Finding x = k.onAttack(hit(100 + i * 2, i % 3 + 1, yaws[i], 5, false), JAVA);
            if (x != null) f = x;
        }
        assertNotNull(f);
        assertEquals("KillAura-Switch", f.check());
    }

    @Test
    void slowSwitchingBetweenTwoTargetsIsFine() {
        KillAuraAnalyzer k = new KillAuraAnalyzer();
        for (int i = 0; i < 40; i++) assertNull(k.onAttack(hit(i * 12, i % 2 + 1, i % 2 == 0 ? 0 : 150, 5, false), JAVA));
    }

    @Test
    void wallHitsNeedRepeatedEvidence() {
        KillAuraAnalyzer k = new KillAuraAnalyzer();
        assertNull(k.onAttack(hit(1, 1, 0, 5, true), JAVA));
        Finding f = k.onAttack(hit(8, 1, 0, 5, true), JAVA);
        assertNotNull(f);
        assertEquals("InvalidHit-Wall", f.check());
        assertEquals("combat-wall", f.group());
    }

    // ---------- Aim ----------

    @Test
    void perfectLockOnMovingTargetIsFlaggedOnJava() {
        AimAnalyzer a = new AimAnalyzer();
        Random r = new Random(3);
        Finding f = null;
        for (int i = 0; i < 12; i++) {
            Finding x = a.onAttack(i * 8, 0.2 + r.nextDouble() * 0.2, 3.0, 0.2, JAVA);
            if (x != null) f = x;
        }
        assertNotNull(f);
        assertEquals("AimAssist-Lock", f.check());
    }

    @Test
    void normalAimErrorIsNotFlagged() {
        AimAnalyzer a = new AimAnalyzer();
        Random r = new Random(5);
        for (int i = 0; i < 120; i++) {
            assertNull(a.onAttack(i * 8, 1.5 + r.nextDouble() * 4.0, 3.0, 0.2, JAVA));
        }
    }

    @Test
    void aimChecksAreOffForTouchBecauseBedrockHasAimAssist() {
        AimAnalyzer a = new AimAnalyzer();
        for (int i = 0; i < 60; i++) assertNull(a.onAttack(i * 8, 0.1, 3.0, 0.2, TOUCH));
    }

    @Test
    void snapFlickFollowedByPerfectHitsIsFlagged() {
        AimAnalyzer a = new AimAnalyzer();
        Finding f = null;
        int tick = 500;
        float yaw = 0;
        for (int i = 0; i < 4; i++) {
            tick += 20;
            a.onRotation(tick - 1, yaw, 0);
            yaw += 80; // резкий поворот на 80°
            a.onRotation(tick, yaw, 0);
            Finding x = a.onAttack(tick, 0.3, 3.0, 0.0, JAVA);
            if (x != null) f = x;
        }
        assertNotNull(f);
        assertEquals("AimAssist-Snap", f.check());
    }

    @Test
    void constantSpeedRotationIsSuspicious() {
        AimAnalyzer a = new AimAnalyzer();
        float yaw = 0;
        for (int tick = 100; tick < 107; tick++) {
            yaw += 6.0f;
            a.onRotation(tick, yaw, 0);
        }
        Finding f = a.onAttack(106, 3.0, 3.0, 0.0, JAVA);
        assertNotNull(f);
        assertEquals("Rotation-Smooth", f.check());
    }

    @Test
    void humanRotationVarianceIsNotSmooth() {
        AimAnalyzer a = new AimAnalyzer();
        float yaw = 0;
        Random r = new Random(11);
        for (int tick = 100; tick < 107; tick++) {
            yaw += 3.0f + r.nextFloat() * 5.0f;
            a.onRotation(tick, yaw, 0);
        }
        assertNull(a.onAttack(106, 3.0, 3.0, 0.0, JAVA));
    }

    // ---------- TriggerBot ----------

    @Test
    void instantReactionsAreFlagged() {
        TriggerBotAnalyzer tb = new TriggerBotAnalyzer();
        Finding f = null;
        int tick = 0;
        for (int i = 0; i < 12; i++) {
            tick += 30;
            tb.onLook(tick - 1, 7, false);
            tb.onLook(tick, 7, true);
            Finding x = tb.onAttack(tick + (i % 2), 7, JAVA);
            if (x != null) f = x;
        }
        assertNotNull(f);
        assertEquals("TriggerBot", f.check());
    }

    @Test
    void humanReactionTimesAreNotFlagged() {
        TriggerBotAnalyzer tb = new TriggerBotAnalyzer();
        Random r = new Random(9);
        int tick = 0;
        for (int i = 0; i < 60; i++) {
            tick += 40;
            tb.onLook(tick - 1, 7, false);
            tb.onLook(tick, 7, true);
            assertNull(tb.onAttack(tick + 2 + r.nextInt(7), 7, JAVA));
        }
    }

    @Test
    void controlClassMapping() {
        assertEquals(ControlClass.JAVA, ControlClass.of(false, "TOUCH"));
        assertEquals(ControlClass.BEDROCK_TOUCH, ControlClass.of(true, "touch"));
        assertEquals(ControlClass.BEDROCK_UNKNOWN, ControlClass.of(true, null));
        assertEquals("bedrock-controller", ControlClass.BEDROCK_CONTROLLER.key());
    }
}
