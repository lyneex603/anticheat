package ru.hexatime.astraguard.potion;

import org.junit.jupiter.api.Test;
import ru.hexatime.astraguard.potion.analysis.*;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class PotionAnalysisTest {

    private static final List<CustomMovementModifier> VANILLA_MOVE = List.of(VanillaEffectModifiers.movement());
    private static final List<CustomDamageModifier> VANILLA_DMG = List.of(VanillaEffectModifiers.damage());

    private static EffectState fx(String key, int level) {
        return new EffectState(key, level, 600);
    }

    // ---------- EffectState ----------

    @Test
    void effectStateNormalizesKeyAndLevel() {
        EffectState e = new EffectState("Jump_Boost", 0, 100);
        assertEquals("minecraft:jump_boost", e.key());
        assertEquals(1, e.level());
        assertEquals("myplugin:dash", new EffectState("MyPlugin:Dash", 2, 1).key());
        assertEquals(3, EffectState.fromAmplifier("speed", 2, 5).level());
        assertEquals("jump_boost II", fx("jump_boost", 2).describe());
        assertEquals("myplugin:dash X", fx("myplugin:dash", 10).describe());
    }

    // ---------- ваниль ----------

    @Test
    void noEffectsMeansIdentity() {
        assertTrue(EffectAggregator.movement(List.of(), VANILLA_MOVE).isIdentity());
        assertTrue(EffectAggregator.damage(List.of(), VANILLA_DMG).isIdentity());
    }

    @Test
    void jumpBoostMatchesOldHardcodedFormula() {
        // раньше: jump += 0.1 * (amplifier + 1)
        for (int amp = 0; amp < 5; amp++) {
            MovementAdjust a = EffectAggregator.movement(List.of(EffectState.fromAmplifier("jump_boost", amp, 100)), VANILLA_MOVE);
            assertEquals(0.1 * (amp + 1), a.extraJump(), 1e-9);
            assertEquals(1.0, a.speedMultiplier(), 1e-9);
            assertFalse(a.exempt());
        }
    }

    @Test
    void attributeBackedEffectsAreNotCountedTwice() {
        // Speed/Strength/Haste и т.д. уже есть в атрибутах: модификатор их не трогает
        List<EffectState> list = List.of(fx("speed", 3), fx("strength", 2), fx("haste", 2),
                fx("slowness", 1), fx("weakness", 1), fx("mining_fatigue", 1));
        assertTrue(EffectAggregator.movement(list, VANILLA_MOVE).isIdentity());
        assertTrue(EffectAggregator.damage(list, VANILLA_DMG).isIdentity());
    }

    @Test
    void resistanceReducesTakenDamageTwentyPercentPerLevel() {
        double[] expected = {0.8, 0.6, 0.4, 0.2, 0.0, 0.0};
        for (int lvl = 1; lvl <= 6; lvl++) {
            DamageAdjust d = EffectAggregator.damage(List.of(fx("resistance", lvl)), VANILLA_DMG);
            assertEquals(expected[lvl - 1], d.damageTakenMultiplier(), 1e-9);
            assertEquals(0.0, d.attackBonus(), 1e-9);
        }
    }

    // ---------- правила из конфигурации (будущие кастомные зелья) ----------

    private static RuleBasedModifiers rules() {
        return new RuleBasedModifiers(Map.of(
                "MyPlugin:Swift", new EffectRule(0.2, 0.05, 0.0, 0.0, false),
                "myplugin:dash", new EffectRule(0.0, 0.0, 0.0, 0.0, true),
                "myplugin:might", new EffectRule(0.0, 0.0, 1.5, 0.1, false),
                "myplugin:inert", new EffectRule(0.0, 0.0, 0.0, 0.0, false)));
    }

    @Test
    void emptyRulesChangeNothing() {
        RuleBasedModifiers none = new RuleBasedModifiers(Map.of());
        assertTrue(none.isEmpty());
        List<EffectState> list = List.of(fx("myplugin:swift", 3), fx("jump_boost", 1));
        assertTrue(EffectAggregator.movement(list, List.of(none.movement())).isIdentity());
        assertTrue(EffectAggregator.damage(list, List.of(none.damage())).isIdentity());
    }

    @Test
    void customSpeedAndJumpScaleWithLevel() {
        MovementAdjust a = EffectAggregator.movement(List.of(fx("myplugin:swift", 2)), List.of(rules().movement()));
        assertEquals(1.4, a.speedMultiplier(), 1e-9);
        assertEquals(0.10, a.extraJump(), 1e-9);
        assertFalse(a.exempt());
        assertEquals(1, a.reasons().size());
    }

    @Test
    void customDashExemptsMovementChecks() {
        MovementAdjust a = EffectAggregator.movement(List.of(fx("myplugin:dash", 1)), List.of(rules().movement()));
        assertTrue(a.exempt());
    }

    @Test
    void customDamageRulesApplyBonusAndReduction() {
        DamageAdjust d = EffectAggregator.damage(List.of(fx("myplugin:might", 2)), List.of(rules().damage()));
        assertEquals(3.0, d.attackBonus(), 1e-9);
        assertEquals(0.8, d.damageTakenMultiplier(), 1e-9);
    }

    @Test
    void unknownAndZeroRulesAreIgnored() {
        List<EffectState> list = List.of(fx("myplugin:unknown", 5), fx("myplugin:inert", 5));
        assertTrue(EffectAggregator.movement(list, List.of(rules().movement())).isIdentity());
        assertTrue(EffectAggregator.damage(list, List.of(rules().damage())).isIdentity());
    }

    @Test
    void vanillaAndCustomModifiersCombine() {
        List<EffectState> list = List.of(fx("jump_boost", 2), fx("myplugin:swift", 1), fx("myplugin:dash", 1),
                fx("resistance", 2), fx("myplugin:might", 1));
        MovementAdjust m = EffectAggregator.movement(list, List.of(VanillaEffectModifiers.movement(), rules().movement()));
        assertEquals(1.2, m.speedMultiplier(), 1e-9);
        assertEquals(0.2 + 0.05, m.extraJump(), 1e-9);
        assertTrue(m.exempt());
        DamageAdjust d = EffectAggregator.damage(list, List.of(VanillaEffectModifiers.damage(), rules().damage()));
        assertEquals(1.5, d.attackBonus(), 1e-9);
        assertEquals(0.6 * 0.9, d.damageTakenMultiplier(), 1e-9);
    }

    // ---------- защита от неверных данных ----------

    @Test
    void invalidRulesAndAdjustmentsAreRejected() {
        assertThrows(IllegalArgumentException.class, () -> new EffectRule(-1.0, 0, 0, 0, false));
        assertThrows(IllegalArgumentException.class, () -> new EffectRule(0, 0, 0, 1.5, false));
        assertThrows(IllegalArgumentException.class, () -> new MovementAdjust(0.0, 0, false, List.of()));
        assertThrows(IllegalArgumentException.class, () -> new DamageAdjust(0, -0.1, List.of()));
    }
}
