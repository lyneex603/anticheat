package ru.hexatime.astraguard.violation;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ConfidenceModelTest {

    @Test
    void decayReducesVlLinearly() {
        // 30 секунд при шаге 15 секунд и 1.0 за шаг = минус 2
        assertEquals(8.0, ConfidenceModel.decayedVl(10.0, 30_000, 1.0, 15.0), 1e-9);
    }

    @Test
    void decayNeverGoesBelowZero() {
        assertEquals(0.0, ConfidenceModel.decayedVl(3.0, 600_000, 1.0, 15.0), 1e-9);
    }

    @Test
    void noElapsedTimeMeansNoDecay() {
        assertEquals(5.0, ConfidenceModel.decayedVl(5.0, 0, 1.0, 15.0), 1e-9);
    }

    @Test
    void checkConfidenceIsCappedAtOne() {
        assertEquals(0.5, ConfidenceModel.checkConfidence(10.0, 20.0), 1e-9);
        assertEquals(1.0, ConfidenceModel.checkConfidence(50.0, 20.0), 1e-9);
        assertEquals(0.0, ConfidenceModel.checkConfidence(0.0, 20.0), 1e-9);
    }

    @Test
    void combinedConfidenceOfIndependentGroups() {
        assertEquals(0.75, ConfidenceModel.combined(List.of(0.5, 0.5)), 1e-9);
        assertEquals(0.0, ConfidenceModel.combined(List.of()), 1e-9);
        // три группы по 0.6 дают 0.936 — меньше порога автобана 0.95 по умолчанию
        assertTrue(ConfidenceModel.combined(List.of(0.6, 0.6, 0.6)) < 0.95);
        // три группы по 0.9 — выше порога
        assertTrue(ConfidenceModel.combined(List.of(0.9, 0.9, 0.9)) >= 0.95);
    }

    @Test
    void flagRequiresReasonAndPositiveWeight() {
        assertThrows(IllegalArgumentException.class,
                () -> Flag.of("Speed", "speed", CheckCategory.MOVEMENT, 1.0, " "));
        assertThrows(IllegalArgumentException.class,
                () -> Flag.of("Speed", "speed", CheckCategory.MOVEMENT, 0.0, "причина"));
        assertThrows(IllegalArgumentException.class,
                () -> Flag.of("", "speed", CheckCategory.MOVEMENT, 1.0, "причина"));
    }

    @Test
    void flagContextIsImmutableCopy() {
        Flag f = Flag.of("Reach", "reach", CheckCategory.COMBAT, 2.0, "дистанция 4.1").with("dist", 4.1);
        assertEquals(Map.of("dist", "4.1"), f.context());
        assertThrows(UnsupportedOperationException.class, () -> f.context().put("x", "y"));
        assertTrue(f.asTest().test());
    }
}
