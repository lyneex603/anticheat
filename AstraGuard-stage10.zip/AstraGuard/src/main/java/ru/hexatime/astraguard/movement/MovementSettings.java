package ru.hexatime.astraguard.movement;

import org.bukkit.configuration.file.FileConfiguration;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.combat.analysis.ControlClass;
import ru.hexatime.astraguard.movement.analysis.MoveThresholds;

import java.util.EnumMap;
import java.util.Map;

/** Настройки движения из config.yml. Кэшируются, перечитываются по /ag reload. */
public final class MovementSettings {

    private final AstraGuard plugin;
    private final Map<ControlClass, MoveThresholds> profiles = new EnumMap<>(ControlClass.class);
    private volatile boolean enabled = true;
    private volatile double minTps = 15.0;
    private volatile int timerMaxPing = 300;
    private volatile double probeJava = 0.05;
    private volatile double probeBedrock = 0.10;

    public MovementSettings(AstraGuard plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        FileConfiguration c = plugin.getConfig();
        enabled = c.getBoolean("movement.enabled", true);
        minTps = c.getDouble("movement.min-tps", 15.0);
        timerMaxPing = Math.max(50, c.getInt("movement.timer-max-ping", 300));
        probeJava = Math.max(0.0, c.getDouble("movement.ground-probe-java", 0.05));
        probeBedrock = Math.max(0.0, c.getDouble("movement.ground-probe-bedrock", 0.10));
        Map<ControlClass, MoveThresholds> fresh = new EnumMap<>(ControlClass.class);
        for (ControlClass cc : ControlClass.values()) {
            MoveThresholds d = MoveThresholds.defaults(cc);
            String p = "movement.profiles." + cc.key() + ".";
            fresh.put(cc, new MoveThresholds(
                    c.getDouble(p + "speed-eps", d.speedEps()),
                    c.getDouble(p + "vertical-tolerance", d.verticalTol()),
                    c.getBoolean(p + "ground-check", d.groundCheck()),
                    c.getDouble(p + "timer-limit-ms", d.timerLimitMs()),
                    c.getDouble(p + "timer-credit-ms", d.timerCreditMs())));
        }
        profiles.clear();
        profiles.putAll(fresh);
    }

    public MoveThresholds thresholds(ControlClass c) {
        MoveThresholds t = profiles.get(c);
        return t != null ? t : MoveThresholds.defaults(c);
    }

    public boolean enabled() {
        return enabled;
    }

    public double minTps() {
        return minTps;
    }

    public int timerMaxPing() {
        return timerMaxPing;
    }

    public double probe(boolean bedrock) {
        return bedrock ? probeBedrock : probeJava;
    }
}
