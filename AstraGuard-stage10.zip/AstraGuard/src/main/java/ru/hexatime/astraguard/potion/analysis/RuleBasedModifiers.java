package ru.hexatime.astraguard.potion.analysis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Модификаторы, заданные правилами из конфигурации: ключ эффекта → {@link EffectRule}. Так будущие кастомные зелья
 * подключаются без изменения кода. Пока правил нет (по умолчанию), ничего не меняется.
 */
public final class RuleBasedModifiers {

    private final Map<String, EffectRule> rules = new HashMap<>();

    public RuleBasedModifiers(Map<String, EffectRule> rules) {
        rules.forEach((k, v) -> this.rules.put(EffectState.normalize(k), v));
    }

    public boolean isEmpty() {
        return rules.isEmpty();
    }

    public CustomMovementModifier movement() {
        return active -> {
            double speed = 1.0;
            double jump = 0.0;
            boolean exempt = false;
            List<String> why = new ArrayList<>();
            for (EffectState e : active) {
                EffectRule r = rules.get(e.key());
                if (r == null) {
                    continue;
                }
                if (r.speedPerLevel() == 0.0 && r.jumpPerLevel() == 0.0 && !r.exemptMovement()) {
                    continue;
                }
                speed *= Math.max(0.01, 1.0 + r.speedPerLevel() * e.level());
                jump += r.jumpPerLevel() * e.level();
                exempt |= r.exemptMovement();
                why.add(e.describe());
            }
            return why.isEmpty() ? MovementAdjust.IDENTITY : new MovementAdjust(speed, jump, exempt, why);
        };
    }

    public CustomDamageModifier damage() {
        return active -> {
            double bonus = 0.0;
            double taken = 1.0;
            List<String> why = new ArrayList<>();
            for (EffectState e : active) {
                EffectRule r = rules.get(e.key());
                if (r == null || (r.attackBonusPerLevel() == 0.0 && r.damageReductionPerLevel() == 0.0)) {
                    continue;
                }
                bonus += r.attackBonusPerLevel() * e.level();
                taken *= Math.max(0.0, 1.0 - r.damageReductionPerLevel() * e.level());
                why.add(e.describe());
            }
            return why.isEmpty() ? DamageAdjust.IDENTITY : new DamageAdjust(bonus, taken, why);
        };
    }
}
