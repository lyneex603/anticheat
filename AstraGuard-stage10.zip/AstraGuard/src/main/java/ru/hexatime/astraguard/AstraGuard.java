package ru.hexatime.astraguard;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import ru.hexatime.astraguard.checks.CheckRegistry;
import ru.hexatime.astraguard.combat.CombatManager;
import ru.hexatime.astraguard.commands.AgCommand;
import ru.hexatime.astraguard.config.Settings;
import ru.hexatime.astraguard.enchant.DynamicEnchantmentAnalyzer;
import ru.hexatime.astraguard.database.Database;
import ru.hexatime.astraguard.movement.MovementManager;
import ru.hexatime.astraguard.evidence.EvidenceRecorder;
import ru.hexatime.astraguard.notify.AlertManager;
import ru.hexatime.astraguard.player.ProfileManager;
import ru.hexatime.astraguard.potion.PotionEffectAnalyzer;
import ru.hexatime.astraguard.punishment.PunishmentManager;
import ru.hexatime.astraguard.util.ServerHealth;
import ru.hexatime.astraguard.world.WorldManager;
import ru.hexatime.astraguard.violation.CheckCategory;
import ru.hexatime.astraguard.violation.ViolationManager;

import java.util.logging.Level;

/** AstraGuard — PvP-античит с поддержкой Bedrock (этапы 1–4, 9, 10: ядро, бой, движение, мир, зачарования, эффекты). */
public final class AstraGuard extends JavaPlugin {

    private Settings settings;
    private Database database;
    private CheckRegistry registry;
    private EvidenceRecorder evidence;
    private ProfileManager profiles;
    private AlertManager alerts;
    private ViolationManager violations;
    private PunishmentManager punishments;
    private CombatManager combat;
    private MovementManager movement;
    private WorldManager world;
    private ServerHealth health;
    private DynamicEnchantmentAnalyzer enchants;
    private PotionEffectAnalyzer potions;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = new Settings(this);
        database = new Database(this, settings);
        try {
            database.init();
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Не удалось подключить базу данных — плагин отключается", e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        registry = new CheckRegistry();
        registry.register(new CheckRegistry.CheckInfo("Test", "test", CheckCategory.SYSTEM,
                "Тестовая проверка для /ag test: проверяет оповещения и запись в БД, никогда не наказывает"));

        enchants = new DynamicEnchantmentAnalyzer(this);
        potions = new PotionEffectAnalyzer(this);
        evidence = new EvidenceRecorder();
        alerts = new AlertManager(settings);
        profiles = new ProfileManager(this);
        punishments = new PunishmentManager(this);
        violations = new ViolationManager(this);

        combat = new CombatManager(this);
        registerCombatChecks();
        health = new ServerHealth(this);
        health.start();
        movement = new MovementManager(this, health);
        registerMovementChecks();
        world = new WorldManager(this, health);
        registerWorldChecks();

        getServer().getPluginManager().registerEvents(profiles, this);
        getServer().getPluginManager().registerEvents(combat, this);
        getServer().getPluginManager().registerEvents(movement, this);
        getServer().getPluginManager().registerEvents(world, this);
        getServer().getPluginManager().registerEvents(punishments, this);

        AgCommand command = new AgCommand(this);
        PluginCommand pc = getCommand("ag");
        if (pc != null) {
            pc.setExecutor(command);
            pc.setTabCompleter(command);
        }
        getLogger().info("AstraGuard запущен. Floodgate: " + (profiles.floodgatePresent() ? "найден" : "не найден")
                + ". Срок бана: " + settings.banDays() + " дн.");
    }

    private void registerCombatChecks() {
        String[][] c = {
                {"AutoClicker-CPS", "combat-click", "Невозможный CPS (порог зависит от способа управления); слабый признак, нужен повтор"},
                {"AutoClicker-Pattern", "combat-click", "Почти одинаковые интервалы между кликами (в тиках сервера) при непрерывных кликах"},
                {"Reach", "combat-reach", "Дистанция удара больше допустимой с компенсацией пинга и профилем управления"},
                {"KillAura-Facing", "combat-killaura", "Повторные удары по цели далеко в стороне от взгляда"},
                {"KillAura-Switch", "combat-killaura", "Быстрые переключения между целями в разных направлениях"},
                {"InvalidHit-Wall", "combat-wall", "Удар сквозь сплошные блоки (заблокированы все лучи до хитбокса)"},
                {"AimAssist-Snap", "combat-aim", "Резкое наведение и точное попадание в центр цели (только Java и Bedrock-мышь)"},
                {"AimAssist-Lock", "combat-aim", "Прицел «приклеен» к движущейся цели (только Java и Bedrock-мышь)"},
                {"Rotation-Smooth", "combat-aim", "Поворот камеры с идеально постоянной скоростью (только Java и Bedrock-мышь)"},
                {"TriggerBot", "combat-trigger", "Удар в тот же или следующий тик после наведения, устойчиво (только Java и Bedrock-мышь)"}};
        for (String[] r : c) {
            registry.register(new CheckRegistry.CheckInfo(r[0], r[1], CheckCategory.COMBAT, r[2]));
        }
    }

    private void registerMovementChecks() {
        String[][] c = {
                {"Speed-Ground", "move-speed", "Скорость больше допустимой по модели физики (инерция, лёд, спринт-прыжок учтены)"},
                {"Speed-Air", "move-speed", "Горизонтальная скорость в воздухе выше, чем позволяют трение воздуха и разгон"},
                {"InvalidMove-Distance", "move-speed", "Невозможное смещение за один кадр без телепорта/отдачи/элитр/транспорта"},
                {"Fly-Gravity", "move-vertical", "Движение выше, чем позволяет гравитация (висение, подъём, слишком высокий прыжок)"},
                {"Spider-Climb", "move-vertical", "Подъём вдоль стены без лестницы, лианы или другого лазательного блока"},
                {"NoFall-Ground", "move-vertical", "Клиент говорит «на земле», а серверные коллизии опоры не находят (по умолчанию только Java)"},
                {"Jesus-Walk", "move-vertical", "Игрок держится на поверхности воды/лавы без опоры"},
                {"Timer", "move-timer", "Пакеты движения идут быстрее 20/с (слабый признак, нужен повтор)"}};
        for (String[] r : c) {
            registry.register(new CheckRegistry.CheckInfo(r[0], r[1], CheckCategory.MOVEMENT, r[2]));
        }
    }

    private void registerWorldChecks() {
        String[][] c = {
                {"FastBreak", "world-break", "Блок сломан быстрее эталона сервера (инструмент, Efficiency любого уровня, Haste и т.д.)"},
                {"FastPlace", "world-place-rate", "Невозможное число установок блоков в секунду"},
                {"Scaffold-Aim", "world-place-aim", "Блоки ставятся, а взгляд не проходит через блок-опору (только Java и Bedrock-мышь/геймпад)"},
                {"InvalidPlace-Face", "world-place-aim", "Блок поставлен на грань, обращённую от игрока"},
                {"InvalidInteract-Reach", "world-interact", "Взаимодействие с блоком дальше дальности из атрибута игрока"}};
        for (String[] r : c) {
            registry.register(new CheckRegistry.CheckInfo(r[0], r[1], CheckCategory.WORLD, r[2]));
        }
    }

    @Override
    public void onDisable() {
        if (database != null) {
            database.close();
        }
    }

    public Settings settings() {
        return settings;
    }

    public Database database() {
        return database;
    }

    public CheckRegistry registry() {
        return registry;
    }

    public EvidenceRecorder evidence() {
        return evidence;
    }

    public ProfileManager profiles() {
        return profiles;
    }

    public AlertManager alerts() {
        return alerts;
    }

    public ViolationManager violations() {
        return violations;
    }

    public CombatManager combat() {
        return combat;
    }

    public MovementManager movement() {
        return movement;
    }

    public WorldManager world() {
        return world;
    }

    public DynamicEnchantmentAnalyzer enchants() {
        return enchants;
    }

    public PotionEffectAnalyzer potions() {
        return potions;
    }

    public PunishmentManager punishments() {
        return punishments;
    }
}
