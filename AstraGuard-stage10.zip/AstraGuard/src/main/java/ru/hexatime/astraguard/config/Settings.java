package ru.hexatime.astraguard.config;

import org.bukkit.configuration.file.FileConfiguration;
import ru.hexatime.astraguard.AstraGuard;

import java.util.List;
import java.util.Locale;

/** Типизированный доступ к config.yml. Значения читаются при каждом обращении, поэтому /ag reload работает сразу. */
public final class Settings {

    /** Настройки одной проверки. */
    public record CheckSettings(boolean enabled, double maxVl, double decayAmount) {
    }

    private final AstraGuard plugin;

    public Settings(AstraGuard plugin) {
        this.plugin = plugin;
    }

    private FileConfiguration c() {
        return plugin.getConfig();
    }

    public void reload() {
        plugin.reloadConfig();
    }

    public boolean debug() {
        return c().getBoolean("debug", false);
    }

    // ---------------- база данных ----------------

    public String dbType() {
        return c().getString("database.type", "sqlite").toLowerCase(Locale.ROOT);
    }

    public String sqliteFile() {
        return c().getString("database.sqlite.file", "astraguard.db");
    }

    public String mysqlHost() {
        return c().getString("database.mysql.host", "127.0.0.1");
    }

    public int mysqlPort() {
        return c().getInt("database.mysql.port", 3306);
    }

    public String mysqlDatabase() {
        return c().getString("database.mysql.database", "astraguard");
    }

    public String mysqlUser() {
        return c().getString("database.mysql.user", "root");
    }

    public String mysqlPassword() {
        return c().getString("database.mysql.password", "");
    }

    // ---------------- нарушения ----------------

    public double decayAmount() {
        return Math.max(0.0, c().getDouble("violations.decay-amount", 1.0));
    }

    public double decaySeconds() {
        return Math.max(1.0, c().getDouble("violations.decay-seconds", 15.0));
    }

    public double defaultMaxVl() {
        return Math.max(1.0, c().getDouble("violations.default-max-vl", 20.0));
    }

    public CheckSettings check(String name) {
        String p = "checks." + name.toLowerCase(Locale.ROOT) + ".";
        return new CheckSettings(
                c().getBoolean(p + "enabled", true),
                Math.max(1.0, c().getDouble(p + "max-vl", defaultMaxVl())),
                Math.max(0.0, c().getDouble(p + "decay-amount", decayAmount())));
    }

    // ---------------- наказания ----------------

    public int banDays() {
        return Math.max(1, c().getInt("punishment.ban-days", 90));
    }

    public boolean autoBanEnabled() {
        return c().getBoolean("punishment.auto-ban.enabled", true);
    }

    public int minIndependentChecks() {
        return Math.max(1, c().getInt("punishment.auto-ban.min-independent-checks", 3));
    }

    public double minCheckConfidence() {
        return clamp01(c().getDouble("punishment.auto-ban.min-check-confidence", 0.6));
    }

    public double minCombinedConfidence() {
        return clamp01(c().getDouble("punishment.auto-ban.min-combined-confidence", 0.95));
    }

    public double warnConfidence() {
        return clamp01(c().getDouble("punishment.warn-confidence", 0.6));
    }

    public long warnCooldownMs() {
        return Math.max(0, c().getLong("punishment.warn-cooldown-seconds", 60)) * 1000L;
    }

    public String banScreen() {
        List<String> lines = c().getStringList("punishment.ban-screen");
        if (lines.isEmpty()) {
            return "&c&lВы заблокированы\n&7Причина: &f{reason}\n&7До: &f{until}";
        }
        return String.join("\n", lines);
    }

    // ---------------- оповещения ----------------

    public boolean alertsEnabled() {
        return c().getBoolean("alerts.enabled", true);
    }

    public long alertThrottleMs() {
        return Math.max(0, c().getLong("alerts.throttle-ms", 1000));
    }

    public String alertFormat() {
        return c().getString("alerts.format", "&c[AstraGuard] &f{player} &7» &c{check} &7VL {vl} ({reason})");
    }

    public String warnFormat() {
        return c().getString("alerts.warn-format", "&c[AstraGuard] &6Предупреждение: &f{player}");
    }

    public String banFormat() {
        return c().getString("alerts.ban-format", "&c[AstraGuard] &4БАН &f{player} &7до &f{until} — {reason}");
    }

    public String unbanFormat() {
        return c().getString("alerts.unban-format", "&c[AstraGuard] &aРазбан &f{player}");
    }

    private static double clamp01(double v) {
        return Math.max(0.0, Math.min(1.0, v));
    }
}
