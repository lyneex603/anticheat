package ru.hexatime.astraguard.geyser;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

/**
 * Сведения об установленном Geyser. AstraGuard не использует классы Geyser напрямую: всё, что нужно для проверок
 * (Bedrock или Java, способ управления, устройство, версия клиента), отдаёт Floodgate API. Здесь определяется только
 * наличие и версия Geyser, чтобы предупредить об опасной конфигурации «Geyser есть, а Floodgate нет»
 * (тогда все Bedrock-игроки были бы признаны Java и проверялись бы слишком строго).
 */
public final class GeyserInfo {

    private static final String[] NAMES = {"Geyser-Spigot", "Geyser-Paper", "Geyser"};

    private final Plugin plugin;

    public GeyserInfo() {
        Plugin found = null;
        for (String n : NAMES) {
            Plugin p = Bukkit.getPluginManager().getPlugin(n);
            if (p != null) {
                found = p;
                break;
            }
        }
        this.plugin = found;
    }

    public boolean present() {
        return plugin != null;
    }

    /** Версия Geyser из plugin.yml или «не найден». */
    public String version() {
        return plugin == null ? "не найден" : plugin.getPluginMeta().getVersion();
    }
}
