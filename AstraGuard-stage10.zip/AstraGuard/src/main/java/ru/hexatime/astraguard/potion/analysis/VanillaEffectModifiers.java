package ru.hexatime.astraguard.potion.analysis;

import java.util.List;

/**
 * Ванильные эффекты, которых НЕТ в атрибутах игрока, и поэтому их нужно учитывать отдельно:
 * Jump Boost (+0.1 к скорости прыжка за уровень) и Resistance (−20% получаемого урона за уровень, 5 уровень — полная защита).
 * <p>
 * Speed, Slowness, Strength, Weakness, Haste и Mining Fatigue в игре реализованы модификаторами атрибутов, поэтому
 * {@code Attribute#getValue()} уже содержит их влияние. Здесь они намеренно НЕ повторяются — иначе скорость и урон
 * были бы посчитаны дважды.
 */
public final class VanillaEffectModifiers {

    public static final String JUMP_BOOST = "minecraft:jump_boost";
    public static final String RESISTANCE = "minecraft:resistance";

    private VanillaEffectModifiers() {
    }

    public static CustomMovementModifier movement() {
        return active -> {
            for (EffectState e : active) {
                if (e.key().equals(JUMP_BOOST)) {
                    return new MovementAdjust(1.0, 0.1 * e.level(), false, List.of(e.describe()));
                }
            }
            return MovementAdjust.IDENTITY;
        };
    }

    public static CustomDamageModifier damage() {
        return active -> {
            for (EffectState e : active) {
                if (e.key().equals(RESISTANCE)) {
                    return new DamageAdjust(0.0, Math.max(0.0, 1.0 - 0.2 * e.level()), List.of(e.describe()));
                }
            }
            return DamageAdjust.IDENTITY;
        };
    }
}
