package ru.hexatime.astraguard.violation;

/** Категория проверки. */
public enum CheckCategory {
    COMBAT("Бой"),
    MOVEMENT("Движение"),
    WORLD("Мир"),
    PACKET("Пакеты"),
    SYSTEM("Система");

    private final String title;

    CheckCategory(String title) {
        this.title = title;
    }

    public String title() {
        return title;
    }

    public static CheckCategory parse(String s) {
        try {
            return valueOf(s);
        } catch (Exception e) {
            return SYSTEM;
        }
    }
}
