package ru.hexatime.astraguard.potion;

import org.bukkit.entity.Player;
import ru.hexatime.astraguard.potion.analysis.EffectState;

import java.util.List;

/**
 * Источник активных эффектов, которых нет среди обычных эффектов Bukkit (например, зелья другого плагина, хранящиеся
 * в своей структуре). Эффекты, зарегистрированные как настоящие {@code PotionEffectType}, подхватываются автоматически
 * и провайдера не требуют. Вызывается только из основного потока.
 */
public interface CustomPotionProvider {

    String id();

    /** Активные эффекты игрока из этого источника; пустой список, если их нет. */
    List<EffectState> read(Player player);
}
