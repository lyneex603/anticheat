package ru.hexatime.astraguard.violation;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Один «флаг» от проверки. Обязательно содержит реальную причину и вес — флагов «просто так» не бывает.
 *
 * @param check    название проверки, например "KillAura-Aim"
 * @param group    группа независимости: проверки одной группы (например, разные признаки KillAura)
 *                 считаются ОДНИМ подтверждением, а не несколькими
 * @param category категория
 * @param weight   на сколько растёт VL (должно быть больше 0)
 * @param reason   объяснение для администрации
 * @param context  данные события для базы доказательств
 * @param test     тестовый флаг: записывается и показывается, но никогда не наказывает
 */
public record Flag(String check, String group, CheckCategory category, double weight, String reason,
                   Map<String, String> context, boolean test) {

    public Flag {
        if (check == null || check.isBlank()) {
            throw new IllegalArgumentException("check must not be blank");
        }
        if (group == null || group.isBlank()) {
            throw new IllegalArgumentException("group must not be blank");
        }
        if (!(weight > 0.0)) {
            throw new IllegalArgumentException("weight must be > 0");
        }
        if (reason == null || reason.isBlank()) {
            throw new IllegalArgumentException("reason must not be blank");
        }
        context = context == null ? Map.of() : Map.copyOf(context);
    }

    public static Flag of(String check, String group, CheckCategory category, double weight, String reason) {
        return new Flag(check, group, category, weight, reason, Map.of(), false);
    }

    public Flag with(String key, Object value) {
        Map<String, String> m = new LinkedHashMap<>(context);
        m.put(key, String.valueOf(value));
        return new Flag(check, group, category, weight, reason, m, test);
    }

    public Flag asTest() {
        return new Flag(check, group, category, weight, reason, context, true);
    }
}
