package ru.hexatime.astraguard.enchant;

import org.bukkit.inventory.ItemStack;

import java.util.Map;

/**
 * Источник зачарований предмета. Точка расширения: чтобы поддержать зачарования другого плагина,
 * достаточно реализовать этот интерфейс и зарегистрировать его в {@link DynamicEnchantmentAnalyzer#register}.
 * Вызывается только из основного потока.
 */
public interface EnchantProvider {

    /** Короткое имя источника для отчётов. */
    String id();

    /** Ключ зачарования (например {@code minecraft:sharpness}) → уровень (> 0). Пустая карта, если ничего нет. */
    Map<String, Integer> read(ItemStack item);
}
