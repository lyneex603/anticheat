package ru.hexatime.astraguard.database;

import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.config.Settings;
import ru.hexatime.astraguard.evidence.Evidence;
import ru.hexatime.astraguard.player.PlayerProfile;
import ru.hexatime.astraguard.punishment.BanRecord;
import ru.hexatime.astraguard.violation.CheckCategory;
import ru.hexatime.astraguard.violation.Violation;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/**
 * База данных (SQLite или MySQL). Одно соединение, все обращения синхронизированы.
 * <p>
 * Из основного потока используйте {@link #async} и {@link #supply} — они выполняются в отдельном потоке.
 * Блокирующие методы (saveViolation, findActiveBan и т.д.) можно вызывать напрямую только из
 * асинхронных потоков, например из AsyncPlayerPreLoginEvent.
 */
public final class Database {

    @FunctionalInterface
    public interface SqlCall<T> {
        T call() throws SQLException;
    }

    @FunctionalInterface
    public interface SqlRun {
        void run() throws SQLException;
    }

    @FunctionalInterface
    private interface ConnFn<T> {
        T apply(Connection c) throws SQLException;
    }

    /** Строка таблицы players. */
    public record PlayerRow(UUID uuid, String name, String platform, String clientVersion, long firstSeen, long lastSeen) {
    }

    /** Запись истории наказаний. */
    public record HistoryEntry(String action, String reason, String actor, long time, long expiresAt) {
    }

    private final AstraGuard plugin;
    private final Settings settings;
    private final Object lock = new Object();
    private Connection conn;
    private boolean mysql;
    private ExecutorService executor;

    public Database(AstraGuard plugin, Settings settings) {
        this.plugin = plugin;
        this.settings = settings;
    }

    // ------------------------------------------------------------------ подключение

    public void init() throws SQLException {
        mysql = settings.dbType().equals("mysql");
        synchronized (lock) {
            connect();
            createTables();
        }
        executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "AstraGuard-DB");
            t.setDaemon(true);
            return t;
        });
        plugin.getLogger().info("База данных подключена: " + (mysql ? "MySQL" : "SQLite"));
    }

    private void connect() throws SQLException {
        try {
            if (mysql) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                String url = "jdbc:mysql://" + settings.mysqlHost() + ":" + settings.mysqlPort() + "/"
                        + settings.mysqlDatabase() + "?useSSL=false&characterEncoding=utf8&autoReconnect=true";
                conn = DriverManager.getConnection(url, settings.mysqlUser(), settings.mysqlPassword());
            } else {
                Class.forName("org.sqlite.JDBC");
                File file = new File(plugin.getDataFolder(), settings.sqliteFile());
                File parent = file.getParentFile();
                if (parent != null && !parent.exists() && !parent.mkdirs()) {
                    throw new SQLException("Не удалось создать папку " + parent);
                }
                conn = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
                try (Statement st = conn.createStatement()) {
                    st.execute("PRAGMA journal_mode=WAL");
                    st.execute("PRAGMA busy_timeout=5000");
                }
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("JDBC-драйвер не найден в сервере: " + e.getMessage(), e);
        }
    }

    private Connection connection() throws SQLException {
        if (conn == null || conn.isClosed() || (mysql && !conn.isValid(2))) {
            connect();
        }
        return conn;
    }

    private void createTables() throws SQLException {
        String pk = mysql ? "BIGINT PRIMARY KEY AUTO_INCREMENT" : "INTEGER PRIMARY KEY AUTOINCREMENT";
        try (Statement st = conn.createStatement()) {
            st.execute("CREATE TABLE IF NOT EXISTS players (uuid VARCHAR(36) PRIMARY KEY, name VARCHAR(40), "
                    + "platform VARCHAR(10), client_version VARCHAR(64), first_seen BIGINT, last_seen BIGINT)");
            st.execute("CREATE TABLE IF NOT EXISTS violations (id " + pk + ", uuid VARCHAR(36), name VARCHAR(40), "
                    + "check_name VARCHAR(48), grp VARCHAR(48), category VARCHAR(16), vl DOUBLE, confidence DOUBLE, "
                    + "reason TEXT, ts BIGINT, ping INT, tps DOUBLE, mspt DOUBLE, platform VARCHAR(10), "
                    + "client_version VARCHAR(64), test INT)");
            st.execute("CREATE TABLE IF NOT EXISTS evidence (id " + pk + ", violation_id BIGINT, uuid VARCHAR(36), "
                    + "name VARCHAR(40), check_name VARCHAR(48), ts BIGINT, vl DOUBLE, confidence DOUBLE, ping INT, "
                    + "tps DOUBLE, mspt DOUBLE, platform VARCHAR(10), client_version VARCHAR(64), "
                    + "context TEXT, trace TEXT)");
            st.execute("CREATE TABLE IF NOT EXISTS bans (id " + pk + ", uuid VARCHAR(36), name VARCHAR(40), "
                    + "reason TEXT, issued_by VARCHAR(40), issued_at BIGINT, expires_at BIGINT, active INT, "
                    + "removed_by VARCHAR(40), removed_at BIGINT)");
            st.execute("CREATE TABLE IF NOT EXISTS punish_history (id " + pk + ", uuid VARCHAR(36), name VARCHAR(40), "
                    + "action_type VARCHAR(16), reason TEXT, actor VARCHAR(40), ts BIGINT, expires_at BIGINT)");
        }
        for (String idx : new String[]{
                "CREATE INDEX idx_violations_uuid ON violations (uuid)",
                "CREATE INDEX idx_evidence_uuid ON evidence (uuid)",
                "CREATE INDEX idx_bans_uuid ON bans (uuid)",
                "CREATE INDEX idx_history_uuid ON punish_history (uuid)"}) {
            try (Statement st = conn.createStatement()) {
                st.execute(idx);
            } catch (SQLException ignored) {
                // индекс уже существует
            }
        }
    }

    // ------------------------------------------------------------------ выполнение

    private <T> T withConn(ConnFn<T> fn) throws SQLException {
        synchronized (lock) {
            return fn.apply(connection());
        }
    }

    /** Выполняет запись в БД в отдельном потоке; ошибки пишутся в лог. */
    public void async(SqlRun run) {
        ExecutorService ex = executor;
        if (ex == null || ex.isShutdown()) {
            return;
        }
        ex.execute(() -> {
            try {
                run.run();
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Ошибка записи в БД", e);
                if (plugin.discord() != null) {
                    plugin.discord().critical("Ошибка записи в базу данных", e);
                }
            }
        });
    }

    /** Выполняет запрос в отдельном потоке и возвращает результат через CompletableFuture. */
    public <T> CompletableFuture<T> supply(SqlCall<T> call) {
        ExecutorService ex = executor;
        if (ex == null || ex.isShutdown()) {
            return CompletableFuture.failedFuture(new IllegalStateException("База данных остановлена"));
        }
        return CompletableFuture.supplyAsync(() -> {
            try {
                return call.call();
            } catch (SQLException e) {
                throw new CompletionException(e);
            }
        }, ex);
    }

    public void close() {
        if (executor != null) {
            executor.shutdown();
            try {
                if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
                Thread.currentThread().interrupt();
            }
        }
        synchronized (lock) {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Ошибка закрытия БД", e);
            }
        }
    }

    // ------------------------------------------------------------------ игроки

    public void savePlayer(PlayerProfile p) throws SQLException {
        long now = System.currentTimeMillis();
        withConn(c -> {
            try (PreparedStatement up = c.prepareStatement(
                    "UPDATE players SET name=?, platform=?, client_version=?, last_seen=? WHERE uuid=?")) {
                up.setString(1, p.name());
                up.setString(2, p.platform().name());
                up.setString(3, p.clientVersion());
                up.setLong(4, now);
                up.setString(5, p.uuid().toString());
                if (up.executeUpdate() > 0) {
                    return null;
                }
            }
            try (PreparedStatement ins = c.prepareStatement(
                    "INSERT INTO players (uuid, name, platform, client_version, first_seen, last_seen) VALUES (?,?,?,?,?,?)")) {
                ins.setString(1, p.uuid().toString());
                ins.setString(2, p.name());
                ins.setString(3, p.platform().name());
                ins.setString(4, p.clientVersion());
                ins.setLong(5, now);
                ins.setLong(6, now);
                ins.executeUpdate();
            }
            return null;
        });
    }

    public PlayerRow getPlayer(UUID uuid) throws SQLException {
        return withConn(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT uuid, name, platform, client_version, first_seen, last_seen FROM players WHERE uuid=?")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        return new PlayerRow(UUID.fromString(rs.getString(1)), rs.getString(2), rs.getString(3),
                                rs.getString(4), rs.getLong(5), rs.getLong(6));
                    }
                    return null;
                }
            }
        });
    }

    /** Ищет UUID по нику среди игроков и банов (без обращения к Mojang). */
    public UUID resolveUuid(String name) throws SQLException {
        return withConn(c -> {
            for (String sql : new String[]{
                    "SELECT uuid FROM players WHERE LOWER(name)=LOWER(?) ORDER BY last_seen DESC LIMIT 1",
                    "SELECT uuid FROM bans WHERE LOWER(name)=LOWER(?) ORDER BY id DESC LIMIT 1"}) {
                try (PreparedStatement ps = c.prepareStatement(sql)) {
                    ps.setString(1, name);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            return UUID.fromString(rs.getString(1));
                        }
                    }
                }
            }
            return null;
        });
    }

    // ------------------------------------------------------------------ нарушения и доказательства

    public long saveViolation(Violation v, Evidence ev) throws SQLException {
        return withConn(c -> {
            long id = 0;
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO violations (uuid, name, check_name, grp, category, vl, confidence, reason, ts, ping, "
                            + "tps, mspt, platform, client_version, test) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, v.uuid().toString());
                ps.setString(2, v.name());
                ps.setString(3, v.check());
                ps.setString(4, v.group());
                ps.setString(5, v.category().name());
                ps.setDouble(6, v.vl());
                ps.setDouble(7, v.confidence());
                ps.setString(8, v.reason());
                ps.setLong(9, v.time());
                ps.setInt(10, v.ping());
                ps.setDouble(11, v.tps());
                ps.setDouble(12, v.mspt());
                ps.setString(13, v.platform());
                ps.setString(14, v.clientVersion());
                ps.setInt(15, v.test() ? 1 : 0);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        id = rs.getLong(1);
                    }
                }
            }
            if (ev != null) {
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO evidence (violation_id, uuid, name, check_name, ts, vl, confidence, ping, tps, mspt, "
                                + "platform, client_version, context, trace) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)")) {
                    ps.setLong(1, id);
                    ps.setString(2, ev.uuid().toString());
                    ps.setString(3, ev.name());
                    ps.setString(4, ev.check());
                    ps.setLong(5, ev.time());
                    ps.setDouble(6, ev.vl());
                    ps.setDouble(7, ev.confidence());
                    ps.setInt(8, ev.ping());
                    ps.setDouble(9, ev.tps());
                    ps.setDouble(10, ev.mspt());
                    ps.setString(11, ev.platform());
                    ps.setString(12, ev.clientVersion());
                    ps.setString(13, ev.context());
                    ps.setString(14, ev.trace());
                    ps.executeUpdate();
                }
            }
            return id;
        });
    }

    public List<Violation> listViolations(UUID uuid, int limit, CheckCategory category) throws SQLException {
        return withConn(c -> {
            String sql = "SELECT id, uuid, name, check_name, grp, category, vl, confidence, reason, ts, ping, tps, mspt, "
                    + "platform, client_version, test FROM violations WHERE uuid=?"
                    + (category != null ? " AND category=?" : "") + " ORDER BY id DESC LIMIT ?";
            List<Violation> out = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                int i = 1;
                ps.setString(i++, uuid.toString());
                if (category != null) {
                    ps.setString(i++, category.name());
                }
                ps.setInt(i, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        out.add(new Violation(rs.getLong(1), UUID.fromString(rs.getString(2)), rs.getString(3),
                                rs.getString(4), rs.getString(5), CheckCategory.parse(rs.getString(6)),
                                rs.getDouble(7), rs.getDouble(8), rs.getString(9), rs.getLong(10), rs.getInt(11),
                                rs.getDouble(12), rs.getDouble(13), rs.getString(14), rs.getString(15),
                                rs.getInt(16) == 1));
                    }
                }
            }
            return out;
        });
    }

    public int countViolations(UUID uuid) throws SQLException {
        return withConn(c -> {
            try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM violations WHERE uuid=? AND test=0")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? rs.getInt(1) : 0;
                }
            }
        });
    }

    public List<Evidence> listEvidence(UUID uuid, int limit) throws SQLException {
        return withConn(c -> {
            List<Evidence> out = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT uuid, name, check_name, ts, vl, confidence, ping, tps, mspt, platform, client_version, "
                            + "context, trace FROM evidence WHERE uuid=? ORDER BY id DESC LIMIT ?")) {
                ps.setString(1, uuid.toString());
                ps.setInt(2, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        out.add(new Evidence(UUID.fromString(rs.getString(1)), rs.getString(2), rs.getString(3),
                                rs.getLong(4), rs.getDouble(5), rs.getDouble(6), rs.getInt(7), rs.getDouble(8),
                                rs.getDouble(9), rs.getString(10), rs.getString(11),
                                nvl(rs.getString(12)), nvl(rs.getString(13))));
                    }
                }
            }
            return out;
        });
    }

    private static String nvl(String s) {
        return s == null ? "" : s;
    }

    // ------------------------------------------------------------------ баны

    private static BanRecord mapBan(ResultSet rs) throws SQLException {
        return new BanRecord(rs.getLong(1), UUID.fromString(rs.getString(2)), rs.getString(3), rs.getString(4),
                rs.getString(5), rs.getLong(6), rs.getLong(7), rs.getInt(8) == 1, rs.getString(9), rs.getLong(10));
    }

    private static final String BAN_COLUMNS =
            "id, uuid, name, reason, issued_by, issued_at, expires_at, active, removed_by, removed_at";

    /** Активный бан игрока (даже если срок уже прошёл — вызывающий код сам снимает истёкшие). */
    public BanRecord findActiveBan(UUID uuid) throws SQLException {
        return withConn(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT " + BAN_COLUMNS + " FROM bans WHERE uuid=? AND active=1 ORDER BY id DESC LIMIT 1")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? mapBan(rs) : null;
                }
            }
        });
    }

    /** Последний бан игрока: активный или уже снятый. */
    public BanRecord findLatestBan(UUID uuid) throws SQLException {
        return withConn(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT " + BAN_COLUMNS + " FROM bans WHERE uuid=? ORDER BY id DESC LIMIT 1")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? mapBan(rs) : null;
                }
            }
        });
    }

    public long insertBan(BanRecord b) throws SQLException {
        return withConn(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO bans (uuid, name, reason, issued_by, issued_at, expires_at, active) VALUES (?,?,?,?,?,?,1)",
                    Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, b.uuid().toString());
                ps.setString(2, b.name());
                ps.setString(3, b.reason());
                ps.setString(4, b.issuedBy());
                ps.setLong(5, b.issuedAt());
                ps.setLong(6, b.expiresAt());
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    return rs.next() ? rs.getLong(1) : 0L;
                }
            }
        });
    }

    public void deactivateBan(long id, String by, long now) throws SQLException {
        withConn(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE bans SET active=0, removed_by=?, removed_at=? WHERE id=?")) {
                ps.setString(1, by);
                ps.setLong(2, now);
                ps.setLong(3, id);
                ps.executeUpdate();
            }
            return null;
        });
    }

    /** Снимает истёкший бан и пишет запись в историю. */
    public void expireBan(BanRecord b, long now) throws SQLException {
        deactivateBan(b.id(), "EXPIRED", now);
        addHistory(b.uuid(), b.name(), "EXPIRE", "срок бана истёк", "AstraGuard", now, b.expiresAt());
    }

    public List<BanRecord> listActiveBans(int limit, long now) throws SQLException {
        return withConn(c -> {
            List<BanRecord> out = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT " + BAN_COLUMNS + " FROM bans WHERE active=1 AND expires_at>? ORDER BY id DESC LIMIT ?")) {
                ps.setLong(1, now);
                ps.setInt(2, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        out.add(mapBan(rs));
                    }
                }
            }
            return out;
        });
    }

    // ------------------------------------------------------------------ история наказаний

    public void addHistory(UUID uuid, String name, String action, String reason, String actor,
                           long time, long expiresAt) throws SQLException {
        withConn(c -> {
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO punish_history (uuid, name, action_type, reason, actor, ts, expires_at) VALUES (?,?,?,?,?,?,?)")) {
                ps.setString(1, uuid.toString());
                ps.setString(2, name);
                ps.setString(3, action);
                ps.setString(4, reason);
                ps.setString(5, actor);
                ps.setLong(6, time);
                ps.setLong(7, expiresAt);
                ps.executeUpdate();
            }
            return null;
        });
    }

    public List<HistoryEntry> listHistory(UUID uuid, int limit) throws SQLException {
        return withConn(c -> {
            List<HistoryEntry> out = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT action_type, reason, actor, ts, expires_at FROM punish_history WHERE uuid=? ORDER BY id DESC LIMIT ?")) {
                ps.setString(1, uuid.toString());
                ps.setInt(2, limit);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        out.add(new HistoryEntry(rs.getString(1), rs.getString(2), rs.getString(3),
                                rs.getLong(4), rs.getLong(5)));
                    }
                }
            }
            return out;
        });
    }
}
