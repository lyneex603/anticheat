package ru.hexatime.astraguard.movement.analysis;

import ru.hexatime.astraguard.combat.analysis.Finding;

/** Jesus-Walk. Игрок держится на поверхности жидкости без опоры и без вертикального движения 8+ кадров подряд. */
public final class JesusAnalyzer {

    private static final int LIMIT = 8;

    private int frames;

    public void reset() {
        frames = 0;
    }

    public Finding onFrame(MoveFrame f) {
        if (f.discontinuity() || f.altered() || f.serverGround() || !f.surfaceLiquid()
                || Math.abs(f.dy()) > 0.05) {
            frames = 0;
            return null;
        }
        frames++;
        if (frames < LIMIT) {
            return null;
        }
        frames = LIMIT / 2;
        return Finding.of("Jesus-Walk", "move-vertical", 1.0,
                "игрок удерживается на поверхности жидкости без опоры (dy≈0 несколько кадров подряд)",
                "dy", String.format("%.3f", f.dy()), "speed", String.format("%.3f", f.horizontal()));
    }
}
