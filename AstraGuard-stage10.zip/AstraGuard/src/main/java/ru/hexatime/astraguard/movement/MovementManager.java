package ru.hexatime.astraguard.movement;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.player.PlayerElytraBoostEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerRiptideEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.combat.analysis.ControlClass;
import ru.hexatime.astraguard.combat.analysis.Finding;
import ru.hexatime.astraguard.movement.analysis.*;
import ru.hexatime.astraguard.player.PlayerProfile;
import ru.hexatime.astraguard.potion.analysis.MovementAdjust;
import ru.hexatime.astraguard.util.ServerHealth;
import ru.hexatime.astraguard.violation.CheckCategory;
import ru.hexatime.astraguard.violation.Flag;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Проверки движения. Данные собираются из событий в основном потоке; анализаторы — чистая математика.
 * <p>
 * Принцип: когда причина движения неизвестна или легальна (телепорт, отдача, взрыв, поршень, элитры, транспорт,
 * жидкость, лестница...), игрок НЕ проверяется, а базовые значения сбрасываются — вместо ложного флага.
 * Окно после отдачи/телепорта = 300 мс + 1.5 × пинг (пакет идёт к клиенту и обратно).
 * <p>
 * Ограничения (честно): PlayerMoveEvent приходит только при изменении позиции/поворота, поэтому полностью неподвижное
 * зависание без поворота камеры не видно; для этого нужен пакетный уровень (отдельный этап).
 */
public final class MovementManager implements Listener {

    private static final long MAX_GAP_MS = 100;

    private static final class State {
        final SpeedAnalyzer speed = new SpeedAnalyzer();
        final FlyAnalyzer fly = new FlyAnalyzer();
        final GroundAnalyzer ground = new GroundAnalyzer();
        final JesusAnalyzer jesus = new JesusAnalyzer();
        final DistanceAnalyzer distance = new DistanceAnalyzer();
        final TimerAnalyzer timer = new TimerAnalyzer();
        final ControlClass control;
        boolean haveLast;
        long lastMs;
        double lastX;
        double lastY;
        double lastZ;
        long exemptUntil;

        State(ControlClass control) {
            this.control = control;
        }

        void resetPhysics() {
            speed.reset();
            fly.reset();
            ground.reset();
            jesus.reset();
            distance.reset();
            haveLast = false;
        }
    }

    private final AstraGuard plugin;
    private final MovementSettings settings;
    private final TerrainScanner scanner = new TerrainScanner();
    private final Map<UUID, State> states = new HashMap<>();
    private final Attribute movementSpeed;
    private final Attribute jumpStrength;
    private final Attribute gravity;

    private final ServerHealth health;

    public MovementManager(AstraGuard plugin, ServerHealth health) {
        this.plugin = plugin;
        this.health = health;
        this.settings = new MovementSettings(plugin);
        this.movementSpeed = lookup("movement_speed");
        this.jumpStrength = lookup("jump_strength");
        this.gravity = lookup("gravity");
    }

    private Attribute lookup(String key) {
        try {
            Attribute a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft(key));
            if (a == null) {
                plugin.getLogger().warning("Атрибут " + key + " не найден — будет использовано значение по умолчанию");
            }
            return a;
        } catch (Throwable t) {
            plugin.getLogger().warning("Атрибут " + key + " недоступен: " + t);
            return null;
        }
    }

    private static double attr(Player p, Attribute a, double fallback) {
        if (a == null) {
            return fallback;
        }
        AttributeInstance inst = p.getAttribute(a);
        return inst == null ? fallback : inst.getValue();
    }

    public void reload() {
        settings.reload();
    }

    public MovementSettings settings() {
        return settings;
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> {
            PlayerProfile pr = plugin.profiles().get(p);
            return new State(ControlClass.of(pr.isBedrock(), pr.inputMode()));
        });
    }

    private void exemptFor(Player p, long baseMs) {
        State st = state(p);
        long window = baseMs + Math.min(2500L, (long) (p.getPing() * 1.5));
        st.exemptUntil = Math.max(st.exemptUntil, nowMs() + window);
    }

    private static long nowMs() {
        return System.nanoTime() / 1_000_000L;
    }

    // ---------------- события, объясняющие легальное изменение движения ----------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        exemptFor(e.getPlayer(), 2000);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        exemptFor(e.getPlayer(), 300);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent e) {
        exemptFor(e.getPlayer(), 1000);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onVelocity(PlayerVelocityEvent e) {
        exemptFor(e.getPlayer(), 300);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onGameMode(PlayerGameModeChangeEvent e) {
        exemptFor(e.getPlayer(), 1000);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onToggleFlight(PlayerToggleFlightEvent e) {
        exemptFor(e.getPlayer(), 1500);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onGlide(EntityToggleGlideEvent e) {
        if (e.getEntity() instanceof Player p) {
            exemptFor(p, 1500);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRiptide(PlayerRiptideEvent e) {
        exemptFor(e.getPlayer(), 2000);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onElytraBoost(PlayerElytraBoostEvent e) {
        exemptFor(e.getPlayer(), 1500);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onVehicleExit(VehicleExitEvent e) {
        if (e.getExited() instanceof Player p) {
            exemptFor(p, 800);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        exemptNear(e.getLocation(), 16.0, 1000);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        exemptNear(e.getBlock().getLocation(), 16.0, 1000);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent e) {
        exemptNear(e.getBlock().getLocation(), 8.0, 500);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent e) {
        exemptNear(e.getBlock().getLocation(), 8.0, 500);
    }

    private void exemptNear(Location loc, double radius, long baseMs) {
        for (Player p : loc.getWorld().getNearbyPlayers(loc, radius)) {
            exemptFor(p, baseMs);
        }
    }

    // ---------------- основной обработчик ----------------

    /** Игрок сейчас не проверяется (легальные причины нестандартного движения). */
    private boolean exempt(Player p, State st, long now) {
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR || p.isDead() || p.isSleeping()
                || p.getAllowFlight() || p.isFlying()) {
            return true;
        }
        if (p.isInsideVehicle()) {
            st.exemptUntil = Math.max(st.exemptUntil, now + 800);
            return true;
        }
        if (p.isGliding() || p.isRiptiding()) {
            st.exemptUntil = Math.max(st.exemptUntil, now + 1500);
            return true;
        }
        return now < st.exemptUntil;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!settings.enabled()) {
            return;
        }
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null || from.getWorld() != to.getWorld()) {
            return;
        }
        Player p = e.getPlayer();
        State st = state(p);
        long now = nowMs();
        MoveThresholds th = settings.thresholds(st.control);
        boolean healthy = health.tps() >= settings.minTps();
        MovementAdjust fx = plugin.potions().movement(p);
        if (fx.exempt()) {
            st.exemptUntil = Math.max(st.exemptUntil, now + 1500); // рывок/отбрасывание от эффекта: физика не описывает
        }
        boolean exempt = exempt(p, st, now);

        // Timer: считает все пакеты движения, но не при лагах сервера, высоком пинге и сразу после остановки сервера
        if (!exempt && healthy && !health.stalledWithin(now, 3000) && p.getPing() <= settings.timerMaxPing()) {
            emit(p, st, st.timer.onFrame(now, th), false);
        } else {
            st.timer.reset();
        }

        boolean continuous = st.haveLast && now - st.lastMs <= MAX_GAP_MS
                && Math.abs(from.getX() - st.lastX) < 0.05 && Math.abs(from.getY() - st.lastY) < 0.05
                && Math.abs(from.getZ() - st.lastZ) < 0.05;
        st.lastMs = now;
        st.lastX = to.getX();
        st.lastY = to.getY();
        st.lastZ = to.getZ();
        if (exempt || !healthy) {
            st.resetPhysics();
            return;
        }
        boolean wasLast = st.haveLast;
        st.haveLast = true;

        PlayerProfile pr = plugin.profiles().get(p);
        TerrainScanner.Scan sc = scanner.scan(p, to, settings.probe(pr.isBedrock()));
        if (!sc.loaded()) {
            st.resetPhysics();
            return;
        }

        double sp = attr(p, movementSpeed, 0.1);
        if (!p.isSprinting()) {
            sp *= 1.3; // допускаем спринт: порядок пакетов «спринт»/«движение» может отличаться на тик
        }
        sp *= Math.max(1.0, p.getWalkSpeed() / 0.2);
        sp *= fx.speedMultiplier();
        double jump = attr(p, jumpStrength, 0.42) + fx.extraJump(); // Jump Boost и кастомные эффекты
        boolean altered = sc.altered() || p.hasPotionEffect(PotionEffectType.LEVITATION);
        MoveFrame frame = new MoveFrame(now, to.getX() - from.getX(), to.getY() - from.getY(),
                to.getZ() - from.getZ(), !(continuous && wasLast), sc.serverGround(), p.isOnGround(), sc.slip(),
                altered, sc.nearWall(), sc.surfaceLiquid(), sp, jump, attr(p, gravity, 0.08),
                p.hasPotionEffect(PotionEffectType.SLOW_FALLING));

        emit(p, st, st.speed.onFrame(frame, th), true);
        emit(p, st, st.fly.onFrame(frame, th), true);
        emit(p, st, st.ground.onFrame(frame, th), true);
        emit(p, st, st.jesus.onFrame(frame), true);
        emit(p, st, st.distance.onFrame(frame), false);
    }

    /**
     * Рядом живые существа/транспорт могут толкать игрока или служить опорой (лодка, шалкер) — тогда нарушение
     * не фиксируется. Проверка выполняется только когда нарушение уже найдено, поэтому дёшево.
     */
    private boolean entityNearby(Player p) {
        BoundingBox b = p.getBoundingBox().expand(1.0, 0.6, 1.0);
        return !p.getWorld().getNearbyEntities(b, (Entity en) -> en != p
                && (en instanceof LivingEntity || en instanceof Vehicle)
                && !(en instanceof Player sp && sp.getGameMode() == GameMode.SPECTATOR)).isEmpty();
    }

    private void emit(Player p, State st, Finding f, boolean checkEntities) {
        if (f == null) {
            return;
        }
        if (checkEntities && entityNearby(p)) {
            st.resetPhysics();
            return;
        }
        Flag flag = Flag.of(f.check(), f.group(), CheckCategory.MOVEMENT, f.weight(), f.reason());
        for (Map.Entry<String, String> en : f.data().entrySet()) {
            flag = flag.with(en.getKey(), en.getValue());
        }
        flag = flag.with("control", st.control.key())
                .with("tps", String.format("%.2f", health.tps()))
                .with("mspt", String.format("%.1f", health.mspt()));
        plugin.violations().flag(p, flag);
    }
}
