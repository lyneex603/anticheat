package ru.hexatime.astraguard.combat.analysis;

import java.util.Locale;

/**
 * Класс управления игрока. У каждого свой профиль порогов: нельзя мерить мобильного игрока
 * по меркам Java-мыши. Для Bedrock берётся из Floodgate (InputMode), для Java — всегда JAVA.
 */
public enum ControlClass {
    JAVA, BEDROCK_KBM, BEDROCK_TOUCH, BEDROCK_CONTROLLER, BEDROCK_UNKNOWN;

    public static ControlClass of(boolean bedrock, String inputMode) {
        if (!bedrock) {
            return JAVA;
        }
        String m = inputMode == null ? "" : inputMode.toUpperCase(Locale.ROOT);
        return switch (m) {
            case "KEYBOARD_MOUSE" -> BEDROCK_KBM;
            case "TOUCH" -> BEDROCK_TOUCH;
            case "CONTROLLER" -> BEDROCK_CONTROLLER;
            default -> BEDROCK_UNKNOWN;
        };
    }

    /** Ключ секции в config.yml: combat.profiles.<key>. */
    public String key() {
        return name().toLowerCase(Locale.ROOT).replace('_', '-');
    }
}
