package ru.hexatime.astraguard.enchant;

import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.enchant.analysis.EnchantMath;
import ru.hexatime.astraguard.enchant.analysis.EnchantMath.Cause;
import ru.hexatime.astraguard.enchant.analysis.EnchantSnapshot;
import ru.hexatime.astraguard.violation.CheckCategory;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;

/**
 * Анализ реальных характеристик предметов с учётом кастомных уровней зачарований (Sharpness VI–VII,
 * Protection IV–V, Unbreaking IV–V, Efficiency VI–X и любых других).
 * <p>
 * Что делает: читает зачарования через {@link EnchantProvider}, считает по формулам {@link EnchantMath}
 * влияние на урон, защиту, прочность и скорость ломания, прикладывает снаряжение к доказательствам боевых и мировых
 * нарушений и печатает отчёт для {@code /ag enchant}.
 * <p>
 * Чего НЕ делает (честно): не выносит решений о нарушении. Ни одна проверка не считает высокий уровень
 * зачарования подозрительным, а FastBreak берёт эталон у сервера, который сам учитывает любой уровень Efficiency.
 * Работает только в основном потоке: читает инвентарь игрока.
 */
public final class DynamicEnchantmentAnalyzer {

    private final AstraGuard plugin;
    private final List<EnchantProvider> providers = new CopyOnWriteArrayList<>();
    private final EnchantProvider vanilla = new VanillaEnchantProvider();
    private volatile EnchantProvider pdc = new PdcEnchantProvider(List.of());
    private volatile boolean enabled = true;
    private volatile boolean recordInEvidence = true;
    private volatile double sampleDamage = 10.0;

    public DynamicEnchantmentAnalyzer(AstraGuard plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        enabled = plugin.getConfig().getBoolean("enchantments.enabled", true);
        recordInEvidence = plugin.getConfig().getBoolean("enchantments.record-in-evidence", true);
        sampleDamage = Math.max(1.0, plugin.getConfig().getDouble("enchantments.sample-damage", 10.0));
        List<NamespacedKey> keys = new ArrayList<>();
        for (String s : plugin.getConfig().getStringList("enchantments.pdc-keys")) {
            NamespacedKey k = NamespacedKey.fromString(s.trim().toLowerCase(Locale.ROOT));
            if (k == null) {
                plugin.getLogger().warning("enchantments.pdc-keys: некорректный ключ «" + s + "», пропущен");
            } else {
                keys.add(k);
            }
        }
        pdc = new PdcEnchantProvider(keys);
    }

    /** Подключает дополнительный источник зачарований (например, для другого плагина). */
    public void register(EnchantProvider provider) {
        providers.add(provider);
    }

    public boolean enabled() {
        return enabled;
    }

    // ---------------- чтение предметов ----------------

    private static boolean empty(ItemStack item) {
        return item == null || item.getType().isAir();
    }

    /** Зачарования предмета из всех источников; при совпадении ключей берётся больший уровень. */
    public EnchantSnapshot snapshot(ItemStack item) {
        if (empty(item)) {
            return EnchantSnapshot.EMPTY;
        }
        EnchantSnapshot result = read(vanilla, item).mergedWith(read(pdc, item));
        for (EnchantProvider p : providers) {
            result = result.mergedWith(read(p, item));
        }
        return result;
    }

    private EnchantSnapshot read(EnchantProvider p, ItemStack item) {
        try {
            return new EnchantSnapshot(p.read(item));
        } catch (RuntimeException e) {
            plugin.getLogger().log(Level.WARNING, "Источник зачарований «" + p.id() + "» выдал ошибку", e);
            return EnchantSnapshot.EMPTY;
        }
    }

    /** Зачарования надетой брони (пустые слоты дают пустые наборы), 4 элемента. */
    public List<EnchantSnapshot> armor(Player p) {
        List<EnchantSnapshot> out = new ArrayList<>(4);
        for (ItemStack piece : p.getInventory().getArmorContents()) {
            out.add(snapshot(piece));
        }
        return out;
    }

    private static String typeName(ItemStack item) {
        return empty(item) ? "пусто" : item.getType().getKey().getKey();
    }

    private static double attribute(Player p, String key) {
        try {
            Attribute a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft(key));
            AttributeInstance inst = a == null ? null : p.getAttribute(a);
            return inst == null ? Double.NaN : inst.getValue();
        } catch (Throwable t) {
            return Double.NaN;
        }
    }

    // ---------------- доказательства ----------------

    /**
     * Дополнительные поля для доказательства нарушения: оружие и броня (бой) или инструмент (мир).
     * Для движения и системных проверок ничего не добавляется. Вызывается только при флаге, не постоянно.
     */
    public Map<String, String> evidenceContext(Player p, CheckCategory category) {
        Map<String, String> m = new LinkedHashMap<>();
        if (!enabled || !recordInEvidence) {
            return m;
        }
        try {
            if (category == CheckCategory.COMBAT) {
                ItemStack hand = p.getInventory().getItemInMainHand();
                m.put("weapon", typeName(hand) + " [" + snapshot(hand).describe() + "]");
                m.put("armor", armorSummary(armor(p)));
            } else if (category == CheckCategory.WORLD) {
                ItemStack hand = p.getInventory().getItemInMainHand();
                EnchantSnapshot s = snapshot(hand);
                m.put("tool", typeName(hand) + " [" + s.describe() + "]");
                m.put("efficiencyBonus", "+" + EnchantMath.efficiencyBonus(EnchantMath.efficiencyLevel(s)));
            }
        } catch (RuntimeException e) {
            plugin.getLogger().log(Level.WARNING, "Не удалось прочитать снаряжение для доказательства", e);
        }
        return m;
    }

    private static String armorSummary(List<EnchantSnapshot> armor) {
        int points = EnchantMath.totalProtectionPoints(armor, Cause.GENERIC);
        StringBuilder sb = new StringBuilder();
        for (EnchantSnapshot piece : armor) {
            if (sb.length() > 0) {
                sb.append("; ");
            }
            sb.append(piece.describe());
        }
        return "protection=" + points + "/20 (-" + Math.round(100.0 * (1.0 - EnchantMath.enchantDamageFactor(points)))
                + "%) {" + sb + "}";
    }

    // ---------------- отчёт для /ag enchant ----------------

    /** Строки отчёта о снаряжении игрока (с цветовыми кодами &). */
    public List<String> report(Player p) {
        List<String> out = new ArrayList<>();
        ItemStack hand = p.getInventory().getItemInMainHand();
        EnchantSnapshot held = snapshot(hand);

        out.add("&7В руке: &f" + typeName(hand));
        out.add("&7  зачарования: &f" + levelsWithMarks(held));
        List<String> keys = empty(hand) ? List.of() : PdcEnchantProvider.discoverKeys(hand);
        out.add("&7  ключи PersistentData: &f" + (keys.isEmpty() ? "нет" : String.join(", ", keys)));
        if (!keys.isEmpty()) {
            out.add("&8  (ключи своих зачарований вписываются в enchantments.pdc-keys)");
        }

        int sharp = held.level("sharpness");
        double attack = attribute(p, "attack_damage");
        out.add("&7Урон: &fатрибут " + fmt(attack) + " &7+ Sharpness " + EnchantSnapshot.roman(sharp) + " = &f+"
                + fmt(EnchantMath.sharpnessBonus(held)));
        int eff = EnchantMath.efficiencyLevel(held);
        out.add("&7Efficiency " + EnchantSnapshot.roman(eff) + ": &fдобавка к скорости ломания +"
                + fmt(EnchantMath.efficiencyBonus(eff)) + " &8(только если инструмент подходит блоку)");
        int unb = EnchantMath.unbreakingLevel(held);
        out.add("&7Unbreaking " + EnchantSnapshot.roman(unb) + ": &fинструмент служит в &e"
                + fmt(EnchantMath.toolDurabilityMultiplier(unb)) + "&f раз дольше");

        List<EnchantSnapshot> armor = armor(p);
        out.add("&7Броня:");
        String[] names = {"ботинки", "поножи", "нагрудник", "шлем"};
        ItemStack[] contents = p.getInventory().getArmorContents();
        for (int i = 0; i < armor.size(); i++) {
            ItemStack piece = i < contents.length ? contents[i] : null;
            out.add("&8  • &7" + names[Math.min(i, 3)] + ": &f" + typeName(piece) + " &7[" + levelsWithMarks(armor.get(i)) + "&7]");
        }
        double armorPts = attribute(p, "armor");
        double tough = attribute(p, "armor_toughness");
        out.add("&7Очки брони: &f" + fmt(armorPts) + " &7твёрдость: &f" + fmt(tough));
        int generic = EnchantMath.totalProtectionPoints(armor, Cause.GENERIC);
        out.add("&7Защита чарами: обычный урон &f" + generic + "/20 &7(−" + pct(1.0 - EnchantMath.enchantDamageFactor(generic))
                + "), взрыв &f" + EnchantMath.totalProtectionPoints(armor, Cause.EXPLOSION)
                + "&7, стрелы &f" + EnchantMath.totalProtectionPoints(armor, Cause.PROJECTILE)
                + "&7, огонь &f" + EnchantMath.totalProtectionPoints(armor, Cause.FIRE)
                + "&7, падение &f" + EnchantMath.totalProtectionPoints(armor, Cause.FALL));
        if (!Double.isNaN(armorPts) && !Double.isNaN(tough)) {
            double after = EnchantMath.damageAfterArmor(sampleDamage, armorPts, tough, generic);
            out.add("&7Удар на &f" + fmt(sampleDamage) + " &7урона дойдёт как &c" + fmt(after) + " &7(без эффекта Resistance)");
        }
        int armorUnb = 0;
        for (EnchantSnapshot s : armor) {
            armorUnb = Math.max(armorUnb, EnchantMath.unbreakingLevel(s));
        }
        out.add("&7Unbreaking на броне (макс. " + EnchantSnapshot.roman(armorUnb) + "): &fброня служит в &e"
                + fmt(EnchantMath.armorDurabilityMultiplier(armorUnb)) + "&f раз дольше");
        out.add("&8Повышенные уровни не считаются нарушением: античит их учитывает, а не наказывает.");
        return out;
    }

    private static String levelsWithMarks(EnchantSnapshot s) {
        if (s.isEmpty()) {
            return "нет";
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : s.levels().entrySet()) {
            if (sb.length() > 0) {
                sb.append("&7, &f");
            }
            String k = e.getKey().startsWith("minecraft:") ? e.getKey().substring("minecraft:".length()) : e.getKey();
            sb.append(k).append(' ').append(EnchantSnapshot.roman(e.getValue()));
            if (EnchantMath.aboveVanillaMax(e.getKey(), e.getValue())) {
                sb.append(" &e(выше ванили)&f");
            }
        }
        return sb.toString();
    }

    private static String fmt(double v) {
        return Double.isNaN(v) ? "?" : String.format(Locale.ROOT, "%.1f", v);
    }

    private static String pct(double v) {
        return Math.round(v * 100.0) + "%";
    }
}
