package ru.hexatime.astraguard.notify;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import ru.hexatime.astraguard.config.Settings;
import ru.hexatime.astraguard.discord.DiscordWebhook;
import ru.hexatime.astraguard.punishment.BanRecord;
import ru.hexatime.astraguard.util.Text;
import ru.hexatime.astraguard.violation.Violation;
import ru.hexatime.astraguard.violation.ViolationManager;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Оповещения администрации. Получают игроки с правом astraguard.alerts, кто не отключил их командой /ag alerts. */
public final class AlertManager {

    private final Settings settings;
    private final Set<UUID> muted = ConcurrentHashMap.newKeySet();

    private final DiscordWebhook discord;

    public AlertManager(Settings settings, DiscordWebhook discord) {
        this.settings = settings;
        this.discord = discord;
    }

    private Map<String, String> vars(Violation v, ViolationManager.Summary sum) {
        Map<String, String> m = new HashMap<>();
        m.put("test", v.test() ? "&e[TEST] " : "");
        m.put("player", v.name());
        m.put("platform", v.platform());
        m.put("check", v.check());
        m.put("category", v.category().title());
        m.put("vl", Text.num(v.vl()));
        m.put("confidence", Text.percent(v.confidence()));
        m.put("combined", Text.percent(sum.combined()));
        m.put("groups", String.valueOf(sum.independent()));
        m.put("ping", String.valueOf(v.ping()));
        m.put("client", v.clientVersion());
        m.put("reason", v.reason());
        return m;
    }

    public void violation(Violation v, ViolationManager.Summary sum) {
        discord.violation(v, sum);
        if (!settings.alertsEnabled()) {
            return;
        }
        broadcast(Text.fill(settings.alertFormat(), vars(v, sum)));
    }

    public void warn(Violation v, ViolationManager.Summary sum) {
        discord.warning(v, sum);
        if (!settings.alertsEnabled()) {
            return;
        }
        broadcast(Text.fill(settings.warnFormat(), vars(v, sum)));
    }

    public void banIssued(BanRecord b) {
        discord.ban(b);
        Map<String, String> m = new HashMap<>();
        m.put("player", b.name());
        m.put("reason", b.reason());
        m.put("until", Text.date(b.expiresAt()));
        m.put("actor", b.issuedBy());
        m.put("id", String.valueOf(b.id()));
        broadcast(Text.fill(settings.banFormat(), m));
    }

    public void unbanned(String player, String actor) {
        discord.unban(player, actor);
        Map<String, String> m = new HashMap<>();
        m.put("player", player);
        m.put("actor", actor);
        broadcast(Text.fill(settings.unbanFormat(), m));
    }

    private void broadcast(String legacy) {
        Component c = Text.color(legacy);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission("astraguard.alerts") && !muted.contains(p.getUniqueId())) {
                p.sendMessage(c);
            }
        }
        Bukkit.getConsoleSender().sendMessage(c);
    }

    /** Переключает оповещения для игрока; возвращает true, если теперь они включены. */
    public boolean toggle(UUID id) {
        if (muted.remove(id)) {
            return true;
        }
        muted.add(id);
        return false;
    }

    public void forget(UUID id) {
        muted.remove(id);
    }
}
