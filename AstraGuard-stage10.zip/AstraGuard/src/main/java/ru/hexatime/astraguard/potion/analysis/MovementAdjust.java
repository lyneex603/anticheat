package ru.hexatime.astraguard.potion.analysis;

import java.util.ArrayList;
import java.util.List;

/**
 * Влияние активных эффектов на движение, которое НЕ видно в атрибутах игрока.
 *
 * @param speedMultiplier множитель допустимой скорости (1.0 — без изменений)
 * @param extraJump       добавка к начальной скорости прыжка
 * @param exempt          эффект запускает движение, которое не описать моделью физики (рывок, отбрасывание):
 *                        проверки движения на это время не применяются
 * @param reasons         какие эффекты дали вклад (для объяснений)
 */
public record MovementAdjust(double speedMultiplier, double extraJump, boolean exempt, List<String> reasons) {

    public static final MovementAdjust IDENTITY = new MovementAdjust(1.0, 0.0, false, List.of());

    public MovementAdjust {
        if (!(speedMultiplier > 0.0)) {
            throw new IllegalArgumentException("speedMultiplier must be > 0");
        }
        reasons = List.copyOf(reasons);
    }

    public boolean isIdentity() {
        return speedMultiplier == 1.0 && extraJump == 0.0 && !exempt;
    }

    public MovementAdjust and(MovementAdjust o) {
        if (o.isIdentity() && o.reasons.isEmpty()) {
            return this;
        }
        List<String> r = new ArrayList<>(reasons);
        r.addAll(o.reasons);
        return new MovementAdjust(speedMultiplier * o.speedMultiplier, extraJump + o.extraJump, exempt || o.exempt, r);
    }
}
