package ru.hexatime.astraguard.combat.analysis;

/**
 * AutoClicker. Работает в ТИКАХ сервера, а не в миллисекундах: пакеты обрабатываются в тике сервера,
 * поэтому миллисекундные интервалы искажены и не доказывают ничего.
 * <ul>
 *   <li>AutoClicker-CPS: невозможный CPS (порог зависит от способа управления);</li>
 *   <li>AutoClicker-Pattern: при непрерывных кликах ≥ clickMinCps почти все интервалы одинаковы.</li>
 * </ul>
 * Одного высокого CPS мало для наказания: он идёт отдельным признаком с небольшим весом.
 */
public final class ClickAnalyzer {

    private static final int RING = 64;
    private static final int SAMPLE = 30;

    private final int[] swings = new int[RING];
    private int head;
    private int count;
    private int sinceSample;
    private int lastHardTick = -1_000_000;
    private double hardBuffer;

    /** Регистрирует взмах руки. Возвращает нарушение или null. */
    public Finding onSwing(int tick, Thresholds t) {
        swings[head] = tick;
        head = (head + 1) % RING;
        count = Math.min(RING, count + 1);
        sinceSample++;

        Finding hard = checkHardCps(tick, t);
        if (hard != null) {
            return hard;
        }
        if (count >= SAMPLE && sinceSample >= 10) {
            sinceSample = 0;
            return checkPattern(t);
        }
        return null;
    }

    private int at(int back) {
        return swings[(head - 1 - back + RING * 2) % RING];
    }

    /** Количество взмахов за последние 20 тиков (1 секунда). */
    public int cps(int tick) {
        int n = 0;
        for (int i = 0; i < count; i++) {
            if (tick - at(i) < 20) {
                n++;
            } else {
                break;
            }
        }
        return n;
    }

    private Finding checkHardCps(int tick, Thresholds t) {
        int cps = cps(tick);
        if (cps >= t.hardCps()) {
            if (tick - lastHardTick >= 20) {
                lastHardTick = tick;
                hardBuffer += 1.0;
                if (hardBuffer >= 2.0) {
                    hardBuffer = 1.0;
                    return Finding.of("AutoClicker-CPS", "combat-click", 0.6,
                            "CPS " + cps + " за 1 секунду при пороге " + (int) t.hardCps(),
                            "cps", cps, "limit", (int) t.hardCps());
                }
            }
        } else if (tick - lastHardTick >= 60) {
            hardBuffer = Math.max(0.0, hardBuffer - 0.5);
        }
        return null;
    }

    private Finding checkPattern(Thresholds t) {
        int n = SAMPLE - 1;
        int[] iv = new int[n];
        long sum = 0;
        for (int i = 0; i < n; i++) {
            iv[i] = at(i) - at(i + 1);
            if (iv[i] < 0 || iv[i] > 6) {
                return null; // клики не непрерывные — анализировать нечего
            }
            sum += iv[i];
        }
        if (sum <= 0) {
            return null;
        }
        double avgCps = 20.0 * n / sum;
        if (avgCps < t.clickMinCps()) {
            return null;
        }
        int[] freq = new int[8];
        for (int v : iv) {
            freq[v]++;
        }
        int mode = 0;
        for (int i = 1; i < freq.length; i++) {
            if (freq[i] > freq[mode]) {
                mode = i;
            }
        }
        double ratio = freq[mode] / (double) n;
        double mean = sum / (double) n;
        double var = 0;
        for (int v : iv) {
            var += (v - mean) * (v - mean);
        }
        double std = Math.sqrt(var / n);
        if (ratio >= t.clickModeRatio() && std <= 0.4) {
            return Finding.of("AutoClicker-Pattern", "combat-click", 0.8,
                    String.format("%d%% интервалов между кликами одинаковы (%d тик.) при среднем CPS %.1f",
                            Math.round(ratio * 100), mode, avgCps),
                    "cps", String.format("%.1f", avgCps), "modeRatio", String.format("%.2f", ratio),
                    "modeTicks", mode, "stdTicks", String.format("%.2f", std));
        }
        return null;
    }
}
