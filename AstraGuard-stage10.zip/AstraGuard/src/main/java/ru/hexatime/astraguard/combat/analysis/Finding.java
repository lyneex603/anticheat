package ru.hexatime.astraguard.combat.analysis;

import java.util.LinkedHashMap;
import java.util.Map;

/** Результат анализа: что именно подозрительно, насколько сильно и с какими числами. Без Bukkit. */
public record Finding(String check, String group, double weight, String reason, Map<String, String> data) {

    public static Finding of(String check, String group, double weight, String reason, Object... kv) {
        Map<String, String> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            m.put(String.valueOf(kv[i]), String.valueOf(kv[i + 1]));
        }
        return new Finding(check, group, weight, reason, m);
    }
}
