package ru.hexatime.astraguard.player;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.floodgate.FloodgateResolver;
import ru.hexatime.astraguard.floodgate.JavaOnlyResolver;
import ru.hexatime.astraguard.floodgate.PlatformResolver;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Хранит профили онлайн-игроков. Профиль создаётся при входе и удаляется при выходе (без утечек памяти). */
public final class ProfileManager implements Listener {

    private final AstraGuard plugin;
    private final Map<UUID, PlayerProfile> profiles = new ConcurrentHashMap<>();
    private final PlatformResolver resolver;
    private final boolean floodgatePresent;

    public ProfileManager(AstraGuard plugin) {
        this.plugin = plugin;
        this.floodgatePresent = Bukkit.getPluginManager().getPlugin("floodgate") != null;
        this.resolver = floodgatePresent ? new FloodgateResolver(plugin.getLogger()) : new JavaOnlyResolver();
        if (!floodgatePresent) {
            plugin.getLogger().warning("Floodgate не найден: отличить Bedrock от Java невозможно, все игроки считаются Java.");
        }
    }

    public boolean floodgatePresent() {
        return floodgatePresent;
    }

    public PlayerProfile get(Player player) {
        return profiles.computeIfAbsent(player.getUniqueId(), k -> resolver.resolve(player));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        PlayerProfile profile = get(e.getPlayer());
        plugin.database().async(() -> plugin.database().savePlayer(profile));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        profiles.remove(id);
        plugin.violations().clear(id);
        plugin.evidence().clear(id);
        plugin.alerts().forget(id);
    }
}
