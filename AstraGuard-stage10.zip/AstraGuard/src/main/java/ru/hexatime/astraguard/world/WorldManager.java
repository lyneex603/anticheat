package ru.hexatime.astraguard.world;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageAbortEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.combat.analysis.ControlClass;
import ru.hexatime.astraguard.combat.analysis.Finding;
import ru.hexatime.astraguard.combat.analysis.Geometry;
import ru.hexatime.astraguard.player.PlayerProfile;
import ru.hexatime.astraguard.util.ServerHealth;
import ru.hexatime.astraguard.violation.CheckCategory;
import ru.hexatime.astraguard.violation.Flag;
import ru.hexatime.astraguard.world.analysis.*;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Проверки взаимодействия с миром. Все обработчики — MONITOR + ignoreCancelled: действия, отменённые другими плагинами
 * (регионы, защита), не проверяются. Работает в основном потоке.
 * <p>
 * FastBreak: эталонное время ломания берётся у сервера ({@code Block#getBreakSpeed(Player)}) — он сам учитывает
 * инструмент, зачарования любого уровня (в т.ч. Efficiency VI–X, они ванильные с повышенным уровнем), Haste,
 * усталость, воду и полёт. Блоки, которые сломал плагин (бур/дровосек) без начала ломания игроком, не проверяются.
 */
public final class WorldManager implements Listener {

    private record BlockKey(UUID world, int x, int y, int z) {
        static BlockKey of(Block b) {
            return new BlockKey(b.getWorld().getUID(), b.getX(), b.getY(), b.getZ());
        }
    }

    private static final class State {
        final BreakAnalyzer breaking = new BreakAnalyzer();
        final PlaceRateAnalyzer rate = new PlaceRateAnalyzer();
        final PlacementAnalyzer placement = new PlacementAnalyzer();
        final InteractReachAnalyzer reach = new InteractReachAnalyzer();
        final ControlClass control;
        BlockKey digKey;
        long digStartMs;
        double digExpectedMs;

        State(ControlClass control) {
            this.control = control;
        }
    }

    private final AstraGuard plugin;
    private final WorldSettings settings;
    private final ServerHealth health;
    private final Map<UUID, State> states = new HashMap<>();
    private final Attribute blockRange;

    public WorldManager(AstraGuard plugin, ServerHealth health) {
        this.plugin = plugin;
        this.health = health;
        this.settings = new WorldSettings(plugin);
        Attribute a = null;
        try {
            a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft("block_interaction_range"));
        } catch (Throwable t) {
            plugin.getLogger().warning("Атрибут дальности взаимодействия не найден, будет 4.5: " + t);
        }
        this.blockRange = a;
    }

    public void reload() {
        settings.reload();
    }

    public WorldSettings settings() {
        return settings;
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> {
            PlayerProfile pr = plugin.profiles().get(p);
            return new State(ControlClass.of(pr.isBedrock(), pr.inputMode()));
        });
    }

    private static boolean skip(Player p) {
        GameMode gm = p.getGameMode();
        return gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR;
    }

    /** Эталонное время ломания в мс: 0 — мгновенно, -1 — неломаемый блок или неизвестно. */
    private static double expectedMs(Block b, Player p) {
        float speed = b.getBreakSpeed(p);
        if (speed <= 0.0f) {
            return -1.0;
        }
        if (speed >= 1.0f) {
            return 0.0;
        }
        return Math.ceil(1.0 / speed) * 50.0;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }

    // ---------------- FastBreak ----------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(BlockDamageEvent e) {
        Player p = e.getPlayer();
        if (!settings.enabled() || skip(p)) {
            return;
        }
        State st = state(p);
        st.digKey = BlockKey.of(e.getBlock());
        st.digStartMs = ServerHealth.nowMs();
        st.digExpectedMs = e.getInstaBreak() ? 0.0 : expectedMs(e.getBlock(), p);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDamageAbort(BlockDamageAbortEvent e) {
        State st = states.get(e.getPlayer().getUniqueId());
        if (st != null) {
            st.digKey = null;
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        State st = states.get(p.getUniqueId());
        if (!settings.enabled() || st == null || skip(p) || st.digKey == null
                || !st.digKey.equals(BlockKey.of(e.getBlock()))) {
            return; // блок сломан без начала ломания игроком (плагин, бур/дровосек) — не проверяем
        }
        long now = ServerHealth.nowMs();
        double elapsed = now - st.digStartMs;
        double expected = st.digExpectedMs;
        double expectedNow = expectedMs(e.getBlock(), p);
        st.digKey = null;
        if (expected < 0 || expectedNow < 0) {
            return;
        }
        // Инструмент могли сменить во время ломания — берём более быстрый (мягкий) эталон
        expected = Math.min(expected, expectedNow);
        if (health.tps() < settings.minTps() || health.stalledWithin(now, (long) elapsed + 1000L)) {
            st.breaking.reset();
            return; // сервер лагал: пакеты начала и конца могли прийти пачкой
        }
        emit(p, st, st.breaking.onBreak(now, elapsed, expected, settings.thresholds(st.control)));
    }

    // ---------------- FastPlace, Scaffold, InvalidPlace ----------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (!settings.enabled() || skip(p)) {
            return;
        }
        State st = state(p);
        WorldThresholds th = settings.thresholds(st.control);
        long now = ServerHealth.nowMs();

        if (health.stalledWithin(now, 2000)) {
            st.rate.reset();
        } else {
            emit(p, st, st.rate.onPlace(now, th));
        }

        Block against = e.getBlockAgainst();
        Block placed = e.getBlockPlaced();
        int fx = placed.getX() - against.getX();
        int fy = placed.getY() - against.getY();
        int fz = placed.getZ() - against.getZ();
        if (Math.abs(fx) + Math.abs(fy) + Math.abs(fz) != 1) {
            return; // замена блока (трава, снег) или нестандартная установка — геометрию не оцениваем
        }
        BoundingBox bb = against.getBoundingBox();
        double[] box = bb.getVolume() > 0.0
                ? new double[]{bb.getMinX(), bb.getMinY(), bb.getMinZ(), bb.getMaxX(), bb.getMaxY(), bb.getMaxZ()}
                : new double[]{against.getX(), against.getY(), against.getZ(),
                        against.getX() + 1, against.getY() + 1, against.getZ() + 1};
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection();
        PlacementAnalyzer.Result r = PlacementAnalyzer.classify(
                new double[]{eye.getX(), eye.getY(), eye.getZ()}, new double[]{dir.getX(), dir.getY(), dir.getZ()},
                box, new int[]{fx, fy, fz}, th, th.aimChecks());
        emit(p, st, st.placement.onPlace(r));
    }

    // ---------------- InvalidInteract-Reach ----------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        Action a = e.getAction();
        Block b = e.getClickedBlock();
        Player p = e.getPlayer();
        if (b == null || !settings.enabled() || skip(p)
                || (a != Action.LEFT_CLICK_BLOCK && a != Action.RIGHT_CLICK_BLOCK)
                || (a == Action.RIGHT_CLICK_BLOCK && e.getHand() != EquipmentSlot.HAND)) {
            return;
        }
        State st = state(p);
        Location eye = p.getEyeLocation();
        double distance = Geometry.distanceToBox(eye.getX(), eye.getY(), eye.getZ(),
                b.getX(), b.getY(), b.getZ(), b.getX() + 1, b.getY() + 1, b.getZ() + 1);
        double range = 4.5;
        if (blockRange != null) {
            AttributeInstance inst = p.getAttribute(blockRange);
            if (inst != null) {
                range = inst.getValue();
            }
        }
        emit(p, st, st.reach.onInteract(distance, range,
                a == Action.LEFT_CLICK_BLOCK ? "удар по" : "использование", settings.thresholds(st.control)));
    }

    // ---------------- отправка нарушения ----------------

    private void emit(Player p, State st, Finding f) {
        if (f == null) {
            return;
        }
        Flag flag = Flag.of(f.check(), f.group(), CheckCategory.WORLD, f.weight(), f.reason());
        for (Map.Entry<String, String> en : f.data().entrySet()) {
            flag = flag.with(en.getKey(), en.getValue());
        }
        flag = flag.with("control", st.control.key())
                .with("tps", String.format("%.2f", health.tps()))
                .with("mspt", String.format("%.1f", health.mspt()));
        plugin.violations().flag(p, flag);
    }
}
