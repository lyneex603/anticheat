package ru.hexatime.astraguard.movement.analysis;

import ru.hexatime.astraguard.combat.analysis.Finding;

/**
 * Fly / Spider. В воздухе вертикальная скорость подчиняется закону dy(t) = (dy(t-1) − g)·0.98.
 * Если игрок движется ВЫШЕ предсказания (висит, поднимается, ползёт по стене) несколько кадров подряд — это нарушение.
 * Падение быстрее предсказанного не флагается (его объясняют столкновения и лаги).
 * Если при подъёме игрок вплотную к стене — проверка называется Spider-Climb (та же группа независимости).
 * В кадре отрыва от земли допускается dy от падения со ступени до силы прыжка.
 */
public final class FlyAnalyzer {

    private static final double BUFFER_LIMIT = 4.0;

    private boolean have;
    private double prevDy;
    private boolean prevGround;
    private int cooldown;
    private double buffer;
    private long lastBadTakeoff = Long.MIN_VALUE / 2;

    public void reset() {
        have = false;
        cooldown = 0;
        buffer = 0;
    }

    public Finding onFrame(MoveFrame f, MoveThresholds t) {
        Finding out = null;
        if (f.discontinuity()) {
            have = false;
            cooldown = 0;
        } else if (f.altered()) {
            cooldown = 3;
            buffer = 0;
        } else if (cooldown > 0) {
            cooldown--;
        } else if (have) {
            out = evaluate(f, t);
        }
        prevDy = f.dy();
        prevGround = f.serverGround();
        have = true;
        return out;
    }

    private Finding evaluate(MoveFrame f, MoveThresholds t) {
        if (f.serverGround()) {
            buffer = Math.max(0.0, buffer - 1.0);
            return null;
        }
        double deviation;
        double reference;
        String kind;
        if (prevGround) {
            reference = f.jumpPower();
            deviation = f.dy() - reference;
            kind = "takeoff";
            if (deviation > t.verticalTol()) {
                // Завышенный прыжок виден ровно в одном кадре, поэтому считаем повторы по времени:
                // два таких взлёта за 10 секунд — нарушение (одиночный может быть неучтённым источником).
                boolean repeat = f.timeMs() - lastBadTakeoff <= 10_000;
                lastBadTakeoff = f.timeMs();
                if (repeat) {
                    buffer = BUFFER_LIMIT;
                }
            } else {
                buffer = Math.max(0.0, buffer - 0.5);
            }
        } else {
            double g = f.slowFalling() && prevDy <= 0.0 ? 0.01 : f.gravity();
            reference = (prevDy - g) * 0.98;
            deviation = f.dy() - reference;
            kind = "air";
            if (deviation > t.verticalTol()) {
                buffer += 1.0;
            } else {
                buffer = Math.max(0.0, buffer - 0.5);
            }
        }
        if (buffer < BUFFER_LIMIT) {
            return null;
        }
        buffer = BUFFER_LIMIT - 2.0;
        boolean spider = f.dy() > 0.0 && f.nearWall();
        String reason = String.format("вертикальное смещение %.3f при ожидаемом не более %.3f (%s, +%.3f)",
                f.dy(), reference + t.verticalTol(), kind.equals("takeoff") ? "отрыв от земли" : "в воздухе", deviation);
        return Finding.of(spider ? "Spider-Climb" : "Fly-Gravity", "move-vertical", spider ? 0.8 : 0.8,
                spider ? "подъём вдоль стены без лестницы/лианы: " + reason : reason,
                "dy", String.format("%.3f", f.dy()), "expected", String.format("%.3f", reference),
                "deviation", String.format("%.3f", deviation), "phase", kind, "nearWall", f.nearWall());
    }
}
