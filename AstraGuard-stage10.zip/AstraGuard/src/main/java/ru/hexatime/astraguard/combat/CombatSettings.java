package ru.hexatime.astraguard.combat;

import org.bukkit.configuration.file.FileConfiguration;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.combat.analysis.ControlClass;
import ru.hexatime.astraguard.combat.analysis.Thresholds;

import java.util.EnumMap;
import java.util.Map;

/** Боевые настройки из config.yml. Кэшируются и перечитываются по /ag reload (в горячих обработчиках конфиг не читается). */
public final class CombatSettings {

    private final AstraGuard plugin;
    private final Map<ControlClass, Thresholds> profiles = new EnumMap<>(ControlClass.class);
    private volatile int maxPing = 400;
    private volatile double minTps = 17.5;
    private volatile double maxMspt = 80.0;
    private volatile long warmupMs = 5000;

    public CombatSettings(AstraGuard plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        FileConfiguration c = plugin.getConfig();
        maxPing = Math.max(50, c.getInt("combat.max-ping", 400));
        minTps = c.getDouble("combat.min-tps", 17.5);
        maxMspt = c.getDouble("combat.max-mspt", 80.0);
        warmupMs = Math.max(0, c.getLong("combat.warmup-seconds", 5)) * 1000L;
        Map<ControlClass, Thresholds> fresh = new EnumMap<>(ControlClass.class);
        for (ControlClass cc : ControlClass.values()) {
            Thresholds d = Thresholds.defaults(cc);
            String p = "combat.profiles." + cc.key() + ".";
            fresh.put(cc, new Thresholds(
                    c.getDouble(p + "reach-tolerance", d.reachTolerance()),
                    c.getDouble(p + "max-facing-angle", d.maxFacingDeg()),
                    c.getDouble(p + "click-mode-ratio", d.clickModeRatio()),
                    c.getDouble(p + "click-min-cps", d.clickMinCps()),
                    c.getDouble(p + "hard-cps", d.hardCps()),
                    c.getBoolean(p + "aim-checks", d.aimChecks()),
                    c.getBoolean(p + "trigger-check", d.triggerCheck())));
        }
        profiles.clear();
        profiles.putAll(fresh);
    }

    public Thresholds thresholds(ControlClass c) {
        Thresholds t = profiles.get(c);
        return t != null ? t : Thresholds.defaults(c);
    }

    public int maxPing() {
        return maxPing;
    }

    public double minTps() {
        return minTps;
    }

    public double maxMspt() {
        return maxMspt;
    }

    public long warmupMs() {
        return warmupMs;
    }
}
