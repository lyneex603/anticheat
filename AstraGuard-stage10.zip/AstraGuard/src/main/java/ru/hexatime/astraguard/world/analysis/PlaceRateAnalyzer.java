package ru.hexatime.astraguard.world.analysis;

import ru.hexatime.astraguard.combat.analysis.Finding;

/** FastPlace. Невозможное число установок блоков за секунду (ваниль ограничивает ~5/с). Нужна серия, а не один всплеск. */
public final class PlaceRateAnalyzer {

    private static final int RING = 32;

    private final long[] times = new long[RING];
    private int head;
    private int count;
    private double buffer;

    public void reset() {
        head = 0;
        count = 0;
        buffer = 0;
    }

    public Finding onPlace(long nowMs, WorldThresholds t) {
        times[head] = nowMs;
        head = (head + 1) % RING;
        count = Math.min(RING, count + 1);
        int inSecond = 0;
        for (int i = 0; i < count; i++) {
            long ts = times[(head - 1 - i + RING * 2) % RING];
            if (nowMs - ts <= 1000) {
                inSecond++;
            } else {
                break;
            }
        }
        if (inSecond <= t.maxPlacePerSecond()) {
            buffer = Math.max(0.0, buffer - 0.25);
            return null;
        }
        buffer += 1.0;
        if (buffer < 3.0) {
            return null;
        }
        buffer = 1.5;
        return Finding.of("FastPlace", "world-place-rate", 0.8,
                inSecond + " блоков за 1 секунду при пределе " + t.maxPlacePerSecond(),
                "perSecond", inSecond, "limit", t.maxPlacePerSecond());
    }
}
