package ru.hexatime.astraguard.evidence;

import ru.hexatime.astraguard.util.Text;
import ru.hexatime.astraguard.violation.Violation;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Кольцевой буфер последних событий каждого игрока. Проверки добавляют сюда короткие записи
 * (например, "hit target=Zombie dist=3.2"), а при флаге последние события прикрепляются к доказательству.
 * Размер ограничен, данные удаляются при выходе игрока.
 */
public final class EvidenceRecorder {

    private static final int TRACE_SIZE = 40;

    private final Map<UUID, ArrayDeque<String>> traces = new ConcurrentHashMap<>();

    public void trace(UUID uuid, String type, String detail) {
        ArrayDeque<String> q = traces.computeIfAbsent(uuid, k -> new ArrayDeque<>(TRACE_SIZE + 1));
        String line = Text.timeMs(System.currentTimeMillis()) + " " + type + " " + detail;
        synchronized (q) {
            q.addLast(line);
            while (q.size() > TRACE_SIZE) {
                q.pollFirst();
            }
        }
    }

    /** Собирает доказательство для нарушения: контекст проверки + последние события игрока. */
    public Evidence capture(Violation v, Map<String, String> context) {
        StringBuilder ctx = new StringBuilder();
        for (Map.Entry<String, String> e : context.entrySet()) {
            ctx.append(e.getKey()).append('=').append(e.getValue()).append('\n');
        }
        String traceText = "";
        ArrayDeque<String> q = traces.get(v.uuid());
        if (q != null) {
            synchronized (q) {
                traceText = String.join("\n", List.copyOf(q));
            }
        }
        return new Evidence(v.uuid(), v.name(), v.check(), v.time(), v.vl(), v.confidence(), v.ping(),
                v.tps(), v.mspt(), v.platform(), v.clientVersion(), ctx.toString().trim(), traceText);
    }

    public void clear(UUID uuid) {
        traces.remove(uuid);
    }
}
