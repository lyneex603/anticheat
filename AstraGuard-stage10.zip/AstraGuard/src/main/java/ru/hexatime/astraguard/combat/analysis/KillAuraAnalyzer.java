package ru.hexatime.astraguard.combat.analysis;

import java.util.ArrayDeque;

/**
 * KillAura и Invalid Hit.
 * <ul>
 *   <li>KillAura-Facing: повторные удары по цели, находящейся далеко в стороне от взгляда;</li>
 *   <li>KillAura-Switch: быстрая серия ударов по разным целям, стоящим в разных направлениях;</li>
 *   <li>InvalidHit-Wall: удары, когда между глазами и целью сплошной блок.</li>
 * </ul>
 * Facing и Switch — одна группа независимости (один источник подозрения), Wall — отдельная.
 */
public final class KillAuraAnalyzer {

    /** Один удар. */
    public record Hit(int tick, int targetId, double distance, double yawToTarget, double yawError, boolean throughWall) {
    }

    private static final int SWITCH_WINDOW = 20;

    private double facingBuffer;
    private double wallBuffer;
    private Hit last;
    private final ArrayDeque<Integer> switchTicks = new ArrayDeque<>();
    private final ArrayDeque<Integer> switchTargets = new ArrayDeque<>();

    public Finding onAttack(Hit h, Thresholds t) {
        Finding wall = checkWall(h);
        Finding sw = checkSwitch(h);
        Finding facing = checkFacing(h, t);
        last = h;
        if (wall != null) {
            return wall;
        }
        return facing != null ? facing : sw;
    }

    private Finding checkFacing(Hit h, Thresholds t) {
        if (h.distance() < 1.5) {
            return null; // вплотную угол взгляда ничего не значит
        }
        if (h.yawError() > t.maxFacingDeg()) {
            facingBuffer += 1.0;
            if (facingBuffer >= 3.0) {
                facingBuffer = 2.0;
                return Finding.of("KillAura-Facing", "combat-killaura", 1.0,
                        String.format("удар по цели в стороне от взгляда: %.0f° при допустимых %.0f°", h.yawError(), t.maxFacingDeg()),
                        "yawError", String.format("%.1f", h.yawError()), "limit", String.format("%.0f", t.maxFacingDeg()),
                        "distance", String.format("%.2f", h.distance()));
            }
        } else {
            facingBuffer = Math.max(0.0, facingBuffer - 0.34);
        }
        return null;
    }

    private Finding checkWall(Hit h) {
        if (h.throughWall()) {
            wallBuffer += 1.0;
            if (wallBuffer >= 2.0) {
                wallBuffer = 1.0;
                return Finding.of("InvalidHit-Wall", "combat-wall", 1.0,
                        "удар по цели сквозь сплошной блок", "distance", String.format("%.2f", h.distance()));
            }
        } else {
            wallBuffer = Math.max(0.0, wallBuffer - 0.25);
        }
        return null;
    }

    private Finding checkSwitch(Hit h) {
        if (last == null || last.targetId() == h.targetId()) {
            return null;
        }
        int gap = h.tick() - last.tick();
        double diff = Math.abs(Geometry.wrapDeg(h.yawToTarget() - last.yawToTarget()));
        while (!switchTicks.isEmpty() && h.tick() - switchTicks.peekFirst() > SWITCH_WINDOW) {
            switchTicks.pollFirst();
            switchTargets.pollFirst();
        }
        if (diff >= 45.0 && gap <= 4) {
            switchTicks.addLast(h.tick());
            switchTargets.addLast(h.targetId());
            long distinct = switchTargets.stream().distinct().count();
            if (switchTicks.size() >= 3 && distinct >= 3) {
                int n = switchTicks.size();
                switchTicks.clear();
                switchTargets.clear();
                return Finding.of("KillAura-Switch", "combat-killaura", 1.0,
                        n + " быстрых переключений между целями в разных направлениях за " + SWITCH_WINDOW + " тиков",
                        "switches", n, "lastAngle", String.format("%.0f", diff), "gapTicks", gap);
            }
        }
        return null;
    }
}
