package ru.hexatime.astraguard.punishment;

import java.util.UUID;

/** Запись о бане. expiresAt — время окончания в миллисекундах (бан всегда временный). */
public record BanRecord(long id, UUID uuid, String name, String reason, String issuedBy, long issuedAt,
                        long expiresAt, boolean active, String removedBy, long removedAt) {

    public BanRecord withId(long newId) {
        return new BanRecord(newId, uuid, name, reason, issuedBy, issuedAt, expiresAt, active, removedBy, removedAt);
    }

    public boolean expired(long now) {
        return expiresAt <= now;
    }
}
