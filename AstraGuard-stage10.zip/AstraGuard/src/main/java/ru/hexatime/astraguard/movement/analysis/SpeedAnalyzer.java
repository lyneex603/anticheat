package ru.hexatime.astraguard.movement.analysis;

import ru.hexatime.astraguard.combat.analysis.Finding;

/**
 * Speed. Не фиксированный лимит, а модель ванильной физики по кадрам:
 * <pre>d(t) ≤ d(t-1) · трение + разгон + бонус прыжка + запас</pre>
 * где трение = скользкость·0.91 на земле и 0.91 в воздухе, разгон на земле = скорость·0.216/скользкость³,
 * в воздухе 0.026, бонус спринт-прыжка 0.2 в кадре отрыва. Лёд, потенциалы скорости, инерция учтены самой формулой.
 * «Земля» берётся с запасом (прошлый ИЛИ текущий кадр), чтобы ошибка в 1 кадр не давала ложных флагов.
 */
public final class SpeedAnalyzer {

    static final double AIR_ACCEL = 0.026;
    static final double JUMP_BOOST = 0.2;
    private static final double BUFFER_LIMIT = 5.0;

    private boolean have;
    private double prevH;
    private boolean prevGround;
    private double prevSlip = 0.6;
    private int cooldown;
    private double buffer;

    public void reset() {
        have = false;
        cooldown = 0;
        buffer = 0;
    }

    public Finding onFrame(MoveFrame f, MoveThresholds t) {
        Finding out = null;
        if (f.discontinuity()) {
            have = false;
            cooldown = 0;
        } else if (f.altered()) {
            cooldown = 3;
            buffer = 0;
        } else if (cooldown > 0) {
            cooldown--;
        } else if (have) {
            out = evaluate(f, t);
        }
        prevH = f.horizontal();
        prevGround = f.serverGround();
        prevSlip = f.slip();
        have = true;
        return out;
    }

    /** Максимально допустимое смещение за кадр (для /ag debug и тестов). */
    public double bound(MoveFrame f, MoveThresholds t) {
        boolean grounded = prevGround || f.serverGround();
        double slip = grounded ? Math.max(prevSlip, f.slip()) : 0.6;
        double friction = grounded ? slip * 0.91 : 0.91;
        double accel = grounded ? f.speedPotential() * 0.216 / (slip * slip * slip) : AIR_ACCEL;
        double takeoff = prevGround && !f.serverGround() ? JUMP_BOOST : 0.0;
        return prevH * friction + accel + takeoff + t.speedEps();
    }

    private Finding evaluate(MoveFrame f, MoveThresholds t) {
        double h = f.horizontal();
        double bound = bound(f, t);
        double excess = h - bound;
        if (excess <= 0.0) {
            buffer = Math.max(0.0, buffer - 0.5);
            return null;
        }
        buffer += 1.0;
        if (buffer < BUFFER_LIMIT) {
            return null;
        }
        buffer = BUFFER_LIMIT - 2.0;
        boolean grounded = prevGround || f.serverGround();
        return Finding.of(grounded ? "Speed-Ground" : "Speed-Air", "move-speed", 0.7,
                String.format("скорость %.3f бл/тик при допустимых %.3f (+%.3f) по модели физики", h, bound, excess),
                "speed", String.format("%.3f", h), "allowed", String.format("%.3f", bound),
                "excess", String.format("%.3f", excess), "grounded", grounded);
    }
}
