package ru.hexatime.astraguard.world.analysis;

import ru.hexatime.astraguard.combat.analysis.Finding;
import ru.hexatime.astraguard.combat.analysis.Geometry;

/**
 * Scaffold-Aim и InvalidPlace-Face. Блок ставят ПРОТИВ другого блока; у честного игрока
 * (1) глаза находятся со стороны той грани, на которую ставят, и (2) взгляд проходит через блок, на который ставят.
 * Scaffold ставит блоки, не глядя на них, и часто «на невидимую» грань. Одиночная неточность не флагается (буферы).
 */
public final class PlacementAnalyzer {

    public enum Result { OK, FACE_AWAY, AIM_MISS }

    private double aimBuffer;
    private double faceBuffer;

    public void reset() {
        aimBuffer = 0;
        faceBuffer = 0;
    }

    /**
     * Чистая геометрия одной установки.
     *
     * @param eye   глаза игрока; look — единичный вектор взгляда
     * @param box   {minX,minY,minZ,maxX,maxY,maxZ} блока, на который ставят
     * @param face  единичная нормаль грани (из блока в сторону нового блока)
     */
    public static Result classify(double[] eye, double[] look, double[] box, int[] face,
                                  WorldThresholds t, boolean aimChecks) {
        double cx = (box[0] + box[3]) / 2.0 + face[0] * ((box[3] - box[0]) / 2.0);
        double cy = (box[1] + box[4]) / 2.0 + face[1] * ((box[4] - box[1]) / 2.0);
        double cz = (box[2] + box[5]) / 2.0 + face[2] * ((box[5] - box[2]) / 2.0);
        double side = (eye[0] - cx) * face[0] + (eye[1] - cy) * face[1] + (eye[2] - cz) * face[2];
        if (side < -t.faceTolerance()) {
            return Result.FACE_AWAY;
        }
        if (aimChecks) {
            double e = t.aimTolerance();
            boolean hit = Geometry.rayHitsBox(eye[0], eye[1], eye[2], look[0], look[1], look[2],
                    box[0] - e, box[1] - e, box[2] - e, box[3] + e, box[4] + e, box[5] + e, 8.0);
            if (!hit) {
                return Result.AIM_MISS;
            }
        }
        return Result.OK;
    }

    public Finding onPlace(Result r) {
        if (r == Result.FACE_AWAY) {
            faceBuffer += 1.0;
            if (faceBuffer >= 3.0) {
                faceBuffer = 1.5;
                return Finding.of("InvalidPlace-Face", "world-place-aim", 0.8,
                        "блок поставлен на грань, обращённую от игрока (глаза за плоскостью грани)");
            }
            return null;
        }
        faceBuffer = Math.max(0.0, faceBuffer - 0.25);
        if (r == Result.AIM_MISS) {
            aimBuffer += 1.0;
            if (aimBuffer >= 4.0) {
                aimBuffer = 2.0;
                return Finding.of("Scaffold-Aim", "world-place-aim", 0.9,
                        "блок поставлен, а взгляд не проходит через блок, на который ставят (несколько раз)");
            }
        } else {
            aimBuffer = Math.max(0.0, aimBuffer - 0.35);
        }
        return null;
    }
}
