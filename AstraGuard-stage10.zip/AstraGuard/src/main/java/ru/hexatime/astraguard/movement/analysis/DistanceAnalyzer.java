package ru.hexatime.astraguard.movement.analysis;

import ru.hexatime.astraguard.combat.analysis.Finding;

/**
 * InvalidMove-Distance. За один кадр невозможное смещение (без телепорта, скорости, элитр и транспорта —
 * они отфильтрованы выше). Нужны два случая за 5 секунд.
 */
public final class DistanceAnalyzer {

    static final double MAX_H = 3.0;
    static final double MAX_V = 4.5;
    private static final long WINDOW_MS = 5000;

    private long lastStrike = Long.MIN_VALUE / 2;

    public void reset() {
        lastStrike = Long.MIN_VALUE / 2;
    }

    public Finding onFrame(MoveFrame f) {
        if (f.discontinuity()) {
            return null;
        }
        double h = f.horizontal();
        if (h <= MAX_H && Math.abs(f.dy()) <= MAX_V) {
            return null;
        }
        boolean repeat = f.timeMs() - lastStrike <= WINDOW_MS;
        lastStrike = f.timeMs();
        if (!repeat) {
            return null;
        }
        return Finding.of("InvalidMove-Distance", "move-speed", 1.5,
                String.format("перемещение за один кадр: %.2f бл. по горизонтали, %.2f по вертикали", h, f.dy()),
                "horizontal", String.format("%.2f", h), "vertical", String.format("%.2f", f.dy()));
    }
}
