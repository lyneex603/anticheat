package ru.hexatime.astraguard.floodgate;

import org.bukkit.entity.Player;
import ru.hexatime.astraguard.player.PlayerProfile;

/** Определяет платформу игрока. Реализация выбирается при старте в зависимости от наличия Floodgate. */
public interface PlatformResolver {
    PlayerProfile resolve(Player player);
}
