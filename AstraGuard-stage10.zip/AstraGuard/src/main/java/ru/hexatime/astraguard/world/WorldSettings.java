package ru.hexatime.astraguard.world;

import org.bukkit.configuration.file.FileConfiguration;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.combat.analysis.ControlClass;
import ru.hexatime.astraguard.world.analysis.WorldThresholds;

import java.util.EnumMap;
import java.util.Map;

/** Настройки проверок мира из config.yml. Кэшируются, перечитываются по /ag reload. */
public final class WorldSettings {

    private final AstraGuard plugin;
    private final Map<ControlClass, WorldThresholds> profiles = new EnumMap<>(ControlClass.class);
    private volatile boolean enabled = true;
    private volatile double minTps = 15.0;

    public WorldSettings(AstraGuard plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        FileConfiguration c = plugin.getConfig();
        enabled = c.getBoolean("world.enabled", true);
        minTps = c.getDouble("world.min-tps", 15.0);
        Map<ControlClass, WorldThresholds> fresh = new EnumMap<>(ControlClass.class);
        for (ControlClass cc : ControlClass.values()) {
            WorldThresholds d = WorldThresholds.defaults(cc);
            String p = "world.profiles." + cc.key() + ".";
            fresh.put(cc, new WorldThresholds(
                    c.getDouble(p + "aim-tolerance", d.aimTolerance()),
                    c.getBoolean(p + "aim-checks", d.aimChecks()),
                    c.getDouble(p + "face-tolerance", d.faceTolerance()),
                    c.getDouble(p + "reach-tolerance", d.reachTolerance()),
                    Math.max(1, c.getInt(p + "max-place-per-second", d.maxPlacePerSecond())),
                    c.getDouble(p + "min-break-ratio", d.minBreakRatio()),
                    c.getDouble(p + "break-tolerance-ms", d.breakToleranceMs())));
        }
        profiles.clear();
        profiles.putAll(fresh);
    }

    public WorldThresholds thresholds(ControlClass c) {
        WorldThresholds t = profiles.get(c);
        return t != null ? t : WorldThresholds.defaults(c);
    }

    public boolean enabled() {
        return enabled;
    }

    public double minTps() {
        return minTps;
    }
}
