package ru.hexatime.astraguard.violation;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.config.Settings;
import ru.hexatime.astraguard.evidence.Evidence;
import ru.hexatime.astraguard.player.PlayerProfile;
import ru.hexatime.astraguard.util.Text;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Система нарушений. Все методы вызываются из основного потока сервера.
 * <p>
 * VL затухает «лениво» — при обращении, без фоновых задач и сканирования всех игроков.
 * Автобан требует нескольких НЕЗАВИСИМЫХ групп проверок с высокой уверенностью; иначе — только предупреждение.
 */
public final class ViolationManager {

    /** Итог по игроку: сколько независимых групп подозрительны и какова общая уверенность. */
    public record Summary(int independent, double combined, List<String> checks) {
    }

    /** Снимок состояния одной проверки для команд. */
    public record CheckView(String check, String group, CheckCategory category, double vl,
                            double confidence, int flags) {
    }

    private static final int RECENT_LIMIT = 50;

    private static final class State {
        String name;
        String group;
        CheckCategory category;
        double vl;
        long updated;
        int flags;
        long lastAlert;
    }

    private final AstraGuard plugin;
    private final Map<UUID, Map<String, State>> states = new HashMap<>();
    private final Map<UUID, Long> lastWarn = new HashMap<>();
    private final Map<UUID, ArrayDeque<Violation>> recent = new HashMap<>();

    public ViolationManager(AstraGuard plugin) {
        this.plugin = plugin;
    }

    /**
     * Регистрирует нарушение. Возвращает запись или null, если игрок в исключениях или проверка отключена.
     */
    public Violation flag(Player player, Flag flag) {
        if (!Bukkit.isPrimaryThread()) {
            throw new IllegalStateException("ViolationManager.flag нужно вызывать из основного потока");
        }
        Settings s = plugin.settings();
        if (!flag.test() && player.hasPermission("astraguard.bypass")) {
            return null;
        }
        Settings.CheckSettings cs = s.check(flag.check());
        if (!flag.test() && !cs.enabled()) {
            return null;
        }

        long now = System.currentTimeMillis();
        UUID id = player.getUniqueId();
        State st = states.computeIfAbsent(id, k -> new HashMap<>())
                .computeIfAbsent(flag.check().toLowerCase(Locale.ROOT), k -> new State());
        st.vl = ConfidenceModel.decayedVl(st.vl, now - st.updated, cs.decayAmount(), s.decaySeconds()) + flag.weight();
        st.updated = now;
        st.flags++;
        st.name = flag.check();
        st.group = flag.group();
        st.category = flag.category();

        double confidence = ConfidenceModel.checkConfidence(st.vl, cs.maxVl());
        PlayerProfile profile = plugin.profiles().get(player);
        double tps = Math.min(20.0, Bukkit.getTPS()[0]);
        double mspt = Bukkit.getAverageTickTime();

        Summary summary = summarize(id, now);
        Violation v = new Violation(0, id, player.getName(), flag.check(), flag.group(), flag.category(),
                st.vl, confidence, flag.reason(), now, player.getPing(), tps, mspt,
                profile.platform().name(), profile.clientVersion(), flag.test());

        ArrayDeque<Violation> q = recent.computeIfAbsent(id, k -> new ArrayDeque<>());
        q.addLast(v);
        while (q.size() > RECENT_LIMIT) {
            q.pollFirst();
        }

        Map<String, String> context = flag.context();
        Map<String, String> gear = new java.util.LinkedHashMap<>(plugin.enchants().evidenceContext(player, flag.category()));
        if (flag.category() != CheckCategory.SYSTEM) {
            gear.putAll(plugin.potions().evidenceContext(player));
        }
        if (!gear.isEmpty()) {
            context = new java.util.LinkedHashMap<>(context);
            context.putAll(gear);
        }
        Evidence evidence = plugin.evidence().capture(v, context);
        plugin.database().async(() -> plugin.database().saveViolation(v, evidence));

        if (now - st.lastAlert >= s.alertThrottleMs()) {
            st.lastAlert = now;
            plugin.alerts().violation(v, summary);
        }

        if (!flag.test()) {
            evaluatePunishment(player, v, summary, now);
        }
        if (s.debug()) {
            plugin.getLogger().info("[debug] flag " + flag.check() + " " + player.getName() + " vl=" + Text.num(st.vl)
                    + " conf=" + Text.num(confidence) + " groups=" + summary.independent());
        }
        return v;
    }

    private void evaluatePunishment(Player player, Violation v, Summary sum, long now) {
        Settings s = plugin.settings();
        if (s.autoBanEnabled()
                && sum.independent() >= s.minIndependentChecks()
                && sum.combined() >= s.minCombinedConfidence()) {
            String reason = "Читы (AstraGuard): " + String.join(", ", sum.checks());
            plugin.punishments().autoBan(player, reason);
            return;
        }
        if (sum.combined() >= s.warnConfidence()) {
            long last = lastWarn.getOrDefault(v.uuid(), 0L);
            if (now - last >= s.warnCooldownMs()) {
                lastWarn.put(v.uuid(), now);
                plugin.alerts().warn(v, sum);
            }
        }
    }

    /** Считает независимые группы с достаточной уверенностью и общую уверенность по ним. */
    public Summary summarize(UUID id, long now) {
        Settings s = plugin.settings();
        Map<String, State> map = states.get(id);
        if (map == null) {
            return new Summary(0, 0.0, List.of());
        }
        Map<String, Double> bestPerGroup = new HashMap<>();
        Set<String> names = new HashSet<>();
        for (State st : map.values()) {
            Settings.CheckSettings cs = s.check(st.name);
            double vl = ConfidenceModel.decayedVl(st.vl, now - st.updated, cs.decayAmount(), s.decaySeconds());
            double conf = ConfidenceModel.checkConfidence(vl, cs.maxVl());
            if (conf >= s.minCheckConfidence()) {
                bestPerGroup.merge(st.group, conf, Math::max);
                names.add(st.name);
            }
        }
        List<String> sorted = new ArrayList<>(names);
        sorted.sort(String::compareToIgnoreCase);
        return new Summary(bestPerGroup.size(), ConfidenceModel.combined(bestPerGroup.values()), sorted);
    }

    /** Текущее (с учётом затухания) состояние всех проверок игрока. */
    public List<CheckView> snapshot(UUID id) {
        long now = System.currentTimeMillis();
        Settings s = plugin.settings();
        List<CheckView> out = new ArrayList<>();
        Map<String, State> map = states.get(id);
        if (map == null) {
            return out;
        }
        for (State st : map.values()) {
            Settings.CheckSettings cs = s.check(st.name);
            double vl = ConfidenceModel.decayedVl(st.vl, now - st.updated, cs.decayAmount(), s.decaySeconds());
            if (vl > 0.0) {
                out.add(new CheckView(st.name, st.group, st.category, vl,
                        ConfidenceModel.checkConfidence(vl, cs.maxVl()), st.flags));
            }
        }
        out.sort((a, b) -> Double.compare(b.vl(), a.vl()));
        return out;
    }

    public List<Violation> recent(UUID id) {
        ArrayDeque<Violation> q = recent.get(id);
        return q == null ? List.of() : List.copyOf(q);
    }

    /** Сбрасывает VL игрока (команда /ag punish <ник> reset). */
    public void reset(UUID id) {
        states.remove(id);
        lastWarn.remove(id);
    }

    /** Освобождает память при выходе игрока. */
    public void clear(UUID id) {
        states.remove(id);
        lastWarn.remove(id);
        recent.remove(id);
    }
}
