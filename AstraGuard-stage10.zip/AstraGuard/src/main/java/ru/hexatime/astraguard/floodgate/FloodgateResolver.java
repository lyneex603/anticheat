package ru.hexatime.astraguard.floodgate;

import org.bukkit.entity.Player;
import org.geysermc.floodgate.api.FloodgateApi;
import org.geysermc.floodgate.api.player.FloodgatePlayer;
import ru.hexatime.astraguard.player.PlayerProfile;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Определение Bedrock-игроков через Floodgate API.
 * Класс загружается только если Floodgate установлен (см. ProfileManager), чтобы плагин
 * не падал с NoClassDefFoundError на сервере без Floodgate.
 */
public final class FloodgateResolver implements PlatformResolver {

    private final Logger logger;
    private boolean warned;

    public FloodgateResolver(Logger logger) {
        this.logger = logger;
    }

    @Override
    public PlayerProfile resolve(Player player) {
        long now = System.currentTimeMillis();
        try {
            FloodgatePlayer fp = FloodgateApi.getInstance().getPlayer(player.getUniqueId());
            if (fp != null) {
                return new PlayerProfile(player.getUniqueId(), player.getName(), PlayerProfile.Platform.BEDROCK,
                        String.valueOf(fp.getInputMode()), String.valueOf(fp.getDeviceOs()),
                        String.valueOf(fp.getVersion()), now);
            }
            return new PlayerProfile(player.getUniqueId(), player.getName(), PlayerProfile.Platform.JAVA,
                    "UNKNOWN", "UNKNOWN", "unknown", now);
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                logger.log(Level.WARNING, "Floodgate API недоступен — игрок считается Java. Проверьте версию Floodgate.", t);
            }
            return new PlayerProfile(player.getUniqueId(), player.getName(), PlayerProfile.Platform.JAVA,
                    "UNKNOWN", "UNKNOWN", "unknown", now);
        }
    }
}
