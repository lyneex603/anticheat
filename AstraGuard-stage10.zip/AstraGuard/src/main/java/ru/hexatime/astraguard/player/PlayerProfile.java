package ru.hexatime.astraguard.player;

import java.util.UUID;

/**
 * Профиль игрока: платформа и данные клиента на момент входа.
 * Для Bedrock-игроков хранит способ управления и устройство (из Floodgate).
 */
public final class PlayerProfile {

    public enum Platform { JAVA, BEDROCK }

    private final UUID uuid;
    private final String name;
    private final Platform platform;
    private final String inputMode;
    private final String deviceOs;
    private final String clientVersion;
    private final long joinedAt;

    public PlayerProfile(UUID uuid, String name, Platform platform, String inputMode,
                         String deviceOs, String clientVersion, long joinedAt) {
        this.uuid = uuid;
        this.name = name;
        this.platform = platform;
        this.inputMode = inputMode;
        this.deviceOs = deviceOs;
        this.clientVersion = clientVersion;
        this.joinedAt = joinedAt;
    }

    public UUID uuid() {
        return uuid;
    }

    public String name() {
        return name;
    }

    public Platform platform() {
        return platform;
    }

    public boolean isBedrock() {
        return platform == Platform.BEDROCK;
    }

    /** KEYBOARD_MOUSE, TOUCH, CONTROLLER и т.д. для Bedrock; UNKNOWN для Java. */
    public String inputMode() {
        return inputMode;
    }

    public String deviceOs() {
        return deviceOs;
    }

    /** Версия клиента, если Floodgate её сообщил; иначе "unknown". */
    public String clientVersion() {
        return clientVersion;
    }

    public long joinedAt() {
        return joinedAt;
    }
}
