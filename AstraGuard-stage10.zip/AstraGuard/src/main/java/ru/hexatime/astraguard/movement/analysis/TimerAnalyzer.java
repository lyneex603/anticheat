package ru.hexatime.astraguard.movement.analysis;

import ru.hexatime.astraguard.combat.analysis.Finding;

/**
 * Timer. Клиент шлёт ~20 пакетов движения в секунду; Timer ускоряет это. Считаем «опережение» клиента:
 * каждый кадр +50 мс, минус реально прошедшее время. Паузы дают кредит (до timerCreditMs), чтобы всплеск пакетов
 * после лага сети не флагался. Самая слабая проверка: Bukkit показывает только пакеты с изменением позиции/поворота.
 */
public final class TimerAnalyzer {

    private long last = -1;
    private double ahead;
    private int strikes;

    public void reset() {
        last = -1;
        ahead = 0;
        strikes = 0;
    }

    public Finding onFrame(long nowMs, MoveThresholds t) {
        if (last < 0) {
            last = nowMs;
            return null;
        }
        long dt = Math.max(0, nowMs - last);
        last = nowMs;
        ahead = Math.max(-t.timerCreditMs(), ahead + 50.0 - dt);
        if (ahead <= t.timerLimitMs()) {
            strikes = Math.max(0, strikes - (ahead < 0 ? 1 : 0));
            return null;
        }
        strikes++;
        double shown = ahead;
        ahead = t.timerLimitMs() / 2;
        if (strikes < 3) {
            return null;
        }
        strikes = 1;
        return Finding.of("Timer", "move-timer", 0.5,
                String.format("клиент опережает реальное время на %.0f мс (предел %.0f): пакеты движения идут быстрее 20/с",
                        shown, t.timerLimitMs()),
                "aheadMs", String.format("%.0f", shown), "limitMs", String.format("%.0f", t.timerLimitMs()));
    }
}
