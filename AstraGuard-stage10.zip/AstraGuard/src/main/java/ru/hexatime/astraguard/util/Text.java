package ru.hexatime.astraguard.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Map;

/** Вспомогательные функции для текста: цвета через &amp;, даты, подстановка плейсхолдеров. */
public final class Text {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();
    private static final DateTimeFormatter DATE =
            DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault());
    private static final DateTimeFormatter TIME_MS =
            DateTimeFormatter.ofPattern("HH:mm:ss.SSS").withZone(ZoneId.systemDefault());

    private Text() {
    }

    public static Component color(String legacyAmpersand) {
        return LEGACY.deserialize(legacyAmpersand);
    }

    public static String date(long millis) {
        return millis <= 0 ? "—" : DATE.format(Instant.ofEpochMilli(millis));
    }

    public static String timeMs(long millis) {
        return TIME_MS.format(Instant.ofEpochMilli(millis));
    }

    public static String num(double v) {
        return String.format(Locale.ROOT, "%.1f", v);
    }

    public static String percent(double v) {
        return Math.round(v * 100.0) + "%";
    }

    /** Подставляет {ключ} → значение. */
    public static String fill(String template, Map<String, String> vars) {
        String out = template;
        for (Map.Entry<String, String> e : vars.entrySet()) {
            out = out.replace("{" + e.getKey() + "}", e.getValue());
        }
        return out;
    }
}
