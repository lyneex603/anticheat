package ru.hexatime.astraguard.combat;

import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageAbortEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.combat.analysis.*;
import ru.hexatime.astraguard.player.PlayerProfile;
import ru.hexatime.astraguard.violation.CheckCategory;
import ru.hexatime.astraguard.violation.Flag;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Боевая система. Собирает данные из событий Bukkit в ОСНОВНОМ потоке и отдаёт их чистым анализаторам.
 * <p>
 * Ограничение (честно): сервер видит только то, что Geyser уже превратил в Java-события. Оригинальные
 * Bedrock-пакеты и точные тайминги кликов недоступны, поэтому клики анализируются в тиках сервера,
 * а для тача и геймпада аимбот-проверки по умолчанию выключены.
 * <p>
 * Обработчики используют MONITOR и ignoreCancelled=true: удары, отменённые другими плагинами
 * (лимит КПС в PvPSystem, WorldGuard и т.д.), не проверяются и не наказываются.
 */
public final class CombatManager implements Listener {

    private static final long DIGGING_MAX_TICKS = 400;

    private static final class State {
        final ClickAnalyzer click = new ClickAnalyzer();
        final ReachAnalyzer reach = new ReachAnalyzer();
        final KillAuraAnalyzer killAura = new KillAuraAnalyzer();
        final AimAnalyzer aim = new AimAnalyzer();
        final TriggerBotAnalyzer trigger = new TriggerBotAnalyzer();
        final PositionHistory history = new PositionHistory();
        final ControlClass control;
        int diggingSince = -1;
        int lastUseTick = -1000;
        int ignoreUntilTick;
        int lastVelocityTick = -1000;
        UUID combatTarget;
        int combatUntilTick;

        State(ControlClass control) {
            this.control = control;
        }
    }

    private final AstraGuard plugin;
    private final CombatSettings settings;
    private final Map<UUID, State> states = new HashMap<>();
    private final Attribute interactionRange;

    private int serverStateTick = -100;
    private double tps = 20.0;
    private double mspt = 0.0;

    public CombatManager(AstraGuard plugin) {
        this.plugin = plugin;
        this.settings = new CombatSettings(plugin);
        Attribute a = null;
        try {
            a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft("entity_interaction_range"));
        } catch (Throwable t) {
            plugin.getLogger().warning("Атрибут дальности атаки не найден, Reach будет считаться от 3.0: " + t);
        }
        this.interactionRange = a;
    }

    public void reload() {
        settings.reload();
    }

    public CombatSettings settings() {
        return settings;
    }

    /** Класс управления игрока (для /ag combat). */
    public ControlClass controlOf(Player p) {
        return state(p).control;
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> {
            PlayerProfile pr = plugin.profiles().get(p);
            return new State(ControlClass.of(pr.isBedrock(), pr.inputMode()));
        });
    }

    private void refreshServerState(int tick) {
        if (tick - serverStateTick >= 20) {
            serverStateTick = tick;
            tps = Math.min(20.0, Bukkit.getTPS()[0]);
            mspt = Bukkit.getAverageTickTime();
        }
    }

    /** Условия, при которых боевые данные ненадёжны и игрока не проверяем (вместо ложных флагов). */
    private boolean canAnalyze(Player p, State st, int tick) {
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR || tick < st.ignoreUntilTick) {
            return false;
        }
        refreshServerState(tick);
        if (tps < settings.minTps() || mspt > settings.maxMspt() || p.getPing() > settings.maxPing()) {
            return false;
        }
        PlayerProfile pr = plugin.profiles().get(p);
        return System.currentTimeMillis() - pr.joinedAt() >= settings.warmupMs();
    }

    // ---------------- события, нужные для контекста ----------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        state(e.getPlayer()).ignoreUntilTick = Bukkit.getCurrentTick() + 40;
    }

    /** Отдача/толчок атакующего: его позиция на сервере и у клиента временно расходятся, Reach и Wall пропускаются. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onVelocity(PlayerVelocityEvent e) {
        state(e.getPlayer()).lastVelocityTick = Bukkit.getCurrentTick();
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockDamage(BlockDamageEvent e) {
        state(e.getPlayer()).diggingSince = Bukkit.getCurrentTick();
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockDamageAbort(BlockDamageAbortEvent e) {
        state(e.getPlayer()).diggingSince = -1;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockBreak(BlockBreakEvent e) {
        state(e.getPlayer()).diggingSince = -1;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onInteract(PlayerInteractEvent e) {
        Action a = e.getAction();
        if (a == Action.RIGHT_CLICK_AIR || a == Action.RIGHT_CLICK_BLOCK) {
            state(e.getPlayer()).lastUseTick = Bukkit.getCurrentTick();
        }
    }

    // ---------------- взмахи: AutoClicker ----------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSwing(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) {
            return;
        }
        Player p = e.getPlayer();
        State st = state(p);
        int tick = Bukkit.getCurrentTick();
        // Взмахи при копании и использовании предметов — не клики по врагам
        if (st.diggingSince >= 0 && tick - st.diggingSince <= DIGGING_MAX_TICKS) {
            return;
        }
        if (tick - st.lastUseTick <= 1 || !canAnalyze(p, st, tick)) {
            return;
        }
        emit(p, st, st.click.onSwing(tick, settings.thresholds(st.control)));
    }

    // ---------------- движение: история позиций, поворот, TriggerBot ----------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) {
            return;
        }
        Player p = e.getPlayer();
        State st = state(p);
        int tick = Bukkit.getCurrentTick();
        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            st.history.record(System.currentTimeMillis(), to.getX(), to.getY(), to.getZ());
        }
        if (from.getYaw() != to.getYaw() || from.getPitch() != to.getPitch()) {
            st.aim.onRotation(tick, to.getYaw(), to.getPitch());
        }
        if (st.combatTarget != null && tick <= st.combatUntilTick
                && settings.thresholds(st.control).triggerCheck()) {
            Player target = Bukkit.getPlayer(st.combatTarget);
            if (target != null && target.getWorld().equals(p.getWorld())) {
                double[] l = Geometry.look(to.getYaw(), to.getPitch());
                BoundingBox b = target.getBoundingBox();
                boolean looking = Geometry.rayHitsBox(to.getX(), to.getY() + p.getEyeHeight(), to.getZ(),
                        l[0], l[1], l[2], b.getMinX(), b.getMinY(), b.getMinZ(), b.getMaxX(), b.getMaxY(), b.getMaxZ(), 6.0);
                st.trigger.onLook(tick, target.getEntityId(), looking);
            }
        }
    }

    // ---------------- удары: Reach, KillAura, AimAssist, TriggerBot, Invalid Hit ----------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (e.getCause() != DamageCause.ENTITY_ATTACK
                || !(e.getDamager() instanceof Player attacker) || !(e.getEntity() instanceof Player victim)
                || attacker.equals(victim)) {
            return;
        }
        State st = state(attacker);
        int tick = Bukkit.getCurrentTick();
        boolean analyze = canAnalyze(attacker, st, tick);
        if (analyze) {
            analyzeHit(attacker, st, victim, tick);
        }
        st.combatTarget = victim.getUniqueId();
        st.combatUntilTick = tick + 60;
    }

    private void analyzeHit(Player attacker, State st, Player victim, int tick) {
        Thresholds th = settings.thresholds(st.control);
        Location eye = attacker.getEyeLocation();
        BoundingBox box = victim.getBoundingBox();
        double ex = eye.getX();
        double ey = eye.getY();
        double ez = eye.getZ();

        double current = Geometry.distanceToBox(ex, ey, ez, box.getMinX(), box.getMinY(), box.getMinZ(),
                box.getMaxX(), box.getMaxY(), box.getMaxZ());

        // Reach с компенсацией задержки: берём минимум по позициям цели за время пинга атакующего
        double[] best = {current};
        State vs = states.get(victim.getUniqueId());
        if (vs != null) {
            Location vl = victim.getLocation();
            long since = System.currentTimeMillis() - Math.min(attacker.getPing(), settings.maxPing()) - 100L;
            vs.history.forEachSince(since, (t, x, y, z) -> {
                double dx = x - vl.getX();
                double dy = y - vl.getY();
                double dz = z - vl.getZ();
                best[0] = Math.min(best[0], Geometry.distanceToBox(ex, ey, ez,
                        box.getMinX() + dx, box.getMinY() + dy, box.getMinZ() + dz,
                        box.getMaxX() + dx, box.getMaxY() + dy, box.getMaxZ() + dz));
            });
        }
        // Отдача: окно 3 тика + задержка игрока (до 5 тиков). В это время положение атакующего неточно.
        boolean knocked = tick - st.lastVelocityTick <= 3 + Math.min(5, attacker.getPing() / 50);
        double allowed = reachBase(attacker) + th.reachTolerance();
        if (!knocked) {
            emit(attacker, st, st.reach.onAttack(best[0], allowed));
        }

        // Прицел
        double cx = box.getCenterX() - ex;
        double cy = box.getCenterY() - ey;
        double cz = box.getCenterZ() - ez;
        double[] look = Geometry.look(eye.getYaw(), eye.getPitch());
        double error = Geometry.angleDeg(look[0], look[1], look[2], cx, cy, cz);
        double yawTo = Geometry.yawTo(cx, cz);
        double yawErr = Math.abs(Geometry.wrapDeg(yawTo - eye.getYaw()));
        boolean wall = !knocked && isBlocked(eye, box);

        KillAuraAnalyzer.Hit hit = new KillAuraAnalyzer.Hit(tick, victim.getEntityId(), current, yawTo, yawErr, wall);
        emit(attacker, st, st.killAura.onAttack(hit, th));
        double speed = vs == null ? 0.0 : vs.history.speedPerTick();
        emit(attacker, st, st.aim.onAttack(tick, error, current, speed, th));
        emit(attacker, st, st.trigger.onAttack(tick, victim.getEntityId(), th));
    }

    private double reachBase(Player p) {
        if (interactionRange != null) {
            AttributeInstance inst = p.getAttribute(interactionRange);
            if (inst != null) {
                return inst.getValue();
            }
        }
        return 3.0;
    }

    /** Удар «сквозь стену» только если заблокированы ВСЕ лучи до 5 точек хитбокса (защита от угла и края блока). */
    private boolean isBlocked(Location eye, BoundingBox b) {
        double[][] pts = {
                {b.getCenterX(), b.getCenterY(), b.getCenterZ()},
                {b.getCenterX(), b.getMaxY() - 0.1, b.getCenterZ()},
                {b.getCenterX(), b.getMinY() + 0.1, b.getCenterZ()},
                {b.getMinX() + 0.05, b.getCenterY(), b.getMinZ() + 0.05},
                {b.getMaxX() - 0.05, b.getCenterY(), b.getMaxZ() - 0.05}};
        for (double[] pt : pts) {
            Vector dir = new Vector(pt[0] - eye.getX(), pt[1] - eye.getY(), pt[2] - eye.getZ());
            double len = dir.length();
            if (len < 0.5) {
                return false;
            }
            RayTraceResult r = eye.getWorld().rayTraceBlocks(eye, dir.normalize(), len, FluidCollisionMode.NEVER, true);
            if (r == null) {
                return false;
            }
        }
        return true;
    }

    // ---------------- отправка нарушения ----------------

    private void emit(Player p, State st, Finding f) {
        if (f == null) {
            return;
        }
        Flag flag = Flag.of(f.check(), f.group(), CheckCategory.COMBAT, f.weight(), f.reason());
        for (Map.Entry<String, String> en : f.data().entrySet()) {
            flag = flag.with(en.getKey(), en.getValue());
        }
        flag = flag.with("control", st.control.key())
                .with("tps", String.format("%.2f", tps))
                .with("mspt", String.format("%.1f", mspt));
        plugin.violations().flag(p, flag);
    }
}
