package ru.hexatime.astraguard.potion.analysis;

import java.util.List;

/** Точка расширения: как активные эффекты (в т.ч. будущие кастомные зелья) меняют допустимое движение. */
public interface CustomMovementModifier {
    MovementAdjust adjust(List<EffectState> active);
}
