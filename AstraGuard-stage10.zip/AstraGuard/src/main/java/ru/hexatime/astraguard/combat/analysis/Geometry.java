package ru.hexatime.astraguard.combat.analysis;

/** Геометрия для боевых проверок. Углы в градусах, система координат и yaw/pitch — как в Minecraft. */
public final class Geometry {

    private Geometry() {
    }

    /** Расстояние от точки до ближайшей точки параллелепипеда (0, если точка внутри). */
    public static double distanceToBox(double ox, double oy, double oz,
                                       double minX, double minY, double minZ,
                                       double maxX, double maxY, double maxZ) {
        double dx = Math.max(Math.max(minX - ox, 0.0), ox - maxX);
        double dy = Math.max(Math.max(minY - oy, 0.0), oy - maxY);
        double dz = Math.max(Math.max(minZ - oz, 0.0), oz - maxZ);
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Пересекает ли луч (направление d — единичный вектор) параллелепипед на длине до maxDist. */
    public static boolean rayHitsBox(double ox, double oy, double oz, double dx, double dy, double dz,
                                     double minX, double minY, double minZ,
                                     double maxX, double maxY, double maxZ, double maxDist) {
        double tMin = 0.0;
        double tMax = maxDist;
        double[] o = {ox, oy, oz};
        double[] d = {dx, dy, dz};
        double[] lo = {minX, minY, minZ};
        double[] hi = {maxX, maxY, maxZ};
        for (int i = 0; i < 3; i++) {
            if (Math.abs(d[i]) < 1e-12) {
                if (o[i] < lo[i] || o[i] > hi[i]) {
                    return false;
                }
            } else {
                double t1 = (lo[i] - o[i]) / d[i];
                double t2 = (hi[i] - o[i]) / d[i];
                if (t1 > t2) {
                    double tmp = t1;
                    t1 = t2;
                    t2 = tmp;
                }
                tMin = Math.max(tMin, t1);
                tMax = Math.min(tMax, t2);
                if (tMin > tMax) {
                    return false;
                }
            }
        }
        return true;
    }

    /** Единичный вектор взгляда по yaw/pitch Minecraft. */
    public static double[] look(double yawDeg, double pitchDeg) {
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        double cp = Math.cos(pitch);
        return new double[]{-Math.sin(yaw) * cp, -Math.sin(pitch), Math.cos(yaw) * cp};
    }

    /** Угол между двумя векторами (не обязательно единичными). */
    public static double angleDeg(double ax, double ay, double az, double bx, double by, double bz) {
        double la = Math.sqrt(ax * ax + ay * ay + az * az);
        double lb = Math.sqrt(bx * bx + by * by + bz * bz);
        if (la < 1e-12 || lb < 1e-12) {
            return 0.0;
        }
        double cos = (ax * bx + ay * by + az * bz) / (la * lb);
        return Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, cos))));
    }

    /** Приводит угол к диапазону (-180; 180]. */
    public static double wrapDeg(double a) {
        double r = a % 360.0;
        if (r > 180.0) {
            r -= 360.0;
        } else if (r <= -180.0) {
            r += 360.0;
        }
        return r;
    }

    /** yaw направления на точку со смещением (dx, dz). */
    public static double yawTo(double dx, double dz) {
        return Math.toDegrees(Math.atan2(-dx, dz));
    }
}
