package ru.hexatime.astraguard.combat.analysis;

/**
 * AimAssist и Suspicious Rotation. Использует поворот камеры по тикам и ошибку прицела в момент удара
 * (угол между взглядом и центром хитбокса цели).
 * <ul>
 *   <li>AimAssist-Snap: резкий поворот прямо перед ударом, после которого прицел точно в центре цели;</li>
 *   <li>AimAssist-Lock: ошибка прицела в серии ударов стабильно близка к нулю;</li>
 *   <li>Rotation-Smooth: поворот с почти одинаковой скоростью несколько тиков подряд (человек так не двигает мышь).</li>
 * </ul>
 * На Bedrock с тачем или геймпадом анализ отключён (aimChecks=false): там есть встроенная помощь прицеливания.
 */
public final class AimAnalyzer {

    private static final int ROT = 8;
    private static final int ERR = 12;

    private final int[] rotTick = new int[ROT];
    private final float[] rotYaw = new float[ROT];
    private final float[] rotPitch = new float[ROT];
    private int rotHead;
    private int rotCount;

    private final double[] errors = new double[ERR];
    private int errCount;
    private final boolean[] snaps = new boolean[15];
    private int snapHead;
    private int lastSmoothTick = -1_000_000;

    public void onRotation(int tick, float yaw, float pitch) {
        rotTick[rotHead] = tick;
        rotYaw[rotHead] = yaw;
        rotPitch[rotHead] = pitch;
        rotHead = (rotHead + 1) % ROT;
        rotCount = Math.min(ROT, rotCount + 1);
    }

    private int idx(int back) {
        return (rotHead - 1 - back + ROT * 2) % ROT;
    }

    /** Суммарный угол поворота за последние ticks тиков до тика tick. */
    double rotationWithin(int tick, int ticks) {
        double total = 0;
        for (int i = 0; i + 1 < rotCount; i++) {
            int a = idx(i);
            int b = idx(i + 1);
            if (tick - rotTick[a] > ticks) {
                break;
            }
            double dy = Geometry.wrapDeg(rotYaw[a] - rotYaw[b]);
            double dp = rotPitch[a] - rotPitch[b];
            total += Math.sqrt(dy * dy + dp * dp);
        }
        return total;
    }

    public Finding onAttack(int tick, double errorDeg, double distance, double targetSpeedPerTick, Thresholds t) {
        if (!t.aimChecks() || distance < 1.5) {
            return null;
        }
        Finding smooth = checkSmooth(tick);

        boolean snap = rotationWithin(tick, 2) >= 35.0 && errorDeg <= 1.0;
        snaps[snapHead] = snap;
        snapHead = (snapHead + 1) % snaps.length;
        if (snap) {
            int n = 0;
            for (boolean b : snaps) {
                if (b) {
                    n++;
                }
            }
            if (n >= 3) {
                java.util.Arrays.fill(snaps, false);
                return Finding.of("AimAssist-Snap", "combat-aim", 1.0,
                        "3 резких наведения с последующим попаданием в центр цели (ошибка ≤ 1°)",
                        "lastError", String.format("%.2f", errorDeg));
            }
        }

        if (targetSpeedPerTick > 0.08) {
            errors[errCount++] = errorDeg;
            if (errCount == ERR) {
                errCount = 0;
                double mean = 0;
                for (double e : errors) {
                    mean += e;
                }
                mean /= ERR;
                double var = 0;
                for (double e : errors) {
                    var += (e - mean) * (e - mean);
                }
                double std = Math.sqrt(var / ERR);
                if (mean < 0.9 && std < 0.45) {
                    return Finding.of("AimAssist-Lock", "combat-aim", 1.0,
                            String.format("прицел «приклеен» к движущейся цели: средняя ошибка %.2f° (σ %.2f°) за %d ударов", mean, std, ERR),
                            "meanError", String.format("%.3f", mean), "std", String.format("%.3f", std));
                }
            }
        }
        return smooth;
    }

    private Finding checkSmooth(int tick) {
        if (rotCount < 6 || tick - lastSmoothTick < 20) {
            return null;
        }
        double[] d = new double[5];
        for (int i = 0; i < 5; i++) {
            int a = idx(i);
            int b = idx(i + 1);
            if (rotTick[a] - rotTick[b] != 1 || tick - rotTick[idx(0)] > 2) {
                return null; // повороты должны идти подряд по тикам
            }
            d[i] = Math.abs(Geometry.wrapDeg(rotYaw[a] - rotYaw[b]));
            if (d[i] < 2.0) {
                return null;
            }
        }
        double mean = 0;
        for (double v : d) {
            mean += v;
        }
        mean /= d.length;
        double var = 0;
        for (double v : d) {
            var += (v - mean) * (v - mean);
        }
        double std = Math.sqrt(var / d.length);
        if (std < 0.03) {
            lastSmoothTick = tick;
            return Finding.of("Rotation-Smooth", "combat-aim", 0.8,
                    String.format("поворот с одинаковой скоростью %.2f°/тик 5 тиков подряд (σ %.3f)", mean, std),
                    "yawPerTick", String.format("%.3f", mean), "std", String.format("%.4f", std));
        }
        return null;
    }
}
