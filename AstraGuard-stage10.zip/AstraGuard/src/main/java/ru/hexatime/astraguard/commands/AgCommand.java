package ru.hexatime.astraguard.commands;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.checks.CheckRegistry;
import ru.hexatime.astraguard.config.Settings;
import ru.hexatime.astraguard.database.Database;
import ru.hexatime.astraguard.evidence.Evidence;
import ru.hexatime.astraguard.player.PlayerProfile;
import ru.hexatime.astraguard.punishment.BanRecord;
import ru.hexatime.astraguard.util.Text;
import ru.hexatime.astraguard.violation.CheckCategory;
import ru.hexatime.astraguard.violation.Flag;
import ru.hexatime.astraguard.violation.Violation;
import ru.hexatime.astraguard.violation.ViolationManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletionException;
import java.util.function.Consumer;
import java.util.logging.Level;

/** Команда /ag. Для каждой подкоманды отдельное право astraguard.command.&lt;имя&gt;. */
public final class AgCommand implements CommandExecutor, TabCompleter {

    private static final String PREFIX = "&8[&cAstraGuard&8] &7";

    private static final Map<String, String> HELP = new LinkedHashMap<>();

    static {
        HELP.put("help", "/ag help &8— список команд");
        HELP.put("alerts", "/ag alerts &8— включить/выключить оповещения");
        HELP.put("info", "/ag info <игрок> &8— общая информация");
        HELP.put("combat", "/ag combat <игрок> &8— боевые нарушения");
        HELP.put("movement", "/ag movement <игрок> &8— нарушения движения");
        HELP.put("world", "/ag world <игрок> &8— нарушения взаимодействия с миром");
        HELP.put("enchant", "/ag enchant <игрок> &8— снаряжение: чары, урон, защита (онлайн)");
        HELP.put("potion", "/ag potion <игрок> &8— активные эффекты и их влияние (онлайн)");
        HELP.put("violations", "/ag violations <игрок> &8— все нарушения");
        HELP.put("logs", "/ag logs <игрок> [evidence] &8— история и доказательства");
        HELP.put("debug", "/ag debug <игрок> &8— отладка (онлайн)");
        HELP.put("profile", "/ag profile <игрок> &8— платформа и клиент");
        HELP.put("checks", "/ag checks &8— список проверок");
        HELP.put("reload", "/ag reload &8— перезагрузить конфиг");
        HELP.put("test", "/ag test <игрок> &8— тестовый флаг (без наказания)");
        HELP.put("ban", "/ag ban <игрок> <причина> &8— ручной бан");
        HELP.put("unban", "/ag unban <игрок> &8— снять бан");
        HELP.put("baninfo", "/ag baninfo <игрок> &8— информация о бане");
        HELP.put("banlist", "/ag banlist [страница] &8— список банов");
        HELP.put("punish", "/ag punish <игрок> [reset] &8— история наказаний / сброс VL");
    }

    private record Target(UUID uuid, String name, Player online) {
    }

    private record InfoData(Database.PlayerRow row, int violations, BanRecord ban) {
    }

    private record ViolationsData(List<Violation> list) {
    }

    private final AstraGuard plugin;

    public AgCommand(AstraGuard plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ диспетчер

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String sub = a.length == 0 ? "help" : a[0].toLowerCase(Locale.ROOT);
        if (!HELP.containsKey(sub)) {
            sub = "help";
        }
        if (!s.hasPermission("astraguard.command." + sub)) {
            msg(s, "&cНет прав на эту команду.");
            return true;
        }
        String[] args = a.length > 1 ? Arrays.copyOfRange(a, 1, a.length) : new String[0];
        try {
            switch (sub) {
                case "help" -> help(s);
                case "alerts" -> alerts(s);
                case "info" -> info(s, args);
                case "combat" -> violations(s, args, CheckCategory.COMBAT);
                case "movement" -> violations(s, args, CheckCategory.MOVEMENT);
                case "world" -> violations(s, args, CheckCategory.WORLD);
                case "enchant" -> enchant(s, args);
                case "potion" -> potion(s, args);
                case "violations" -> violations(s, args, null);
                case "logs" -> logs(s, args);
                case "debug" -> debug(s, args);
                case "profile" -> profile(s, args);
                case "checks" -> checks(s);
                case "reload" -> reload(s);
                case "test" -> test(s, args);
                case "ban" -> ban(s, args);
                case "unban" -> unban(s, args);
                case "baninfo" -> baninfo(s, args);
                case "banlist" -> banlist(s, args);
                case "punish" -> punish(s, args);
                default -> help(s);
            }
        } catch (Exception e) {
            msg(s, "&cОшибка: &f" + e.getMessage());
            plugin.getLogger().log(Level.WARNING, "Ошибка команды /ag " + sub, e);
        }
        return true;
    }

    // ------------------------------------------------------------------ вспомогательное

    private void msg(CommandSender s, String legacy) {
        s.sendMessage(Text.color(PREFIX + legacy));
    }

    private void raw(CommandSender s, String legacy) {
        s.sendMessage(Text.color(legacy));
    }

    private void runMain(Runnable r) {
        if (plugin.isEnabled()) {
            Bukkit.getScheduler().runTask(plugin, r);
        }
    }

    private static Throwable root(Throwable t) {
        while (t instanceof CompletionException && t.getCause() != null) {
            t = t.getCause();
        }
        return t;
    }

    /** Выполняет запрос к БД вне основного потока и показывает результат в основном. */
    private <T> void query(CommandSender s, Database.SqlCall<T> call, Consumer<T> ui) {
        plugin.database().supply(call).whenComplete((res, ex) -> runMain(() -> {
            if (ex != null) {
                msg(s, "&cОшибка базы данных: &f" + root(ex).getMessage());
                plugin.getLogger().log(Level.WARNING, "Ошибка запроса команды", ex);
            } else {
                ui.accept(res);
            }
        }));
    }

    private void withTarget(CommandSender s, String[] args, String usage, Consumer<Target> action) {
        if (args.length < 1) {
            msg(s, "Использование: &f" + usage);
            return;
        }
        String name = args[0];
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            action.accept(new Target(online.getUniqueId(), online.getName(), online));
            return;
        }
        query(s, () -> plugin.database().resolveUuid(name), uuid -> {
            if (uuid != null) {
                action.accept(new Target(uuid, name, null));
                return;
            }
            OfflinePlayer cached = Bukkit.getOfflinePlayerIfCached(name);
            if (cached != null) {
                action.accept(new Target(cached.getUniqueId(),
                        cached.getName() != null ? cached.getName() : name, null));
            } else {
                msg(s, "&cИгрок не найден: &f" + name + " &7(он должен хотя бы раз зайти на сервер)");
            }
        });
    }

    private static String bar(double v) {
        return Text.percent(v);
    }

    // ------------------------------------------------------------------ подкоманды

    private void help(CommandSender s) {
        raw(s, "&8&m      &r &cAstraGuard &7— команды &8&m      ");
        for (Map.Entry<String, String> e : HELP.entrySet()) {
            if (s.hasPermission("astraguard.command." + e.getKey())) {
                raw(s, "&c" + e.getValue());
            }
        }
    }

    private void alerts(CommandSender s) {
        if (!(s instanceof Player p)) {
            msg(s, "&cЭта команда только для игроков.");
            return;
        }
        boolean on = plugin.alerts().toggle(p.getUniqueId());
        msg(s, "Оповещения " + (on ? "&aвключены" : "&cвыключены") + "&7 (до выхода с сервера).");
    }

    private void info(CommandSender s, String[] args) {
        withTarget(s, args, "/ag info <игрок>", t -> query(s,
                () -> new InfoData(plugin.database().getPlayer(t.uuid()),
                        plugin.database().countViolations(t.uuid()),
                        plugin.database().findLatestBan(t.uuid())),
                d -> {
                    raw(s, "&8&m      &r &c" + t.name() + " &8&m      ");
                    raw(s, "&7Статус: " + (t.online() != null ? "&aонлайн" : "&7оффлайн"));
                    if (t.online() != null) {
                        PlayerProfile pr = plugin.profiles().get(t.online());
                        raw(s, "&7Платформа: &f" + pr.platform() + " &7Пинг: &f" + t.online().getPing() + "мс");
                    } else if (d.row() != null) {
                        raw(s, "&7Платформа: &f" + d.row().platform() + " &7Последний вход: &f" + Text.date(d.row().lastSeen()));
                    }
                    raw(s, "&7Нарушений в базе: &f" + d.violations());
                    raw(s, "&7Бан: " + banLine(d.ban()));
                }));
    }

    private String banLine(BanRecord b) {
        if (b == null) {
            return "&aнет";
        }
        long now = System.currentTimeMillis();
        boolean act = b.active() && !b.expired(now);
        return (act ? "&cактивен до &f" + Text.date(b.expiresAt()) : "&7был (#" + b.id() + ", снят/истёк)");
    }

    private void violations(CommandSender s, String[] args, CheckCategory category) {
        String usage = category == null ? "/ag violations <игрок>"
                : category == CheckCategory.MOVEMENT ? "/ag movement <игрок>"
                : category == CheckCategory.WORLD ? "/ag world <игрок>" : "/ag combat <игрок>";
        withTarget(s, args, usage, t -> query(s,
                () -> new ViolationsData(plugin.database().listViolations(t.uuid(), 10, category)),
                d -> {
                    String title = category == null ? "Нарушения"
                            : category == CheckCategory.MOVEMENT ? "Нарушения движения"
                            : category == CheckCategory.WORLD ? "Нарушения в мире" : "Боевые нарушения";
                    raw(s, "&8&m      &r &c" + title + " &7— " + t.name() + " &8&m      ");
                    if (t.online() != null) {
                        List<ViolationManager.CheckView> live = plugin.violations().snapshot(t.uuid());
                        boolean any = false;
                        for (ViolationManager.CheckView v : live) {
                            if (category != null && v.category() != category) {
                                continue;
                            }
                            any = true;
                            raw(s, "&7Сейчас: &c" + v.check() + " &7VL &f" + Text.num(v.vl())
                                    + " &7уверенность &f" + bar(v.confidence()) + " &7флагов &f" + v.flags());
                        }
                        if (!any) {
                            raw(s, "&7Сейчас активных нарушений нет.");
                        }
                    }
                    if (d.list().isEmpty()) {
                        raw(s, "&7В истории нарушений нет.");
                    }
                    for (Violation v : d.list()) {
                        raw(s, "&8" + Text.date(v.time()) + " " + (v.test() ? "&e[TEST] " : "") + "&c" + v.check()
                                + " &7VL &f" + Text.num(v.vl()) + " &7(" + bar(v.confidence()) + ") &8— &7" + v.reason());
                    }
                }));
    }

    private void logs(CommandSender s, String[] args) {
        boolean evidenceMode = args.length > 1 && args[1].equalsIgnoreCase("evidence");
        withTarget(s, args, "/ag logs <игрок> [evidence]", t -> {
            if (evidenceMode) {
                query(s, () -> plugin.database().listEvidence(t.uuid(), 3), list -> {
                    raw(s, "&8&m      &r &cДоказательства &7— " + t.name() + " &8&m      ");
                    if (list.isEmpty()) {
                        raw(s, "&7Доказательств нет.");
                    }
                    for (Evidence e : list) {
                        raw(s, "&c" + e.check() + " &8" + Text.date(e.time()) + " &7VL &f" + Text.num(e.vl())
                                + " &7пинг &f" + e.ping() + " &7TPS &f" + Text.num(e.tps())
                                + " &7MSPT &f" + Text.num(e.mspt()) + " &7" + e.platform() + " &f" + e.clientVersion());
                        if (!e.context().isEmpty()) {
                            for (String line : e.context().split("\n")) {
                                raw(s, "&8  • &7" + line);
                            }
                        }
                        String[] trace = e.trace().isEmpty() ? new String[0] : e.trace().split("\n");
                        int from = Math.max(0, trace.length - 12);
                        for (int i = from; i < trace.length; i++) {
                            raw(s, "&8  ▸ &7" + trace[i]);
                        }
                    }
                });
            } else {
                query(s, () -> plugin.database().listViolations(t.uuid(), 15, null), list -> {
                    raw(s, "&8&m      &r &cЖурнал &7— " + t.name() + " &8&m      ");
                    if (list.isEmpty()) {
                        raw(s, "&7Записей нет.");
                    }
                    for (Violation v : list) {
                        raw(s, "&8" + Text.date(v.time()) + " " + (v.test() ? "&e[TEST] " : "") + "&c" + v.check()
                                + " &7VL &f" + Text.num(v.vl()) + " &7пинг &f" + v.ping() + " &8— &7" + v.reason());
                    }
                    raw(s, "&8Подробности: &7/ag logs " + t.name() + " evidence");
                });
            }
        });
    }

    private void debug(CommandSender s, String[] args) {
        withTarget(s, args, "/ag debug <игрок>", t -> {
            if (t.online() == null) {
                msg(s, "&cОтладка доступна только для игроков онлайн.");
                return;
            }
            Player p = t.online();
            PlayerProfile pr = plugin.profiles().get(p);
            Settings st = plugin.settings();
            raw(s, "&8&m      &r &cDebug &7— " + p.getName() + " &8&m      ");
            raw(s, "&7Платформа: &f" + pr.platform() + " &7Ввод: &f" + pr.inputMode() + " &7Устройство: &f" + pr.deviceOs());
            raw(s, "&7Клиент: &f" + pr.clientVersion() + " &7Пинг: &f" + p.getPing() + "мс");
            raw(s, "&7Floodgate: &f" + (plugin.profiles().floodgatePresent() ? "найден" : "не найден")
                    + " &7Geyser: &f" + plugin.geyser().version());
            raw(s, "&7TPS: &f" + Text.num(Math.min(20.0, Bukkit.getTPS()[0])) + " &7MSPT: &f" + Text.num(Bukkit.getAverageTickTime()));
            ViolationManager.Summary sum = plugin.violations().summarize(t.uuid(), System.currentTimeMillis());
            raw(s, "&7Независимых групп: &f" + sum.independent() + "&7/&f" + st.minIndependentChecks()
                    + " &7общая уверенность: &f" + bar(sum.combined()) + "&7/&f" + bar(st.minCombinedConfidence()));
            raw(s, "&7Автобан: " + (st.autoBanEnabled() ? "&aвключён" : "&cвыключен") + " &7срок: &f" + st.banDays() + " дн.");
            for (ViolationManager.CheckView v : plugin.violations().snapshot(t.uuid())) {
                raw(s, "&8 • &c" + v.check() + " &7[" + v.group() + "] VL &f" + Text.num(v.vl())
                        + " &7(" + bar(v.confidence()) + ") флагов &f" + v.flags());
            }
        });
    }

    private void profile(CommandSender s, String[] args) {
        withTarget(s, args, "/ag profile <игрок>", t -> query(s, () -> plugin.database().getPlayer(t.uuid()), row -> {
            raw(s, "&8&m      &r &cПрофиль &7— " + t.name() + " &8&m      ");
            raw(s, "&7UUID: &f" + t.uuid());
            if (t.online() != null) {
                PlayerProfile pr = plugin.profiles().get(t.online());
                raw(s, "&7Платформа: &f" + pr.platform());
                raw(s, "&7Ввод: &f" + pr.inputMode() + " &7Устройство: &f" + pr.deviceOs());
                raw(s, "&7Клиент: &f" + pr.clientVersion());
            } else if (row != null) {
                raw(s, "&7Платформа: &f" + row.platform() + " &7Клиент: &f" + row.clientVersion());
            }
            if (row != null) {
                raw(s, "&7Первый вход: &f" + Text.date(row.firstSeen()) + " &7Последний: &f" + Text.date(row.lastSeen()));
            } else {
                raw(s, "&7В базе записей об игроке нет.");
            }
        }));
    }

    private void enchant(CommandSender s, String[] args) {
        if (args.length < 1) {
            msg(s, "Использование: &f/ag enchant <игрок>");
            return;
        }
        Player p = Bukkit.getPlayerExact(args[0]);
        if (p == null) {
            msg(s, "&cИгрок должен быть онлайн.");
            return;
        }
        raw(s, "&8&m      &r &cСнаряжение &7— " + p.getName() + " &8&m      ");
        for (String line : plugin.enchants().report(p)) {
            raw(s, line);
        }
    }

    private void potion(CommandSender s, String[] args) {
        if (args.length < 1) {
            msg(s, "Использование: &f/ag potion <игрок>");
            return;
        }
        Player p = Bukkit.getPlayerExact(args[0]);
        if (p == null) {
            msg(s, "&cИгрок должен быть онлайн.");
            return;
        }
        raw(s, "&8&m      &r &cЭффекты &7— " + p.getName() + " &8&m      ");
        for (String line : plugin.potions().report(p)) {
            raw(s, line);
        }
    }

    private void checks(CommandSender s) {
        raw(s, "&8&m      &r &cПроверки &8&m      ");
        for (CheckRegistry.CheckInfo c : plugin.registry().all()) {
            Settings.CheckSettings cs = plugin.settings().check(c.name());
            raw(s, (cs.enabled() ? "&a✔ " : "&c✘ ") + "&f" + c.name() + " &7[" + c.category().title() + "/" + c.group()
                    + "] max-vl &f" + Text.num(cs.maxVl()) + " &8— &7" + c.description());
        }
    }

    private void reload(CommandSender s) {
        plugin.settings().reload();
        plugin.combat().reload();
        plugin.movement().reload();
        plugin.world().reload();
        plugin.enchants().reload();
        plugin.potions().reload();
        msg(s, "&aКонфигурация перезагружена. &7(Тип БД меняется только после перезапуска сервера.)");
    }

    private void test(CommandSender s, String[] args) {
        withTarget(s, args, "/ag test <игрок>", t -> {
            if (t.online() == null) {
                msg(s, "&cИгрок должен быть онлайн.");
                return;
            }
            Flag flag = Flag.of("Test", "test", CheckCategory.SYSTEM, 5.0,
                            "Тестовый флаг из /ag test: проверка оповещений и записи в БД")
                    .with("sender", s.getName())
                    .asTest();
            plugin.evidence().trace(t.uuid(), "test", "флаг вызван командой /ag test");
            plugin.violations().flag(t.online(), flag);
            msg(s, "Тестовый флаг отправлен. Он попадёт в оповещения и журнал, но никогда не приведёт к наказанию.");
        });
    }

    private void ban(CommandSender s, String[] args) {
        if (args.length < 2) {
            msg(s, "Использование: &f/ag ban <игрок> <причина>");
            return;
        }
        String reason = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        withTarget(s, args, "/ag ban <игрок> <причина>", t ->
                plugin.punishments().ban(t.uuid(), t.name(), reason, s.getName(), false)
                        .whenComplete((res, ex) -> runMain(() -> {
                            if (ex != null) {
                                msg(s, "&cНе удалось выдать бан: &f" + root(ex).getMessage());
                            } else if (res.alreadyBanned()) {
                                msg(s, "&cИгрок уже забанен до &f" + Text.date(res.record().expiresAt()));
                            } else {
                                msg(s, "&aИгрок &f" + t.name() + " &aзабанен до &f" + Text.date(res.record().expiresAt()));
                            }
                        })));
    }

    private void unban(CommandSender s, String[] args) {
        withTarget(s, args, "/ag unban <игрок>", t ->
                plugin.punishments().unban(t.uuid(), t.name(), s.getName())
                        .whenComplete((ok, ex) -> runMain(() -> {
                            if (ex != null) {
                                msg(s, "&cНе удалось снять бан: &f" + root(ex).getMessage());
                            } else if (ok) {
                                msg(s, "&aБан игрока &f" + t.name() + " &aснят.");
                            } else {
                                msg(s, "&cУ игрока нет активного бана.");
                            }
                        })));
    }

    private void baninfo(CommandSender s, String[] args) {
        withTarget(s, args, "/ag baninfo <игрок>", t ->
                plugin.punishments().latestBan(t.uuid()).whenComplete((b, ex) -> runMain(() -> {
                    if (ex != null) {
                        msg(s, "&cОшибка базы данных: &f" + root(ex).getMessage());
                        return;
                    }
                    if (b == null) {
                        msg(s, "&aУ игрока &f" + t.name() + " &aбанов не было.");
                        return;
                    }
                    boolean act = b.active() && !b.expired(System.currentTimeMillis());
                    raw(s, "&8&m      &r &cБан #" + b.id() + " &7— " + b.name() + " &8&m      ");
                    raw(s, "&7Статус: " + (act ? "&cактивен" : "&7неактивен"));
                    raw(s, "&7Причина: &f" + b.reason());
                    raw(s, "&7Выдал: &f" + b.issuedBy() + " &7Дата: &f" + Text.date(b.issuedAt()));
                    raw(s, "&7Действует до: &f" + Text.date(b.expiresAt()));
                    if (b.removedAt() > 0) {
                        raw(s, "&7Снят: &f" + b.removedBy() + " &7" + Text.date(b.removedAt()));
                    }
                })));
    }

    private void banlist(CommandSender s, String[] args) {
        int page = 1;
        if (args.length > 0) {
            try {
                page = Math.max(1, Integer.parseInt(args[0]));
            } catch (NumberFormatException e) {
                msg(s, "Использование: &f/ag banlist [страница]");
                return;
            }
        }
        final int pg = page;
        plugin.punishments().activeBans(200).whenComplete((list, ex) -> runMain(() -> {
            if (ex != null) {
                msg(s, "&cОшибка базы данных: &f" + root(ex).getMessage());
                return;
            }
            int pages = Math.max(1, (list.size() + 9) / 10);
            raw(s, "&8&m      &r &cБаны &7(" + list.size() + ") стр. " + Math.min(pg, pages) + "/" + pages + " &8&m      ");
            int from = (Math.min(pg, pages) - 1) * 10;
            for (int i = from; i < Math.min(list.size(), from + 10); i++) {
                BanRecord b = list.get(i);
                raw(s, "&8#" + b.id() + " &c" + b.name() + " &7до &f" + Text.date(b.expiresAt()) + " &8— &7" + b.reason());
            }
            if (list.isEmpty()) {
                raw(s, "&7Активных банов нет.");
            }
        }));
    }

    private void punish(CommandSender s, String[] args) {
        boolean reset = args.length > 1 && args[1].equalsIgnoreCase("reset");
        withTarget(s, args, "/ag punish <игрок> [reset]", t -> {
            if (reset) {
                plugin.violations().reset(t.uuid());
                msg(s, "&aVL игрока &f" + t.name() + " &aсброшены.");
                return;
            }
            plugin.punishments().history(t.uuid(), 10).whenComplete((list, ex) -> runMain(() -> {
                if (ex != null) {
                    msg(s, "&cОшибка базы данных: &f" + root(ex).getMessage());
                    return;
                }
                raw(s, "&8&m      &r &cНаказания &7— " + t.name() + " &8&m      ");
                if (list.isEmpty()) {
                    raw(s, "&7Наказаний не было.");
                }
                for (Database.HistoryEntry h : list) {
                    raw(s, "&8" + Text.date(h.time()) + " &c" + h.action() + " &7(" + h.actor() + ") &8— &7" + h.reason());
                }
                raw(s, "&8Команды: &7/ag ban, /ag unban, /ag punish " + t.name() + " reset");
            }));
        });
    }

    // ------------------------------------------------------------------ автодополнение

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            for (String sub : HELP.keySet()) {
                if (s.hasPermission("astraguard.command." + sub) && sub.startsWith(a[0].toLowerCase(Locale.ROOT))) {
                    out.add(sub);
                }
            }
        } else if (a.length == 2 && List.of("info", "combat", "movement", "world", "enchant", "potion", "violations", "logs", "debug", "profile", "test",
                "ban", "unban", "baninfo", "punish").contains(a[0].toLowerCase(Locale.ROOT))) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) {
                    out.add(p.getName());
                }
            }
        } else if (a.length == 3 && a[0].equalsIgnoreCase("logs")) {
            out.add("evidence");
        } else if (a.length == 3 && a[0].equalsIgnoreCase("punish")) {
            out.add("reset");
        }
        return out;
    }
}
