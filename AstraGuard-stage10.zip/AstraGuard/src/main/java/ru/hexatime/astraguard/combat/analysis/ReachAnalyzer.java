package ru.hexatime.astraguard.combat.analysis;

/**
 * Reach. Дистанция уже скомпенсирована по задержке (минимум по истории позиций цели за время пинга),
 * поэтому здесь только решение «превышение» с буфером против одиночных выбросов.
 */
public final class ReachAnalyzer {

    private double buffer;

    /**
     * @param distance минимальная дистанция от глаз атакующего до хитбокса цели
     * @param allowed  разрешённая дистанция: базовая дальность + бонус атрибутов + запас профиля
     */
    public Finding onAttack(double distance, double allowed) {
        if (distance > allowed) {
            double excess = distance - allowed;
            buffer += 1.0 + Math.min(1.0, excess);
            if (buffer >= 2.0) {
                buffer = 1.0;
                return Finding.of("Reach", "combat-reach", 1.0 + Math.min(2.0, excess * 2.0),
                        String.format("дистанция удара %.2f при допустимых %.2f (превышение %.2f)", distance, allowed, excess),
                        "distance", String.format("%.3f", distance), "allowed", String.format("%.3f", allowed));
            }
        } else {
            buffer = Math.max(0.0, buffer - 0.25);
        }
        return null;
    }
}
