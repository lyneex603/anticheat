package ru.hexatime.astraguard.enchant;

import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Обычные зачарования предмета. CustomEnchants хранит Protection V, Sharpness VII, Efficiency X и т.п. именно так
 * (ванильное зачарование повышенного уровня), поэтому отдельный API для них не нужен.
 */
public final class VanillaEnchantProvider implements EnchantProvider {

    @Override
    public String id() {
        return "vanilla";
    }

    @Override
    public Map<String, Integer> read(ItemStack item) {
        Map<String, Integer> out = new LinkedHashMap<>();
        for (Map.Entry<Enchantment, Integer> e : item.getEnchantments().entrySet()) {
            out.put(e.getKey().getKey().asString(), e.getValue());
        }
        return out;
    }
}
