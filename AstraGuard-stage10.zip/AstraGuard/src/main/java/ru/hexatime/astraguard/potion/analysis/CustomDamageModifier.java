package ru.hexatime.astraguard.potion.analysis;

import java.util.List;

/** Точка расширения: как активные эффекты (в т.ч. будущие кастомные зелья) меняют наносимый и получаемый урон. */
public interface CustomDamageModifier {
    DamageAdjust adjust(List<EffectState> active);
}
