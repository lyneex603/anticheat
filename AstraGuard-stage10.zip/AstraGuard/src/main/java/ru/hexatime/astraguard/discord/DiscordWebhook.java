package ru.hexatime.astraguard.discord;

import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.config.Settings;
import ru.hexatime.astraguard.punishment.BanRecord;
import ru.hexatime.astraguard.util.Text;
import ru.hexatime.astraguard.violation.Violation;
import ru.hexatime.astraguard.violation.ViolationManager;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;

/**
 * Необязательная отправка уведомлений в Discord Webhook.
 * <p>
 * Запросы идут через асинхронный {@link HttpClient}, основной поток сервера не блокируется. Отправка ограничена
 * по частоте (Discord отвечает 429 при спаме), очередь ограничена, лишнее отбрасывается. Адрес вебхука — секрет:
 * он никогда не пишется в лог и в сообщения.
 */
public final class DiscordWebhook {

    /** Типы уведомлений; у каждого свой переключатель в config.yml (discord.events.*). */
    public enum Event {
        VIOLATION("violation", 0xE67E22, "Подтверждённое нарушение"),
        WARNING("warning", 0xF1C40F, "Предупреждение администрации"),
        AUTO_BAN("auto-ban", 0xC0392B, "Автоматический бан"),
        MANUAL_BAN("manual-ban", 0x992D22, "Ручной бан"),
        UNBAN("unban", 0x2ECC71, "Снятие бана"),
        CRITICAL("critical-error", 0x8E44AD, "Критическая ошибка AstraGuard");

        final String key;
        final int color;
        final String title;

        Event(String key, int color, String title) {
            this.key = key;
            this.color = color;
            this.title = title;
        }
    }

    private static final int MAX_PENDING = 25;
    private static final long MIN_INTERVAL_MS = 700;

    private final AstraGuard plugin;
    private final HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private final AtomicInteger pending = new AtomicInteger();
    private final Map<String, Long> lastViolation = new ConcurrentHashMap<>();
    private long nextSlot; // только под synchronized(this)
    private volatile long lastFailLog;
    private volatile long lastCritical;

    public DiscordWebhook(AstraGuard plugin) {
        this.plugin = plugin;
    }

    private boolean active(Event e) {
        Settings s = plugin.settings();
        return s.discordEnabled() && !s.discordUrl().isBlank() && s.discordEventEnabled(e.key);
    }

    // ------------------------------------------------------------------ события

    /** Нарушение с уверенностью не ниже порога; не чаще раза в N секунд на пару «игрок + проверка». */
    public void violation(Violation v, ViolationManager.Summary sum) {
        if (v.test() || !active(Event.VIOLATION) || v.confidence() < plugin.settings().discordMinConfidence()) {
            return;
        }
        long now = System.currentTimeMillis();
        String key = v.uuid() + "|" + v.check();
        Long last = lastViolation.get(key);
        if (last != null && now - last < plugin.settings().discordViolationCooldownMs()) {
            return;
        }
        lastViolation.put(key, now);
        if (lastViolation.size() > 2000) {
            long limit = plugin.settings().discordViolationCooldownMs();
            lastViolation.values().removeIf(t -> now - t > limit);
        }
        send(Event.VIOLATION, "**" + v.name() + "** — " + v.check() + " (" + v.category().title() + ")\n"
                + "VL: " + Text.num(v.vl()) + " | уверенность: " + Text.percent(v.confidence())
                + " | общая: " + Text.percent(sum.combined()) + " (групп: " + sum.independent() + ")\n"
                + "Платформа: " + v.platform() + " | клиент: " + v.clientVersion() + " | пинг: " + v.ping()
                + " мс | TPS: " + Text.num(v.tps()) + "\n"
                + "Причина: " + v.reason());
    }

    public void warning(Violation v, ViolationManager.Summary sum) {
        if (v.test()) {
            return;
        }
        send(Event.WARNING, "**" + v.name() + "**: подозрение на читы, общая уверенность "
                + Text.percent(sum.combined()) + ", независимых групп: " + sum.independent()
                + ".\nПроверки: " + String.join(", ", sum.checks())
                + "\nДоказательств для бана недостаточно, проверьте игрока вручную.");
    }

    public void ban(BanRecord b) {
        boolean auto = "AstraGuard".equals(b.issuedBy());
        send(auto ? Event.AUTO_BAN : Event.MANUAL_BAN, "**" + b.name() + "** заблокирован до " + Text.date(b.expiresAt())
                + "\nВыдал: " + b.issuedBy() + " | ID бана: #" + b.id() + "\nПричина: " + b.reason());
    }

    public void unban(String player, String actor) {
        send(Event.UNBAN, "**" + player + "**: бан снят. Снял: " + actor);
    }

    public void critical(String message, Throwable t) {
        long now = System.currentTimeMillis();
        if (now - lastCritical < 60_000L) {
            return; // не засыпаем канал при повторяющейся ошибке
        }
        lastCritical = now;
        String text = message + (t == null ? "" : "\n" + t.getClass().getSimpleName() + ": " + t.getMessage());
        send(Event.CRITICAL, text);
    }

    // ------------------------------------------------------------------ отправка

    private void send(Event event, String description) {
        if (!active(event)) {
            return;
        }
        if (pending.incrementAndGet() > MAX_PENDING) {
            pending.decrementAndGet();
            return;
        }
        long delay;
        synchronized (this) {
            long now = System.currentTimeMillis();
            long at = Math.max(now, nextSlot);
            nextSlot = at + MIN_INTERVAL_MS;
            delay = at - now;
        }
        String json = buildJson(event, description);
        String url = plugin.settings().discordUrl();
        Runnable post = () -> post(url, json);
        CompletableFuture.runAsync(post, CompletableFuture.delayedExecutor(delay, TimeUnit.MILLISECONDS))
                .whenComplete((r, ex) -> pending.decrementAndGet());
    }

    private void post(String url, String json) {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                    .timeout(Duration.ofSeconds(10))
                    .header("Content-Type", "application/json; charset=utf-8")
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .build();
            client.sendAsync(req, HttpResponse.BodyHandlers.discarding()).whenComplete((resp, ex) -> {
                if (ex != null) {
                    failed("ошибка сети: " + ex.getClass().getSimpleName());
                } else if (resp.statusCode() / 100 != 2) {
                    failed("Discord вернул код " + resp.statusCode());
                }
            });
        } catch (IllegalArgumentException e) {
            failed("некорректный адрес вебхука (проверьте discord.webhook-url)");
        } catch (RuntimeException e) {
            failed("не удалось отправить: " + e.getClass().getSimpleName());
        }
    }

    /** Пишет в лог не чаще раза в минуту, адрес вебхука не выводится. */
    private void failed(String why) {
        long now = System.currentTimeMillis();
        if (now - lastFailLog < 60_000L) {
            return;
        }
        lastFailLog = now;
        plugin.getLogger().log(Level.WARNING, "Discord Webhook: " + why);
    }

    // ------------------------------------------------------------------ JSON

    private String buildJson(Event event, String description) {
        return "{\"username\":" + quote(plugin.settings().discordUsername())
                + ",\"allowed_mentions\":{\"parse\":[]}"
                + ",\"embeds\":[{\"title\":" + quote(cut(event.title, 250))
                + ",\"description\":" + quote(cut(description, 3900))
                + ",\"color\":" + event.color
                + ",\"timestamp\":" + quote(Instant.now().toString())
                + "}]}";
    }

    private static String cut(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }

    static String quote(String s) {
        StringBuilder b = new StringBuilder(s.length() + 8).append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> b.append("\\r");
                case '\t' -> b.append("\\t");
                default -> {
                    if (c < 0x20) {
                        b.append(String.format("\\u%04x", (int) c));
                    } else {
                        b.append(c);
                    }
                }
            }
        }
        return b.append('"').toString();
    }

    /** Освобождает память при выходе игрока не требуется: записи удаляются по сроку, размер ограничен. */
    public void forget(UUID id) {
        String prefix = id + "|";
        lastViolation.keySet().removeIf(k -> k.startsWith(prefix));
    }
}
