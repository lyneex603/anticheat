package ru.hexatime.astraguard.potion.analysis;

import java.util.Locale;

/**
 * Активный эффект игрока: ключ вида {@code minecraft:jump_boost} или {@code плагин:эффект}, уровень (с 1) и
 * оставшееся время. Не зависит от Bukkit.
 */
public record EffectState(String key, int level, int remainingTicks) {

    public EffectState {
        key = normalize(key);
        level = Math.max(1, level);
    }

    public static String normalize(String key) {
        String k = key.trim().toLowerCase(Locale.ROOT);
        return k.indexOf(':') >= 0 ? k : "minecraft:" + k;
    }

    /** Из «амплитуды» Bukkit (0 = уровень I). */
    public static EffectState fromAmplifier(String key, int amplifier, int durationTicks) {
        return new EffectState(key, amplifier + 1, durationTicks);
    }

    /** Короткая запись: {@code jump_boost II}. */
    public String describe() {
        String k = key.startsWith("minecraft:") ? key.substring("minecraft:".length()) : key;
        String[] roman = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return k + " " + (level < roman.length ? roman[level] : Integer.toString(level));
    }
}
