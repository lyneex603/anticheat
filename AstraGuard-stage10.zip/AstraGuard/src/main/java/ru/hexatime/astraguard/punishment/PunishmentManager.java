package ru.hexatime.astraguard.punishment;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.config.Settings;
import ru.hexatime.astraguard.database.Database;
import ru.hexatime.astraguard.util.Text;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/**
 * Баны на срок (по умолчанию 90 дней): выдача, снятие, автоматическое истечение, проверка при входе, история.
 * Все операции с БД выполняются вне основного потока.
 */
public final class PunishmentManager implements Listener {

    /** Результат попытки бана. */
    public record BanResult(BanRecord record, boolean alreadyBanned) {
    }

    private final AstraGuard plugin;
    private final Set<UUID> banning = new HashSet<>(); // только основной поток

    public PunishmentManager(AstraGuard plugin) {
        this.plugin = plugin;
    }

    private void runMain(Runnable r) {
        if (plugin.isEnabled()) {
            Bukkit.getScheduler().runTask(plugin, r);
        }
    }

    // ------------------------------------------------------------------ проверка при входе

    /**
     * Событие асинхронное, поэтому блокирующий запрос к БД здесь безопасен.
     * Истёкший бан снимается автоматически и пишется в историю.
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        try {
            Database db = plugin.database();
            BanRecord b = db.findActiveBan(e.getUniqueId());
            if (b == null) {
                return;
            }
            long now = System.currentTimeMillis();
            if (b.expired(now)) {
                db.expireBan(b, now);
                return;
            }
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED, banScreen(b));
        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "Не удалось проверить бан при входе игрока " + e.getName(), ex);
        }
    }

    public Component banScreen(BanRecord b) {
        Settings s = plugin.settings();
        Map<String, String> m = new HashMap<>();
        m.put("reason", b.reason());
        m.put("until", Text.date(b.expiresAt()));
        m.put("id", String.valueOf(b.id()));
        return Text.color(Text.fill(s.banScreen(), m));
    }

    // ------------------------------------------------------------------ выдача и снятие

    /** Выдаёт бан на срок из конфигурации. Если игрок уже забанен — возвращает существующую запись. */
    public CompletableFuture<BanResult> ban(UUID uuid, String name, String reason, String actor, boolean auto) {
        long now = System.currentTimeMillis();
        long expires = now + TimeUnit.DAYS.toMillis(plugin.settings().banDays());
        Database db = plugin.database();
        return db.supply(() -> {
            BanRecord existing = db.findActiveBan(uuid);
            if (existing != null && !existing.expired(now)) {
                return new BanResult(existing, true);
            }
            if (existing != null) {
                db.expireBan(existing, now);
            }
            BanRecord draft = new BanRecord(0, uuid, name, reason, actor, now, expires, true, null, 0);
            long id = db.insertBan(draft);
            db.addHistory(uuid, name, auto ? "AUTO_BAN" : "BAN", reason, actor, now, expires);
            return new BanResult(draft.withId(id), false);
        }).thenApply(res -> {
            if (!res.alreadyBanned()) {
                runMain(() -> {
                    Player online = Bukkit.getPlayer(uuid);
                    if (online != null) {
                        online.kick(banScreen(res.record()));
                    }
                    plugin.alerts().banIssued(res.record());
                });
            }
            return res;
        });
    }

    /** Автоматический бан. Повторные вызовы для того же игрока, пока идёт выдача, игнорируются. */
    public void autoBan(Player player, String reason) {
        UUID id = player.getUniqueId();
        if (!banning.add(id)) {
            return;
        }
        ban(id, player.getName(), reason, "AstraGuard", true).whenComplete((res, ex) -> {
            runMain(() -> banning.remove(id));
            if (ex != null) {
                plugin.getLogger().log(Level.SEVERE, "Автобан не выдан для " + player.getName(), ex);
            }
        });
    }

    /** Снимает активный бан. Результат true — бан был и снят. */
    public CompletableFuture<Boolean> unban(UUID uuid, String name, String actor) {
        long now = System.currentTimeMillis();
        Database db = plugin.database();
        return db.supply(() -> {
            BanRecord b = db.findActiveBan(uuid);
            if (b == null) {
                return false;
            }
            db.deactivateBan(b.id(), actor, now);
            db.addHistory(uuid, name, "UNBAN", "ручное снятие бана", actor, now, 0);
            return true;
        }).thenApply(ok -> {
            if (ok) {
                runMain(() -> plugin.alerts().unbanned(name, actor));
            }
            return ok;
        });
    }

    public CompletableFuture<BanRecord> latestBan(UUID uuid) {
        return plugin.database().supply(() -> plugin.database().findLatestBan(uuid));
    }

    public CompletableFuture<List<BanRecord>> activeBans(int limit) {
        long now = System.currentTimeMillis();
        return plugin.database().supply(() -> plugin.database().listActiveBans(limit, now));
    }

    public CompletableFuture<List<Database.HistoryEntry>> history(UUID uuid, int limit) {
        return plugin.database().supply(() -> plugin.database().listHistory(uuid, limit));
    }
}
