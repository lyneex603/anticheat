package ru.hexatime.astraguard.movement;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Waterlogged;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

/**
 * Серверная оценка окружения игрока по коллизиям блоков (не по флагам клиента). Вызывается только из основного потока.
 * Не загружает чанки: если рядом выгруженный чанк, кадр пропускается.
 */
final class TerrainScanner {

    /** Итог сканирования. loaded=false — данные неполные, кадр не оцениваем. */
    record Scan(boolean loaded, boolean serverGround, double slip, boolean altered, boolean nearWall,
                boolean surfaceLiquid) {
        static final Scan UNLOADED = new Scan(false, false, 0.6, false, false, false);
    }

    private static final double WALL_GAP = 0.06;

    static double slipperiness(Material m) {
        return switch (m) {
            case ICE, PACKED_ICE, FROSTED_ICE -> 0.98;
            case BLUE_ICE -> 0.989;
            case SLIME_BLOCK -> 0.8;
            default -> 0.6;
        };
    }

    /** Блоки, меняющие физику внутри тела игрока. */
    private static boolean altersMotion(Material m) {
        return Tag.CLIMBABLE.isTagged(m) || Tag.TRAPDOORS.isTagged(m) || m == Material.COBWEB
                || m == Material.BUBBLE_COLUMN || m == Material.POWDER_SNOW || m == Material.HONEY_BLOCK
                || m == Material.SWEET_BERRY_BUSH || m == Material.WATER || m == Material.LAVA;
    }

    /** Блоки, отбрасывающие вверх: рядом с ними вертикальная физика не оценивается. */
    private static boolean bouncy(Material m) {
        return m == Material.SLIME_BLOCK || m == Material.HONEY_BLOCK || Tag.BEDS.isTagged(m);
    }

    private static boolean liquid(Block b) {
        return b.isLiquid() || (b.getBlockData() instanceof Waterlogged w && w.isWaterlogged());
    }

    Scan scan(Player p, Location to, double probe) {
        World w = to.getWorld();
        double hw = p.getWidth() / 2.0;
        BoundingBox box = new BoundingBox(to.getX() - hw, to.getY(), to.getZ() - hw,
                to.getX() + hw, to.getY() + p.getHeight(), to.getZ() + hw);
        int x0 = (int) Math.floor(box.getMinX() - WALL_GAP);
        int x1 = (int) Math.floor(box.getMaxX() + WALL_GAP);
        int z0 = (int) Math.floor(box.getMinZ() - WALL_GAP);
        int z1 = (int) Math.floor(box.getMaxZ() + WALL_GAP);
        if (!w.isChunkLoaded(x0 >> 4, z0 >> 4) || !w.isChunkLoaded(x1 >> 4, z1 >> 4)
                || !w.isChunkLoaded(x0 >> 4, z1 >> 4) || !w.isChunkLoaded(x1 >> 4, z0 >> 4)) {
            return Scan.UNLOADED;
        }
        int y0 = (int) Math.floor(box.getMinY() - probe - 0.01) - 1;
        int y1 = (int) Math.floor(box.getMaxY());
        if (y1 < w.getMinHeight() || y0 > w.getMaxHeight()) {
            return Scan.UNLOADED;
        }

        BoundingBox foot = new BoundingBox(box.getMinX(), box.getMinY() - probe, box.getMinZ(),
                box.getMaxX(), box.getMinY() + 0.001, box.getMaxZ());
        BoundingBox wallBox = new BoundingBox(box.getMinX() - WALL_GAP, box.getMinY() + 0.1, box.getMinZ() - WALL_GAP,
                box.getMaxX() + WALL_GAP, box.getMaxY(), box.getMaxZ() + WALL_GAP);

        boolean ground = false;
        boolean altered = false;
        boolean wall = false;
        double slip = 0.6;
        for (int x = x0; x <= x1; x++) {
            for (int z = z0; z <= z1; z++) {
                for (int y = Math.max(y0, w.getMinHeight()); y <= Math.min(y1, w.getMaxHeight() - 1); y++) {
                    Block b = w.getBlockAt(x, y, z);
                    Material m = b.getType();
                    if (m.isAir()) {
                        continue;
                    }
                    BoundingBox cell = new BoundingBox(x, y, z, x + 1, y + 1, z + 1);
                    if (cell.overlaps(box)) {
                        if (altersMotion(m) || liquid(b)) {
                            altered = true;
                        }
                    } else if (bouncy(m) && cell.overlaps(foot.clone().expand(0.0, 0.9, 0.0))) {
                        altered = true;
                    }
                    for (BoundingBox bb : b.getCollisionShape().getBoundingBoxes()) {
                        BoundingBox wb = bb.clone().shift(x, y, z);
                        if (wb.overlaps(foot)) {
                            ground = true;
                            slip = Math.max(slip, slipperiness(m));
                        }
                        if (wb.overlaps(wallBox) && !wb.overlaps(box)) {
                            wall = true;
                        }
                    }
                }
            }
        }
        boolean surface = false;
        if (!altered && !ground) {
            Block below = w.getBlockAt(to.getBlockX(), (int) Math.floor(box.getMinY() - 0.1), to.getBlockZ());
            surface = below.isLiquid();
        }
        return new Scan(true, ground, slip, altered, wall, surface);
    }
}
