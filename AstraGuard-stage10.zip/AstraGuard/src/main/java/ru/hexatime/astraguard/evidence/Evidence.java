package ru.hexatime.astraguard.evidence;

import java.util.UUID;

/**
 * Доказательство, сохраняемое вместе с нарушением: данные игрока и сервера на момент флага,
 * контекст проверки и последовательность связанных событий.
 */
public record Evidence(UUID uuid, String name, String check, long time, double vl, double confidence,
                       int ping, double tps, double mspt, String platform, String clientVersion,
                       String context, String trace) {
}
