package ru.hexatime.astraguard.enchant.analysis;

import java.util.List;
import java.util.Map;

/**
 * Формулы ванильной механики зачарований для ПРОИЗВОЛЬНЫХ уровней (в т.ч. Sharpness VI–VII, Protection IV–V,
 * Unbreaking IV–V, Efficiency VI–X). Уровни нигде не обрезаются по ванильному максимуму.
 * <p>
 * Формулы — как в Java Edition 1.21+. Часть эффектов там задаётся данными (датапаки), поэтому на сервере
 * с изменённым датапаком реальные значения могут отличаться; эти расчёты нужны для объяснений и доказательств,
 * а не как эталон для наказания (эталоном ломания блока остаётся сам сервер).
 */
public final class EnchantMath {

    /** Вид урона для расчёта защитных зачарований. */
    public enum Cause { GENERIC, FIRE, EXPLOSION, PROJECTILE, FALL }

    /** Верхний предел суммы защитных очков брони (ваниль). */
    public static final int MAX_PROTECTION_POINTS = 20;

    private static final String PROTECTION = "minecraft:protection";
    private static final String FIRE_PROTECTION = "minecraft:fire_protection";
    private static final String BLAST_PROTECTION = "minecraft:blast_protection";
    private static final String PROJECTILE_PROTECTION = "minecraft:projectile_protection";
    private static final String FEATHER_FALLING = "minecraft:feather_falling";
    private static final String SHARPNESS = "minecraft:sharpness";
    private static final String UNBREAKING = "minecraft:unbreaking";
    private static final String EFFICIENCY = "minecraft:efficiency";

    private EnchantMath() {
    }

    // ---------------- Sharpness ----------------

    /** Дополнительный урон от Sharpness: 0.5·уровень + 0.5 (I = 1.0, V = 3.0, VII = 4.0). */
    public static double sharpnessBonus(int level) {
        return level <= 0 ? 0.0 : 0.5 * level + 0.5;
    }

    public static double sharpnessBonus(EnchantSnapshot weapon) {
        return sharpnessBonus(weapon.level(SHARPNESS));
    }

    // ---------------- Protection ----------------

    /** Защитные очки одной детали брони для данного вида урона (Protection ×1, Fire/Blast/Projectile ×2, Feather Falling ×3). */
    public static int protectionPoints(EnchantSnapshot piece, Cause cause) {
        int p = piece.level(PROTECTION);
        switch (cause) {
            case FIRE -> p += 2 * piece.level(FIRE_PROTECTION);
            case EXPLOSION -> p += 2 * piece.level(BLAST_PROTECTION);
            case PROJECTILE -> p += 2 * piece.level(PROJECTILE_PROTECTION);
            case FALL -> p += 3 * piece.level(FEATHER_FALLING);
            case GENERIC -> {
            }
        }
        return p;
    }

    /** Сумма защитных очков всей брони, не выше 20. */
    public static int totalProtectionPoints(List<EnchantSnapshot> armor, Cause cause) {
        long sum = 0;
        for (EnchantSnapshot piece : armor) {
            sum += protectionPoints(piece, cause);
        }
        return (int) Math.min(MAX_PROTECTION_POINTS, sum);
    }

    /** Множитель урона от зачарований брони: 1 − очки/25 (4% за очко, максимум −80%). */
    public static double enchantDamageFactor(int protectionPoints) {
        int p = Math.max(0, Math.min(MAX_PROTECTION_POINTS, protectionPoints));
        return 1.0 - p / 25.0;
    }

    /** Множитель урона от очков брони и твёрдости (формула игры), до зачарований. */
    public static double armorDamageFactor(double damage, double armor, double toughness) {
        if (damage <= 0.0 || armor <= 0.0) {
            return 1.0;
        }
        double f = 2.0 + toughness / 4.0;
        double g = Math.max(armor * 0.2, Math.min(20.0, armor - damage / f));
        return 1.0 - g / 25.0;
    }

    /** Урон после брони и зачарований (без эффекта Resistance — его учтёт этап зелий). */
    public static double damageAfterArmor(double damage, double armor, double toughness, int protectionPoints) {
        return damage * armorDamageFactor(damage, armor, toughness) * enchantDamageFactor(protectionPoints);
    }

    // ---------------- Unbreaking ----------------

    /** Вероятность, что инструмент или оружие потеряет прочность за использование: 1/(уровень+1). */
    public static double toolDurabilityLossChance(int unbreaking) {
        return 1.0 / (Math.max(0, unbreaking) + 1.0);
    }

    /** Вероятность потери прочности брони за удар: 60% + 40%/(уровень+1). */
    public static double armorDurabilityLossChance(int unbreaking) {
        return 0.6 + 0.4 / (Math.max(0, unbreaking) + 1.0);
    }

    /** Во сколько раз дольше служит инструмент по сравнению с предметом без Unbreaking. */
    public static double toolDurabilityMultiplier(int unbreaking) {
        return 1.0 / toolDurabilityLossChance(unbreaking);
    }

    /** Во сколько раз дольше служит броня по сравнению с предметом без Unbreaking. */
    public static double armorDurabilityMultiplier(int unbreaking) {
        return 1.0 / armorDurabilityLossChance(unbreaking);
    }

    public static int unbreakingLevel(EnchantSnapshot item) {
        return item.level(UNBREAKING);
    }

    // ---------------- Efficiency ----------------

    /** Добавка к скорости ломания от Efficiency: уровень² + 1 (V = +26, X = +101). */
    public static double efficiencyBonus(int level) {
        return level <= 0 ? 0.0 : (double) level * level + 1.0;
    }

    /**
     * Скорость ломания с учётом Efficiency. Добавка действует только если инструмент подходит блоку
     * (базовая скорость больше 1), как в игре.
     */
    public static double miningSpeedWithEfficiency(double baseSpeed, int level) {
        return baseSpeed > 1.0 ? baseSpeed + efficiencyBonus(level) : baseSpeed;
    }

    public static int efficiencyLevel(EnchantSnapshot tool) {
        return tool.level(EFFICIENCY);
    }

    // ---------------- ванильные максимумы (только для пометки в отчётах) ----------------

    private static final Map<String, Integer> VANILLA_MAX = Map.ofEntries(
            Map.entry(SHARPNESS, 5), Map.entry(PROTECTION, 4), Map.entry(UNBREAKING, 3), Map.entry(EFFICIENCY, 5),
            Map.entry(FIRE_PROTECTION, 4), Map.entry(BLAST_PROTECTION, 4), Map.entry(PROJECTILE_PROTECTION, 4),
            Map.entry(FEATHER_FALLING, 4), Map.entry("minecraft:knockback", 2), Map.entry("minecraft:fire_aspect", 2),
            Map.entry("minecraft:looting", 3), Map.entry("minecraft:fortune", 3), Map.entry("minecraft:mending", 1));

    /**
     * Выше ли уровень ванильного максимума. Только пометка для администратора: сам по себе такой уровень
     * НЕ нарушение (сервер выдаёт повышенные уровни). Для неизвестных зачарований всегда false.
     */
    public static boolean aboveVanillaMax(String key, int level) {
        Integer max = VANILLA_MAX.get(EnchantSnapshot.normalize(key));
        return max != null && level > max;
    }
}
