package ru.hexatime.astraguard.violation;

import java.util.UUID;

/** Запись о нарушении (в памяти и в базе). */
public record Violation(long id, UUID uuid, String name, String check, String group, CheckCategory category,
                        double vl, double confidence, String reason, long time, int ping, double tps,
                        double mspt, String platform, String clientVersion, boolean test) {
}
