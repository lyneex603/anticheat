package ru.hexatime.astraguard.potion;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.potion.analysis.CustomDamageModifier;
import ru.hexatime.astraguard.potion.analysis.CustomMovementModifier;
import ru.hexatime.astraguard.potion.analysis.DamageAdjust;
import ru.hexatime.astraguard.potion.analysis.EffectAggregator;
import ru.hexatime.astraguard.potion.analysis.EffectRule;
import ru.hexatime.astraguard.potion.analysis.EffectState;
import ru.hexatime.astraguard.potion.analysis.MovementAdjust;
import ru.hexatime.astraguard.potion.analysis.RuleBasedModifiers;
import ru.hexatime.astraguard.potion.analysis.VanillaEffectModifiers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;

/**
 * Учёт реальных активных эффектов игрока и их влияния на движение и урон.
 * <p>
 * Источники эффектов: активные эффекты игрока ({@code Player#getActivePotionEffects}, включая зарегистрированные
 * плагинами типы) и зарегистрированные {@link CustomPotionProvider}. Влияние считают модификаторы: ванильные
 * (Jump Boost, Resistance), заданные правилами в {@code potions.custom-effects} и добавленные кодом через
 * {@link #registerMovement}/{@link #registerDamage}. Кастомных зелий на сервере пока нет — правил по умолчанию нет,
 * и поведение античита не меняется.
 * <p>
 * Только основной поток. Ничего не решает о нарушении: движение получает множитель скорости, добавку прыжка и
 * исключение для рывков; урон используется в отчётах и доказательствах.
 */
public final class PotionEffectAnalyzer {

    private final AstraGuard plugin;
    private final List<CustomPotionProvider> providers = new CopyOnWriteArrayList<>();
    private final List<CustomMovementModifier> movementModifiers = new CopyOnWriteArrayList<>();
    private final List<CustomDamageModifier> damageModifiers = new CopyOnWriteArrayList<>();
    private volatile CustomMovementModifier configMovement = a -> MovementAdjust.IDENTITY;
    private volatile CustomDamageModifier configDamage = a -> DamageAdjust.IDENTITY;
    private volatile int ruleCount;
    private volatile boolean enabled = true;
    private volatile boolean recordInEvidence = true;
    /** Кэш влияния эффектов на движение на 3 тика (только основной поток): не читаем эффекты на каждый пакет движения. */
    private record CachedMovement(int tick, MovementAdjust adjust) {
    }

    private final Map<UUID, CachedMovement> movementCache = new HashMap<>();

    public PotionEffectAnalyzer(AstraGuard plugin) {
        this.plugin = plugin;
        movementModifiers.add(VanillaEffectModifiers.movement());
        damageModifiers.add(VanillaEffectModifiers.damage());
        reload();
    }

    public void reload() {
        movementCache.clear();
        enabled = plugin.getConfig().getBoolean("potions.enabled", true);
        recordInEvidence = plugin.getConfig().getBoolean("potions.record-in-evidence", true);
        Map<String, EffectRule> rules = new LinkedHashMap<>();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("potions.custom-effects");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection c = sec.getConfigurationSection(key);
                if (c == null) {
                    continue;
                }
                try {
                    rules.put(key, new EffectRule(c.getDouble("speed-per-level", 0.0), c.getDouble("jump-per-level", 0.0),
                            c.getDouble("attack-bonus-per-level", 0.0), c.getDouble("damage-reduction-per-level", 0.0),
                            c.getBoolean("exempt-movement", false)));
                } catch (IllegalArgumentException e) {
                    plugin.getLogger().warning("potions.custom-effects." + key + ": " + e.getMessage() + " — правило пропущено");
                }
            }
        }
        RuleBasedModifiers rb = new RuleBasedModifiers(rules);
        configMovement = rb.movement();
        configDamage = rb.damage();
        ruleCount = rules.size();
    }

    public void register(CustomPotionProvider provider) {
        providers.add(provider);
    }

    public void registerMovement(CustomMovementModifier m) {
        movementModifiers.add(m);
    }

    public void registerDamage(CustomDamageModifier m) {
        damageModifiers.add(m);
    }

    public boolean enabled() {
        return enabled;
    }

    /** Сколько правил кастомных эффектов загружено из конфигурации. */
    public int ruleCount() {
        return ruleCount;
    }

    // ---------------- чтение эффектов ----------------

    /** Все активные эффекты игрока: обычные и из провайдеров. */
    public List<EffectState> active(Player p) {
        List<EffectState> out = new ArrayList<>();
        for (PotionEffect e : p.getActivePotionEffects()) {
            out.add(EffectState.fromAmplifier(e.getType().getKey().asString(), e.getAmplifier(), e.getDuration()));
        }
        for (CustomPotionProvider cp : providers) {
            try {
                out.addAll(cp.read(p));
            } catch (RuntimeException ex) {
                plugin.getLogger().log(Level.WARNING, "Провайдер эффектов «" + cp.id() + "» выдал ошибку", ex);
            }
        }
        return out;
    }

    /** Освобождает кэш при выходе игрока. */
    public void forget(UUID id) {
        movementCache.remove(id);
    }

    /** Влияние эффектов на движение; без эффектов — {@link MovementAdjust#IDENTITY}. Кэшируется на 3 тика. */
    public MovementAdjust movement(Player p) {
        if (!enabled) {
            return MovementAdjust.IDENTITY;
        }
        int tick = Bukkit.getCurrentTick();
        CachedMovement c = movementCache.get(p.getUniqueId());
        if (c != null && tick - c.tick() >= 0 && tick - c.tick() < 3) {
            return c.adjust();
        }
        MovementAdjust result = computeMovement(p);
        movementCache.put(p.getUniqueId(), new CachedMovement(tick, result));
        return result;
    }

    private MovementAdjust computeMovement(Player p) {
        List<EffectState> active = active(p);
        if (active.isEmpty()) {
            return MovementAdjust.IDENTITY;
        }
        List<CustomMovementModifier> all = new ArrayList<>(movementModifiers);
        all.add(configMovement);
        return EffectAggregator.movement(active, all);
    }

    /** Влияние эффектов на урон; без эффектов — {@link DamageAdjust#IDENTITY}. */
    public DamageAdjust damage(Player p) {
        if (!enabled) {
            return DamageAdjust.IDENTITY;
        }
        List<EffectState> active = active(p);
        if (active.isEmpty()) {
            return DamageAdjust.IDENTITY;
        }
        List<CustomDamageModifier> all = new ArrayList<>(damageModifiers);
        all.add(configDamage);
        return EffectAggregator.damage(active, all);
    }

    // ---------------- доказательства и отчёт ----------------

    /** Поле «effects» для доказательства: активные эффекты игрока на момент флага (пусто, если их нет). */
    public Map<String, String> evidenceContext(Player p) {
        Map<String, String> m = new LinkedHashMap<>();
        if (!enabled || !recordInEvidence) {
            return m;
        }
        try {
            List<EffectState> active = active(p);
            if (!active.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (EffectState e : active) {
                    if (sb.length() > 0) {
                        sb.append(", ");
                    }
                    sb.append(e.describe()).append(" (").append(e.remainingTicks() / 20).append("с)");
                }
                m.put("effects", sb.toString());
            }
        } catch (RuntimeException e) {
            plugin.getLogger().log(Level.WARNING, "Не удалось прочитать эффекты для доказательства", e);
        }
        return m;
    }

    /** Строки отчёта для /ag potion. */
    public List<String> report(Player p) {
        List<String> out = new ArrayList<>();
        List<EffectState> active = active(p);
        if (active.isEmpty()) {
            out.add("&7Активных эффектов нет.");
        } else {
            for (EffectState e : active) {
                out.add("&8 • &f" + e.describe() + " &7осталось &f" + e.remainingTicks() / 20 + " с");
            }
        }
        MovementAdjust mv = movement(p);
        out.add("&7Движение: скорость ×&f" + String.format(java.util.Locale.ROOT, "%.2f", mv.speedMultiplier())
                + "&7, прыжок +&f" + String.format(java.util.Locale.ROOT, "%.2f", mv.extraJump())
                + "&7, проверки движения " + (mv.exempt() ? "&eотключены эффектом" : "&aработают"));
        DamageAdjust dm = damage(p);
        out.add("&7Урон: добавка +&f" + String.format(java.util.Locale.ROOT, "%.1f", dm.attackBonus())
                + "&7, получаемый урон ×&f" + String.format(java.util.Locale.ROOT, "%.2f", dm.damageTakenMultiplier()));
        out.add("&8Speed/Slowness/Strength/Weakness/Haste уже входят в атрибуты игрока и здесь не дублируются. "
                + "Правил кастомных эффектов: " + ruleCount + ".");
        return out;
    }
}
