package ru.hexatime.astraguard.movement.analysis;

import ru.hexatime.astraguard.combat.analysis.Finding;

/**
 * NoFall-Ground. Клиент сообщает «на земле», а серверные коллизии блоков опоры под ногами не находят.
 * Подмена этого флага — основа NoFall. Только Java по умолчанию: у Bedrock флаг формирует сам Geyser.
 */
public final class GroundAnalyzer {

    private static final double LIMIT = 6.0;

    private double buffer;

    public void reset() {
        buffer = 0;
    }

    public Finding onFrame(MoveFrame f, MoveThresholds t) {
        if (!t.groundCheck() || f.discontinuity() || f.altered()) {
            buffer = 0;
            return null;
        }
        if (f.claimedGround() && !f.serverGround()) {
            buffer += 1.0;
        } else {
            buffer = Math.max(0.0, buffer - 1.0);
        }
        if (buffer < LIMIT) {
            return null;
        }
        buffer = LIMIT / 2;
        return Finding.of("NoFall-Ground", "move-vertical", 0.8,
                "клиент сообщает «на земле», но опоры под ногами нет (подряд несколько кадров)",
                "claimedGround", true, "serverGround", false, "dy", String.format("%.3f", f.dy()));
    }
}
