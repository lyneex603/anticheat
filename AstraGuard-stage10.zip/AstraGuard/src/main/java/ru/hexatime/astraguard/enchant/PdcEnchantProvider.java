package ru.hexatime.astraguard.enchant;

import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Читает уровни «своих» зачарований, которые плагин хранит в PersistentDataContainer предмета.
 * Какие именно ключи использует плагин, заранее неизвестно — их находят командой {@code /ag enchant}
 * (она печатает все ключи контейнера предмета в руке) и вписывают в {@code enchantments.pdc-keys}.
 * Поддерживаются значения типов INTEGER, BYTE, SHORT, LONG и STRING с числом.
 */
public final class PdcEnchantProvider implements EnchantProvider {

    private final List<NamespacedKey> keys;

    public PdcEnchantProvider(List<NamespacedKey> keys) {
        this.keys = List.copyOf(keys);
    }

    @Override
    public String id() {
        return "pdc";
    }

    @Override
    public Map<String, Integer> read(ItemStack item) {
        Map<String, Integer> out = new LinkedHashMap<>();
        if (keys.isEmpty()) {
            return out;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return out;
        }
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        for (NamespacedKey key : keys) {
            int level = levelOf(pdc, key);
            if (level > 0) {
                out.put(key.asString(), level);
            }
        }
        return out;
    }

    private static int levelOf(PersistentDataContainer pdc, NamespacedKey key) {
        if (pdc.has(key, PersistentDataType.INTEGER)) {
            Integer v = pdc.get(key, PersistentDataType.INTEGER);
            return v == null ? 0 : v;
        }
        if (pdc.has(key, PersistentDataType.BYTE)) {
            Byte v = pdc.get(key, PersistentDataType.BYTE);
            return v == null ? 0 : v;
        }
        if (pdc.has(key, PersistentDataType.SHORT)) {
            Short v = pdc.get(key, PersistentDataType.SHORT);
            return v == null ? 0 : v;
        }
        if (pdc.has(key, PersistentDataType.LONG)) {
            Long v = pdc.get(key, PersistentDataType.LONG);
            return v == null ? 0 : (int) Math.max(0L, Math.min(Integer.MAX_VALUE, v));
        }
        if (pdc.has(key, PersistentDataType.STRING)) {
            String v = pdc.get(key, PersistentDataType.STRING);
            try {
                return v == null ? 0 : Integer.parseInt(v.trim());
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        return 0;
    }

    /** Все ключи PersistentDataContainer предмета — для поиска ключей чужих зачарований. */
    public static List<String> discoverKeys(ItemStack item) {
        List<String> out = new ArrayList<>();
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            for (NamespacedKey k : meta.getPersistentDataContainer().getKeys()) {
                out.add(k.asString());
            }
        }
        return out;
    }
}
