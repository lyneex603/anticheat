package ru.hexatime.astraguard.api;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import ru.hexatime.astraguard.violation.CheckCategory;

/**
 * Вызывается в основном потоке ПЕРЕД записью нарушения. Если отменить событие, VL не растёт, оповещение, запись в базу
 * и наказание не выполняются. Нужно другим плагинам сервера (например, с особыми способностями, которые двигают
 * игрока или бьют дальше обычного), чтобы не вызывать ложных флагов.
 */
public final class AstraFlagEvent extends Event implements Cancellable {

    private static final HandlerList HANDLERS = new HandlerList();

    private final Player player;
    private final String check;
    private final CheckCategory category;
    private final String reason;
    private boolean cancelled;

    public AstraFlagEvent(Player player, String check, CheckCategory category, String reason) {
        this.player = player;
        this.check = check;
        this.category = category;
        this.reason = reason;
    }

    public Player getPlayer() {
        return player;
    }

    /** Название проверки, например {@code Reach} или {@code FastBreak}. */
    public String getCheck() {
        return check;
    }

    public CheckCategory getCategory() {
        return category;
    }

    /** Объяснение, почему проверка сработала. */
    public String getReason() {
        return reason;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @Override
    public HandlerList getHandlers() {
        return HANDLERS;
    }

    public static HandlerList getHandlerList() {
        return HANDLERS;
    }
}
