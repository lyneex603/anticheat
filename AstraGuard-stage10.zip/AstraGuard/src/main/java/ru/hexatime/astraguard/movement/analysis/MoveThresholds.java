package ru.hexatime.astraguard.movement.analysis;

import ru.hexatime.astraguard.combat.analysis.ControlClass;

/**
 * Пороги проверок движения для одного класса управления.
 *
 * @param speedEps       запас к допустимой скорости (блоков за тик): шум позиций, толчки, округление Geyser
 * @param verticalTol    допуск отклонения вертикальной скорости от гравитации (блоков за тик)
 * @param groundCheck    включена ли проверка флага «на земле» (NoFall-Ground)
 * @param timerLimitMs   на сколько мс клиент может «опережать» реальное время, прежде чем Timer флагает
 * @param timerCreditMs  сколько мс «паузы» засчитывается как кредит (чтобы лаг-всплеск пакетов не флагал)
 */
public record MoveThresholds(double speedEps, double verticalTol, boolean groundCheck,
                             double timerLimitMs, double timerCreditMs) {

    public static MoveThresholds defaults(ControlClass c) {
        return switch (c) {
            case JAVA -> new MoveThresholds(0.008, 0.02, true, 750, 5000);
            case BEDROCK_KBM -> new MoveThresholds(0.02, 0.04, false, 1500, 5000);
            case BEDROCK_CONTROLLER, BEDROCK_TOUCH, BEDROCK_UNKNOWN ->
                    new MoveThresholds(0.03, 0.05, false, 1500, 5000);
        };
    }
}
