package ru.hexatime.astraguard.floodgate;

import org.bukkit.entity.Player;
import ru.hexatime.astraguard.player.PlayerProfile;

/** Запасной вариант без Floodgate: отличить Bedrock от Java нельзя, поэтому все считаются Java. */
public final class JavaOnlyResolver implements PlatformResolver {

    @Override
    public PlayerProfile resolve(Player player) {
        return new PlayerProfile(player.getUniqueId(), player.getName(), PlayerProfile.Platform.JAVA,
                "UNKNOWN", "UNKNOWN", "unknown", System.currentTimeMillis());
    }
}
