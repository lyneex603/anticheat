package ru.hexatime.astraguard.violation;

import java.util.Collection;

/**
 * Чистая математика системы нарушений (без Bukkit — легко тестируется).
 * <ul>
 *   <li>VL затухает линейно со временем;</li>
 *   <li>уверенность одной проверки = VL / maxVl (не больше 1);</li>
 *   <li>общая уверенность по независимым группам: 1 − Π(1 − cᵢ).</li>
 * </ul>
 */
public final class ConfidenceModel {

    private ConfidenceModel() {
    }

    /** VL после затухания: каждые decaySeconds секунд вычитается decayAmount, но не ниже нуля. */
    public static double decayedVl(double vl, long elapsedMs, double decayAmount, double decaySeconds) {
        if (vl <= 0.0 || elapsedMs <= 0 || decaySeconds <= 0.0) {
            return Math.max(0.0, vl);
        }
        double steps = (elapsedMs / 1000.0) / decaySeconds;
        return Math.max(0.0, vl - steps * decayAmount);
    }

    /** Уверенность одной проверки от 0 до 1. */
    public static double checkConfidence(double vl, double maxVl) {
        if (vl <= 0.0 || maxVl <= 0.0) {
            return 0.0;
        }
        return Math.min(1.0, vl / maxVl);
    }

    /** Объединяет уверенности независимых групп. Пустой набор даёт 0. */
    public static double combined(Collection<Double> confidences) {
        double rest = 1.0;
        for (double c : confidences) {
            rest *= 1.0 - Math.max(0.0, Math.min(1.0, c));
        }
        return 1.0 - rest;
    }
}
