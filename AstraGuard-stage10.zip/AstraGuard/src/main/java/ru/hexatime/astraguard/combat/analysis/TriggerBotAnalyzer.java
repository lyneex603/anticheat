package ru.hexatime.astraguard.combat.analysis;

/**
 * TriggerBot: измеряет, через сколько тиков после попадания прицела на цель следует удар.
 * Человеку нужно ≥ 3–4 тиков на реакцию (но он может «держать» прицел заранее — такие случаи не считаются).
 * Подозрительна устойчивая серия ударов в тот же или следующий тик после наведения.
 */
public final class TriggerBotAnalyzer {

    private static final int N = 12;

    private int target = Integer.MIN_VALUE;
    private int acquiredTick = -1;
    private boolean onTarget;
    private final int[] samples = new int[N];
    private int count;

    /** Вызывается на каждом повороте камеры, пока игрок в бою с target. */
    public void onLook(int tick, int targetId, boolean looking) {
        if (targetId != target) {
            target = targetId;
            onTarget = false;
            acquiredTick = -1;
            count = 0;
        }
        if (looking && !onTarget) {
            acquiredTick = tick;
        } else if (!looking) {
            acquiredTick = -1;
        }
        onTarget = looking;
    }

    public Finding onAttack(int tick, int targetId, Thresholds t) {
        if (!t.triggerCheck() || targetId != target || acquiredTick < 0) {
            return null;
        }
        int reaction = tick - acquiredTick;
        if (reaction < 0 || reaction > 10) {
            return null;
        }
        samples[count++] = reaction;
        acquiredTick = -1; // каждое наведение — одна выборка
        if (count < N) {
            return null;
        }
        count = 0;
        int fast = 0;
        double mean = 0;
        for (int s : samples) {
            if (s <= 1) {
                fast++;
            }
            mean += s;
        }
        mean /= N;
        double var = 0;
        for (int s : samples) {
            var += (s - mean) * (s - mean);
        }
        double std = Math.sqrt(var / N);
        if (fast >= 10 && std <= 0.8) {
            return Finding.of("TriggerBot", "combat-trigger", 1.0,
                    fast + " из " + N + " ударов нанесены в тот же или следующий тик после наведения на цель",
                    "fast", fast, "meanTicks", String.format("%.2f", mean));
        }
        return null;
    }
}
