package ru.hexatime.astraguard.combat.analysis;

/**
 * Кольцевой буфер последних позиций игрока (фиксированный размер — память не растёт).
 * Нужен для компенсации задержки: удар проверяется по тому, где цель могла быть на экране атакующего.
 */
public final class PositionHistory {

    @FunctionalInterface
    public interface Visitor {
        void visit(long timeMs, double x, double y, double z);
    }

    private static final int SIZE = 24;
    private final long[] time = new long[SIZE];
    private final double[] xs = new double[SIZE];
    private final double[] ys = new double[SIZE];
    private final double[] zs = new double[SIZE];
    private int head;
    private int count;

    public void record(long timeMs, double x, double y, double z) {
        time[head] = timeMs;
        xs[head] = x;
        ys[head] = y;
        zs[head] = z;
        head = (head + 1) % SIZE;
        count = Math.min(SIZE, count + 1);
    }

    /** Обходит записи не старше sinceMs (от новых к старым). */
    public void forEachSince(long sinceMs, Visitor v) {
        for (int i = 0; i < count; i++) {
            int idx = (head - 1 - i + SIZE * 2) % SIZE;
            if (time[idx] < sinceMs) {
                break;
            }
            v.visit(time[idx], xs[idx], ys[idx], zs[idx]);
        }
    }

    /** Скорость между двумя последними записями в блоках за тик; 0, если данных мало. */
    public double speedPerTick() {
        if (count < 2) {
            return 0.0;
        }
        int a = (head - 1 + SIZE) % SIZE;
        int b = (head - 2 + SIZE) % SIZE;
        long dt = time[a] - time[b];
        if (dt <= 0) {
            return 0.0;
        }
        double dist = Math.sqrt(Math.pow(xs[a] - xs[b], 2) + Math.pow(ys[a] - ys[b], 2) + Math.pow(zs[a] - zs[b], 2));
        return dist / (dt / 50.0);
    }
}
