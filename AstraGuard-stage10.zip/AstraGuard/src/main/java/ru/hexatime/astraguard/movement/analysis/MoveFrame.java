package ru.hexatime.astraguard.movement.analysis;

/**
 * Один «кадр» движения игрока (одно событие перемещения). Заполняется Bukkit-слоем, анализаторы Bukkit не знают.
 *
 * @param timeMs         монотонное время кадра, мс
 * @param dx             смещение по осям с прошлого кадра
 * @param discontinuity  разрыв (телепорт, пауза, смена позиции плагином): базовые значения сбрасываются
 * @param serverGround   под ногами есть опора по серверным коллизиям блоков (не флаг клиента)
 * @param claimedGround  флаг «на земле», присланный клиентом
 * @param slip           скользкость блока под ногами (0.6 обычный, 0.98 лёд, 0.8 слизь)
 * @param altered        среда меняет физику: жидкость, лестница, паутина, пузыри, слизь/кровать, левитация...
 * @param nearWall       вплотную к твёрдому блоку по горизонтали
 * @param surfaceLiquid  ноги над жидкостью (под ногами жидкость, в ногах — нет) и опоры нет
 * @param speedPotential скорость ходьбы с учётом спринта: атрибут × (1.3, если не бежит) × эффекты
 * @param jumpPower      начальная вертикальная скорость прыжка (атрибут + Jump Boost)
 * @param gravity        гравитация (атрибут, обычно 0.08)
 * @param slowFalling    действует Slow Falling
 */
public record MoveFrame(long timeMs, double dx, double dy, double dz, boolean discontinuity,
                        boolean serverGround, boolean claimedGround, double slip, boolean altered,
                        boolean nearWall, boolean surfaceLiquid, double speedPotential,
                        double jumpPower, double gravity, boolean slowFalling) {

    public double horizontal() {
        return Math.sqrt(dx * dx + dz * dz);
    }
}
