package ru.hexatime.astraguard.combat.analysis;

/**
 * Пороги боевых проверок для одного класса управления.
 *
 * @param reachTolerance  запас к дальности удара (блоков) на задержку позиции игрока
 * @param maxFacingDeg    максимальный угол по горизонтали между взглядом и целью при ударе
 * @param clickModeRatio  доля одинаковых интервалов между кликами (в тиках), выше которой клики «роботные»
 * @param clickMinCps     ниже этого CPS анализ равномерности не выполняется
 * @param hardCps         CPS, выше которого фиксируется нарушение «невозможного» CPS
 * @param aimChecks       включены ли AimAssist-проверки (на тач/геймпаде у Bedrock есть встроенная помощь прицеливания)
 * @param triggerCheck    включена ли проверка TriggerBot
 */
public record Thresholds(double reachTolerance, double maxFacingDeg, double clickModeRatio, double clickMinCps,
                         double hardCps, boolean aimChecks, boolean triggerCheck) {

    public static Thresholds defaults(ControlClass c) {
        return switch (c) {
            case JAVA -> new Thresholds(0.45, 55, 0.88, 9, 28, true, true);
            case BEDROCK_KBM -> new Thresholds(0.60, 65, 0.90, 9, 30, true, true);
            case BEDROCK_CONTROLLER -> new Thresholds(0.70, 75, 0.93, 8, 20, false, false);
            case BEDROCK_TOUCH -> new Thresholds(0.80, 80, 0.95, 8, 20, false, false);
            case BEDROCK_UNKNOWN -> new Thresholds(0.80, 80, 0.95, 9, 28, false, false);
        };
    }
}
