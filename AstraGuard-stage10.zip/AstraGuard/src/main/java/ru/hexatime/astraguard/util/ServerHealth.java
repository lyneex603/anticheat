package ru.hexatime.astraguard.util;

import org.bukkit.Bukkit;
import ru.hexatime.astraguard.AstraGuard;

/**
 * Состояние сервера: TPS, MSPT и остановки («замирания»). Одна дешёвая задача раз в тик на весь плагин.
 * После остановки накопленные пакеты приходят пачкой, поэтому проверки, чувствительные ко времени, ей не доверяют.
 */
public final class ServerHealth {

    private final AstraGuard plugin;
    private int beat;
    private long lastBeatMs;
    private volatile long lastStallMs = Long.MIN_VALUE / 2;
    private volatile double tps = 20.0;
    private volatile double mspt = 0.0;

    public ServerHealth(AstraGuard plugin) {
        this.plugin = plugin;
    }

    public static long nowMs() {
        return System.nanoTime() / 1_000_000L;
    }

    /** Запускает пульс. Задача снимается при отключении плагина. */
    public void start() {
        lastBeatMs = nowMs();
        Bukkit.getScheduler().runTaskTimer(plugin, this::heartbeat, 1L, 1L);
    }

    private void heartbeat() {
        long now = nowMs();
        if (now - lastBeatMs > 120) {
            lastStallMs = now;
        }
        lastBeatMs = now;
        if (++beat >= 20) {
            beat = 0;
            tps = Math.min(20.0, Bukkit.getTPS()[0]);
            mspt = Bukkit.getAverageTickTime();
        }
    }

    public double tps() {
        return tps;
    }

    public double mspt() {
        return mspt;
    }

    /** Была ли остановка сервера за последние windowMs миллисекунд. */
    public boolean stalledWithin(long nowMs, long windowMs) {
        return nowMs - lastStallMs <= windowMs;
    }
}
