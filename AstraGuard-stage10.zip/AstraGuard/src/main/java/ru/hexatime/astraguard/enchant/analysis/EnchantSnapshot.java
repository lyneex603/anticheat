package ru.hexatime.astraguard.enchant.analysis;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Неизменяемый набор зачарований одного предмета: ключ вида {@code minecraft:sharpness} → уровень.
 * Не зависит от Bukkit, поэтому покрывается обычными тестами.
 * <p>
 * Уровни не ограничиваются: Sharpness VII, Protection V и Efficiency X — обычные значения для этого сервера.
 */
public final class EnchantSnapshot {

    public static final EnchantSnapshot EMPTY = new EnchantSnapshot(Map.of());

    private static final String[] ROMAN = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    private final Map<String, Integer> levels;

    public EnchantSnapshot(Map<String, Integer> levels) {
        Map<String, Integer> m = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> e : levels.entrySet()) {
            if (e.getKey() != null && e.getValue() != null && e.getValue() > 0) {
                m.merge(normalize(e.getKey()), e.getValue(), Math::max);
            }
        }
        this.levels = Collections.unmodifiableMap(m);
    }

    /** Ключ без пространства имён считается ванильным: {@code sharpness} → {@code minecraft:sharpness}. */
    public static String normalize(String key) {
        String k = key.trim().toLowerCase(java.util.Locale.ROOT);
        return k.indexOf(':') >= 0 ? k : "minecraft:" + k;
    }

    /** Уровень зачарования, 0 если его нет. */
    public int level(String key) {
        return levels.getOrDefault(normalize(key), 0);
    }

    public boolean isEmpty() {
        return levels.isEmpty();
    }

    public Map<String, Integer> levels() {
        return levels;
    }

    /** Объединяет два набора (например, данные разных провайдеров); при совпадении берётся больший уровень. */
    public EnchantSnapshot mergedWith(EnchantSnapshot other) {
        if (other.isEmpty()) {
            return this;
        }
        if (isEmpty()) {
            return other;
        }
        Map<String, Integer> m = new LinkedHashMap<>(levels);
        other.levels.forEach((k, v) -> m.merge(k, v, Math::max));
        return new EnchantSnapshot(m);
    }

    /** Римская запись для уровней до X, иначе число. */
    public static String roman(int level) {
        return level > 0 && level < ROMAN.length ? ROMAN[level] : Integer.toString(level);
    }

    /** Короткая запись для сообщений: {@code sharpness VII, unbreaking V}. */
    public String describe() {
        if (levels.isEmpty()) {
            return "нет";
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : levels.entrySet()) {
            if (sb.length() > 0) {
                sb.append(", ");
            }
            String k = e.getKey();
            sb.append(k.startsWith("minecraft:") ? k.substring("minecraft:".length()) : k)
                    .append(' ').append(roman(e.getValue()));
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return describe();
    }
}
