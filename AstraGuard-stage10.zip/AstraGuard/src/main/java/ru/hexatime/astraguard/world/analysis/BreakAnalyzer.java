package ru.hexatime.astraguard.world.analysis;

import ru.hexatime.astraguard.combat.analysis.Finding;

/**
 * FastBreak. Сравнивает реальное время ломания блока с ЭТАЛОННЫМ временем, которое считает сам сервер
 * (инструмент, зачарования любого уровня — в т.ч. Efficiency VI–X, Haste, усталость, вода, полёт). Никаких
 * фиксированных скоростей: эталон приходит снаружи. Мгновенно ломаемые блоки (эталон ≤ запаса) не проверяются.
 * <p>
 * Честно: ваниль сама принимает завершение ломания на ~70% прогресса, поэтому проверка ловит только то,
 * что быстрее этого порога (по умолчанию 60% эталона), и требует два случая за 30 секунд.
 */
public final class BreakAnalyzer {

    private static final long WINDOW_MS = 30_000;

    private long lastStrike = Long.MIN_VALUE / 2;

    public void reset() {
        lastStrike = Long.MIN_VALUE / 2;
    }

    /**
     * @param expectedMs эталонное время ломания, мс (0 — мгновенно)
     * @param elapsedMs  реально прошло от начала до конца ломания, мс
     */
    public Finding onBreak(long nowMs, double elapsedMs, double expectedMs, WorldThresholds t) {
        if (expectedMs <= t.breakToleranceMs()) {
            return null;
        }
        double limit = expectedMs * t.minBreakRatio() - t.breakToleranceMs();
        if (elapsedMs >= limit) {
            return null;
        }
        boolean repeat = nowMs - lastStrike <= WINDOW_MS;
        lastStrike = nowMs;
        if (!repeat) {
            return null;
        }
        return Finding.of("FastBreak", "world-break", 1.0,
                String.format("блок сломан за %.0f мс при эталоне %.0f мс (%.0f%%; предел %.0f%%)",
                        elapsedMs, expectedMs, 100.0 * elapsedMs / expectedMs, 100.0 * t.minBreakRatio()),
                "elapsedMs", String.format("%.0f", elapsedMs), "expectedMs", String.format("%.0f", expectedMs));
    }
}
