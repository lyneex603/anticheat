package ru.hexatime.astraguard.world.analysis;

import ru.hexatime.astraguard.combat.analysis.ControlClass;

/**
 * Пороги проверок мира для одного класса управления.
 *
 * @param aimTolerance     запас (блоков) к попаданию взгляда в блок при установке
 * @param aimChecks        включена ли проверка «поставил блок, не глядя на него» (на тач-экране камера не наводится на точку нажатия)
 * @param faceTolerance    запас (блоков) к проверке «грань блока обращена к игроку»
 * @param reachTolerance   запас (блоков) к дальности взаимодействия с блоком
 * @param maxPlacePerSecond больше установок блоков за 1 секунду считается невозможным
 * @param minBreakRatio    доля эталонного времени ломания, ниже которой слом считается слишком быстрым
 * @param breakToleranceMs запас во времени ломания (мс) на тики и сетевой джиттер
 */
public record WorldThresholds(double aimTolerance, boolean aimChecks, double faceTolerance, double reachTolerance,
                              int maxPlacePerSecond, double minBreakRatio, double breakToleranceMs) {

    public static WorldThresholds defaults(ControlClass c) {
        return switch (c) {
            case JAVA -> new WorldThresholds(0.15, true, 0.3, 0.7, 9, 0.6, 100);
            case BEDROCK_KBM -> new WorldThresholds(0.25, true, 0.4, 1.0, 11, 0.6, 150);
            case BEDROCK_CONTROLLER -> new WorldThresholds(0.35, true, 0.5, 1.2, 11, 0.6, 150);
            case BEDROCK_TOUCH, BEDROCK_UNKNOWN -> new WorldThresholds(0.5, false, 0.6, 1.5, 12, 0.55, 200);
        };
    }
}
