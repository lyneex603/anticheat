package ru.hexatime.astraguard.potion.analysis;

import java.util.ArrayList;
import java.util.List;

/**
 * Влияние активных эффектов на урон, которое НЕ видно в атрибутах игрока.
 *
 * @param attackBonus           плоская добавка к урону удара
 * @param damageTakenMultiplier множитель получаемого урона (0.8 — на 20% меньше; 0 — неуязвимость)
 * @param reasons               какие эффекты дали вклад
 */
public record DamageAdjust(double attackBonus, double damageTakenMultiplier, List<String> reasons) {

    public static final DamageAdjust IDENTITY = new DamageAdjust(0.0, 1.0, List.of());

    public DamageAdjust {
        if (damageTakenMultiplier < 0.0) {
            throw new IllegalArgumentException("damageTakenMultiplier must be >= 0");
        }
        reasons = List.copyOf(reasons);
    }

    public boolean isIdentity() {
        return attackBonus == 0.0 && damageTakenMultiplier == 1.0;
    }

    public DamageAdjust and(DamageAdjust o) {
        if (o.isIdentity() && o.reasons.isEmpty()) {
            return this;
        }
        List<String> r = new ArrayList<>(reasons);
        r.addAll(o.reasons);
        return new DamageAdjust(attackBonus + o.attackBonus, damageTakenMultiplier * o.damageTakenMultiplier, r);
    }
}
