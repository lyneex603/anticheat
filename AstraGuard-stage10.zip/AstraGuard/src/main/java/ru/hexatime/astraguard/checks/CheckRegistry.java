package ru.hexatime.astraguard.checks;

import ru.hexatime.astraguard.violation.CheckCategory;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Реестр проверок. Новые проверки (этапы 2-4) регистрируются здесь и сразу видны в /ag checks. */
public final class CheckRegistry {

    /** Описание проверки. */
    public record CheckInfo(String name, String group, CheckCategory category, String description) {
    }

    private final Map<String, CheckInfo> checks = new LinkedHashMap<>();

    public void register(CheckInfo info) {
        checks.put(info.name().toLowerCase(Locale.ROOT), info);
    }

    public Collection<CheckInfo> all() {
        return checks.values();
    }

    public CheckInfo get(String name) {
        return checks.get(name.toLowerCase(Locale.ROOT));
    }
}
