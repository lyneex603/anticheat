package ru.hexatime.astraguard.potion.analysis;

/**
 * Описание влияния одного (кастомного) эффекта на характеристики, задаётся администратором в config.yml.
 * Все значения «за уровень эффекта»; нули означают «не влияет».
 *
 * @param speedPerLevel       прирост допустимой скорости: 0.2 — +20% за уровень (множитель 1 + 0.2·уровень)
 * @param jumpPerLevel        прирост скорости прыжка за уровень
 * @param attackBonusPerLevel плоская добавка к урону удара за уровень
 * @param damageReductionPerLevel доля снижения получаемого урона за уровень (0.2 — −20%)
 * @param exemptMovement      эффект даёт движение вне физики (рывок и т.п.): проверки движения отключаются
 */
public record EffectRule(double speedPerLevel, double jumpPerLevel, double attackBonusPerLevel,
                         double damageReductionPerLevel, boolean exemptMovement) {

    public EffectRule {
        if (speedPerLevel <= -1.0) {
            throw new IllegalArgumentException("speed-per-level must be > -1");
        }
        if (damageReductionPerLevel < 0.0 || damageReductionPerLevel > 1.0) {
            throw new IllegalArgumentException("damage-reduction-per-level must be within 0..1");
        }
    }
}
