package ru.hexatime.astraguard.potion.analysis;

import java.util.List;

/** Складывает вклад всех модификаторов в итоговое влияние эффектов. Чистая логика без Bukkit. */
public final class EffectAggregator {

    private EffectAggregator() {
    }

    public static MovementAdjust movement(List<EffectState> active, List<CustomMovementModifier> modifiers) {
        MovementAdjust result = MovementAdjust.IDENTITY;
        if (active.isEmpty()) {
            return result;
        }
        for (CustomMovementModifier m : modifiers) {
            result = result.and(m.adjust(active));
        }
        return result;
    }

    public static DamageAdjust damage(List<EffectState> active, List<CustomDamageModifier> modifiers) {
        DamageAdjust result = DamageAdjust.IDENTITY;
        if (active.isEmpty()) {
            return result;
        }
        for (CustomDamageModifier m : modifiers) {
            result = result.and(m.adjust(active));
        }
        return result;
    }
}
