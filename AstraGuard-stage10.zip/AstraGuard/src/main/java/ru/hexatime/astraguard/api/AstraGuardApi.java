package ru.hexatime.astraguard.api;

import org.bukkit.entity.Player;
import ru.hexatime.astraguard.AstraGuard;
import ru.hexatime.astraguard.violation.ViolationManager;

import java.util.List;
import java.util.UUID;

/**
 * Публичный API для других плагинов (только чтение; вызывать из основного потока).
 * События {@link AstraFlagEvent} и {@link AstraAutoBanEvent} позволяют отменять флаги и баны.
 */
public final class AstraGuardApi {

    private static volatile AstraGuard plugin;

    private AstraGuardApi() {
    }

    public static void init(AstraGuard instance) {
        plugin = instance;
    }

    public static void shutdown() {
        plugin = null;
    }

    private static AstraGuard require() {
        AstraGuard p = plugin;
        if (p == null) {
            throw new IllegalStateException("AstraGuard не запущен");
        }
        return p;
    }

    /** true, если игрок заходит с Bedrock Edition (по данным Floodgate). */
    public static boolean isBedrock(Player player) {
        return require().profiles().get(player).isBedrock();
    }

    /** Текущее состояние проверок игрока с учётом затухания VL (только с ненулевым VL). */
    public static List<ViolationManager.CheckView> violations(UUID uuid) {
        return require().violations().snapshot(uuid);
    }
}
