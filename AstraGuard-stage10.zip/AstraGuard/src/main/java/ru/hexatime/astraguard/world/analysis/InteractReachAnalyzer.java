package ru.hexatime.astraguard.world.analysis;

import ru.hexatime.astraguard.combat.analysis.Finding;

/** InvalidInteract-Reach. Блок сломан/поставлен/использован дальше дальности взаимодействия (атрибут игрока) + запас. */
public final class InteractReachAnalyzer {

    private double buffer;

    public void reset() {
        buffer = 0;
    }

    /** @param distance расстояние от глаз до ближайшей точки блока; @param range дальность из атрибута игрока */
    public Finding onInteract(double distance, double range, String action, WorldThresholds t) {
        double allowed = range + t.reachTolerance();
        if (distance <= allowed) {
            buffer = Math.max(0.0, buffer - 0.5);
            return null;
        }
        buffer += 1.0;
        if (buffer < 3.0) {
            return null;
        }
        buffer = 1.5;
        return Finding.of("InvalidInteract-Reach", "world-interact", 0.8,
                String.format("%s блока на расстоянии %.2f при допустимых %.2f", action, distance, allowed),
                "distance", String.format("%.2f", distance), "allowed", String.format("%.2f", allowed),
                "action", action);
    }
}
